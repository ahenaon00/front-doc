/// <reference types="cypress" />

describe('Login Bucks',()=>{

    const username = 'jrodriguez@bucks-team.com'
    const password = 'Password1*'
    const url = 'http://localhost:5173/'

    beforeEach(()=>{
        cy.visit(url)
        cy.get('#email').type(username)
        cy.get('#password').type(password)
        cy.get('.inline-flex').click({force: true})
    })


    

    it('Profile',()=>{
        cy.get(':nth-child(2) > .group\\/menu-item > .peer\\/menu-button').click({ force: true, timeout: 10000 })
        cy.get('.gap-6 > .border.relative > .flex-col > :nth-child(1) > .px-2').should('contain.text',username)
    })

    it('Invoices to pay',()=>{
        cy.get(':nth-child(1) > .ml-5 > :nth-child(1) > .flex').click({ force: true, timeout: 10000 })
        cy.get('.flex-grow > .relative > .rounded-full').type('INVERTRIGO')
    })

    it('Unsent Invoices',()=>{
        cy.get(':nth-child(1) > .ml-5 > :nth-child(2) > .flex').click({ force: true, timeout: 10000 })
        cy.get(':nth-child(3) > .mb-2 > .flex-grow > .ml-3 > .relative > .rounded-full').type('Attachment')
    })
    it('Products',()=>{
        cy.get(':nth-child(2) > .ml-5 > :nth-child(1) > .flex').click({ force: true, timeout: 10000 })
    })
    it('Supliers',()=>{
        cy.get(':nth-child(2) > .ml-5 > :nth-child(2) > .flex').click({ force: true, timeout: 10000 })
    })
    it('Taxes',()=>{
        cy.get('.ml-5 > :nth-child(3) > .flex').click({ force: true, timeout: 10000 })
    })
    it('Upload Invoice', () => {
        cy.get('.user > :nth-child(1) > .bg-primary-green-1200').click({ force: true, timeout: 10000 })
    
        cy.get('.dragNdrop').should('be.visible')
    
        cy.get('input[type="file"]').attachFile('invoices/z09014478470082400000016.zip')
        
        
    })
    
   
})