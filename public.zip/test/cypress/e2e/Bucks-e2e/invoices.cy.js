/// <reference types="cypress" />

describe("Upload invoices Api", () => {
	const username = Cypress.env("USERNAME")
	const password = Cypress.env("PASSWORD")
	const url_api = Cypress.env("URL_API")
    const url_front = Cypress.env("URL_FRONT")

    const headers = (token) => {
        return{
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
        
    }
    

    it("delete invoices to upload",()=>{
        cy.request({
            method: "POST",
            url: `${url_api}api/user/login`,
            body: {
                email: username,
                password: password,
            },
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                'Referer': url_front,
                'Origin': url_front

            },
        }).then((responseLogin) => {
            expect(responseLogin.status).to.eq(200)

            cy.request({
                method: 'GET',
                url: `${url_api}api/modules`,
                headers: headers(responseLogin.body.token)
            }).then((response) => {
                const idModule_expenses = response.body.find(module => module.name === 'gastos')._id;
                const idModule_costs = response.body.find(module => module.name === 'costos')._id;

                cy.request({
                    method: 'GET',
                    url: `${url_api}api/transaction-entity/${idModule_costs}`,
                    headers: headers(responseLogin.body.token)
                }).then((response) => {
                    cy.log("🚀 ~ it ~ response:", JSON.stringify(response.body))
                    response.body.forEach((invoice) => {
                        cy.request({
                            method:'DELETE',
                            url: `${url_api}api/transaction-entity/${invoice._id}`,
                            headers: headers(responseLogin.body.token)
                        }).then((response) => {
                            cy.log("response: ", JSON.stringify(response.body))
                        })
                    })
                })

                cy.request({
                    method: 'GET',
                    url: `${url_api}api/transaction-entity/${idModule_expenses}`,
                    headers: headers(responseLogin.body.token)
                }).then((response) => {
                    cy.log("🚀 ~ it ~ response:", JSON.stringify(response.body))
                    response.body.forEach((invoice) => {
                        cy.request({
                            method:'DELETE',
                            url: `${url_api}api/transaction-entity/${invoice._id}`,
                            headers: headers(responseLogin.body.token)
                        }).then((response) => {
                            cy.log("response: ", JSON.stringify(response.body))
                        })
                    })
                })
            })
        })
    })

	it("Upload multiple invoices", () => {
        cy.log("username: ", username)
        cy.log("password: ", password)
        cy.log("url_api: ", url_api)
        cy.log("url_front: ", url_front)
		cy.request({
			method: "POST",
			url: `${url_api}api/user/login`,
			body: {
				email: username,
				password: password,
			},
			headers: {
				"Content-Type": "application/json",
				"Accept": "application/json",
                'Referer': url_front,
                'Origin': url_front

			},
		}).then((responseLogin) => {
			expect(responseLogin.status).to.eq(200)

            cy.task('getFiles', 'invoices').then((files) => {
                let successCount = 0;
                let errorCount = 0;
                let errorFiles = [];
    
                cy.wrap(files).each((fileName) => {
                    cy.fixture(fileName, 'binary').then(fileContent => {
                        const byteArray = new Uint8Array(fileContent.length);
                        for (let i = 0; i < fileContent.length; i++) {
                            byteArray[i] = fileContent.charCodeAt(i);
                        }
    
                        const blob = new Blob([byteArray], { type: 'application/zip' });
    
                        const formData = new FormData();
                        formData.append('file', blob, fileName.split('/').pop());
                        
                        cy.log("token: ", responseLogin.body.token)
                        cy.request({
                            method: 'POST',
                            url: `${url_api}api/file/upload`,
                            body: formData,
                            headers: {
                                'Authorization': `Bearer ${responseLogin.body.token}`,
                                'Content-Type': 'multipart/form-data'
                            },
                            form: false,
                            failOnStatusCode: false
                        }).then((uploadResponse) => {
                            if (uploadResponse.status === 200) {
                                successCount++;
                                cy.log(`✅ Archivo subido: ${fileName}`);
                            } else {
                                errorCount++;
                                errorFiles.push(fileName);
                                cy.log(`❌ Error al subir: ${fileName} (Código ${uploadResponse.status})`);
                            }
                        });
                    });
                }).then(() => {
                    cy.log(`🔹 Total archivos subidos: ${successCount}`);
                    cy.log(`🔸 Total errores: ${errorCount}`);
                    if (errorFiles.length > 0) {
                        cy.log(`⚠️ Archivos con error: ${errorFiles.join(', ')}`);
                    }
                });
            });
        });
    });
})
