import { faker } from "@faker-js/faker"

describe("Regression Bucks", () => {
	const username = Cypress.env("USERNAME")
	const email = username
	const password = Cypress.env("PASSWORD")
	const url = Cypress.env("URL")
	// const url = 'https://staging.dokn3suqe9j70.amplifyapp.com/login'

	const login = () => {
		cy.visit(url)
		cy.get("#email").type(username)
		cy.get("#password").type(password)
		cy.get(".inline-flex").click(configMethod)
	}
    const configMethod = { force: true, timeout: 10000 }
	const fourDigitNumber = faker.number.int({ min: 1000, max: 9999 })

	it("Revisión proveedores", () => {
		login()
		cy.xpath(`//span[normalize-space()='Suppliers']//ancestor::a | //*[@id="providers"]`)
		.click(configMethod)
		cy.get(".space-y-6 > h2").should("contain.text", "Provider Information")


		cy.get('[role="radio"][value="individual"]').click(configMethod)
		cy.get('[name="document"], [data-testid="alternative-document"]').click(configMethod).type(faker?.finance?.routingNumber())
		cy.get('[name="name"]').click(configMethod).type(faker.person.firstName())

        cy.get(`[id=":r11:-form-item"]`).click(configMethod)
        cy.get(`[id="radix-:r1b:"]`,{timeout:10000}).type('test')
        cy.contains("button", "Add code").click(configMethod);
        cy.get(`[id="radix-:r1e:"]`,{timeout:10000}).click(configMethod);
        cy.get(`[id=":r13:-form-item"]`).click(configMethod).type(faker.person.firstName())
        cy.get(`[id=":r14:-form-item"]`).click(configMethod).type(faker.person.lastName())
		cy.get('[id=":r15:-form-item"]').click(configMethod).type(faker.internet.email())
        cy.xpath(`//button[text()='Add Contact'] | //*[@id="addContact"]`).click(configMethod)
	})

	
	it("Verificar página de ajustes", () => {
		login()
		cy.xpath(`//span[text()='Settings']//ancestor::button | //button[@id="settings"]`).click(configMethod)
		cy.get('.text-2xl').should("contain.text", "Preferences")
        cy.xpath(`//span[contains(text(),'correo')]//following-sibling::button | //button[@id="emailConfigGuide"]`).should("be.visible")
        cy.get('[id="inferPUC"]').should("be.visible")
	})

    //TO DO: revisar logica
	it("Revisión productos", () => {
		login()
		cy.xpath(`//span[normalize-space()='Products']//ancestor::a | //*[@id="inventories"]`).click(configMethod)
        cy.get('.space-y-6 > h2').should('contain.text','Product Information')
        cy.get('[role="radio"][value="Product"]').click(configMethod)
        cy.get(`[id=":rt:-form-item"]`).click(configMethod)
        cy.get(`input[name="code"]`).click({ force: true }).type(faker?.finance?.routingNumber(), { force: true });
		cy.get('input[name="name"]').click({ force: true }).type(faker.person.firstName(), { force: true });
        cy.get(`input[name="quantity"]`).click({ force: true }).type('1',{ force: true })
        cy.get(`input[name="reference"]`).click({ force: true }).type(faker?.finance?.routingNumber(),{ force: true })
        cy.get(`input[name="unit.code"]`).click({ force: true }).type(faker?.finance?.routingNumber(),{ force: true })
        cy.get(`input[name="unit.name"]`).click({ force: true }).type(faker.commerce.product.name,{ force: true })
        cy.get(`input[name="unit.label"]`).click({ force: true }).type(faker.commerce.product.name,{ force: true })
        cy.get('#\\:r18\\:-form-item').click({ force: true })
        cy.get(`input[name="taxConsumptionValue"]`).click({ force: true }).type('123',{ force: true })
        cy.get(`button[value="create"]`).click(configMethod)
    })
	

	it('Registro', () => {
	    cy.log(url)
	    cy.visit(url);
	    cy.get(':nth-child(4) > .text-\\[\\#2BAB56\\]').click();
	    cy.get('h1').should('contain.text','Registro tras pago');
	    cy.get('.popup-content > :nth-child(2)').should('contain.text','El siguiente botón te redirigirá a nuestro link de pago de Stripe, una vez realizado el pago, nuestro equipo te enviará lo antes posible tus credenciales para que puedas acceder a Bucks.');
	    cy.get('.reusable-btn').click();

	});
	it('Visualización de contraseña',()=>{
	    cy.visit(url);
	    cy.get('#email').type(username)
	    cy.get('#password').type(password)
	    cy.get('[aria-label="Show password"]').click()
	    cy.get('#password').should('have.attr', 'value', password)
	})
	it('Recordarme',()=>{
	    cy.visit(url);
	    cy.get('#email').type(username)
	    cy.get('#password').type(password)
	    cy.get('#remember').click()
	    cy.get('.inline-flex').click({force: true})
	})
	it('Password reset',()=>{
	    cy.visit(url);
	    cy.get('[href="/forgot-password"]').click();
	    cy.get('#forgot-pass').type(email)
	    cy.get('.reusable-btn').click();
	    cy.get('h1').should('contain.text','Email enviado de forma exitosa');
	    cy.get('p').should('contain.text','Revisa tu Email, Hemos enviado un link para restablecer la contraseña')
	})
	it('Inicio de sesión',()=>{
	    login()
	    cy.get('.peer\\/menu-button > .flex-col > :nth-child(1)').should('contain.text','Hello')
	})
	it('Conexión API Keys',()=>{
	    login()
	    cy.get('.user > :nth-child(1) > .bg-primary-grey-1800').click(configMethod)
	    cy.get('.user > :nth-child(1) > .bg-primary-grey-1800').click(configMethod)
	    cy.get('#apiUser').should('have.attr','value',"sandbox@siigoapi.com")
	    cy.get('[class="absolute right-4 top-1/2 -translate-y-1/2"]').click()
	    cy.get('#apiSecret').should('have.attr','value',"NDllMzI0NmEtNjExZC00NGM3LWE3OTQtMWUyNTNlZWU0ZTM0OkosU2MwLD4xQ08=")
	})

	it('Cargue de facturas',()=>{
	    login()
	    cy.get('.user > :nth-child(1) > .bg-primary-green-1200').click(configMethod)
	    cy.get('.dragNdrop').should('be.visible')
	    cy.get('input[type="file"]').attachFile('invoices/DE_SG57712.zip')
	    cy.get('.popup-content').should('is.visible',true)
	})
	it('Tarjeta Facturas por pagar',()=>{
	    login()
	    cy.xpath(`//span[normalize-space()='Invoices to pay']//ancestor::a | //*[@id="debts"]`).click(configMethod)
	})
	it('Tarjeta Facturas no enviadas',()=>{
	    login()
		cy.xpath(`//span[normalize-space()='Unsent Invoices']//ancestor::a | //*[@id="unsent-invoices"]`).click(configMethod)

	})

	it(`Revisión facturas por pagar`,()=>{
	    login()
		cy.xpath(`//span[normalize-space()='Unsent Invoices']//ancestor::a | //*[@id="unsent-invoices"]`).click(configMethod)
	    cy.get('.flex > :nth-child(3) > .font-normal').should('is.visible',true)
	    cy.get('[placeholder="Search..."]').type('Suministros')
	})
	it('Ampliación información de facturas por pagar',()=>{
	    login()
		cy.xpath(`//span[normalize-space()='Unsent Invoices']//ancestor::a | //*[@id="unsent-invoices"]`).click(configMethod)
	})

	it('Verificar impuestos',()=>{
	    login()
		cy.xpath(`//span[normalize-space()='Taxes']//ancestor::a | //*[@id="taxes"]`).click(configMethod)
	    cy.get(':nth-child(2) > .sm\\:w-3\\/4').should('contain.text','IVA')
	    cy.get(':nth-child(4) > .sm\\:w-3\\/4').should('contain.text','ICA')
	    cy.get(':nth-child(6) > .sm\\:w-3\\/4').should('contain.text','RETEFUENTE')
	})

	it('Verificar página de notificaciones',()=>{
	    login()
		cy.xpath(`//*[contains(@class,'lucide lucide-bell')]//ancestor::button | //*[@id="showNotifications"]`).click(configMethod)
	    cy.get('.m-2 > .text-black').click()
	    cy.get('.inline-flex > .font-normal').should('is.visible',true)
	})

	it('Información personal',()=>{
	    login()
	    cy.get(':nth-child(2) > .group\\/menu-item > .peer\\/menu-button').click(configMethod)
	    cy.get('.gap-6 > .border.relative > .flex-col > :nth-child(1) > .px-2').should('contain.text',username)
	})
	it('Cierre de Sesión',()=>{
	    login()
	    cy.get(':nth-child(2) > .group\\/menu-item > .peer\\/menu-button').click(configMethod)
	    cy.xpath(`//button[text()='Log Out'] | //button[@id='logout']`).click(configMethod)
	    cy.get('.mb-6').should('contain.text','Welcome!')
	})

	it('Verificación de header',()=>{
	    login()
	    cy.get('.inline-flex > .font-normal').should('is.visible',true)
	    cy.get('.user > :nth-child(1) > .bg-primary-green-1200').should('is.visible',true)
	    cy.get('.user > :nth-child(1) > .bg-primary-grey-1800').should('is.visible',true)
	    		cy.xpath(`//*[contains(@class,'lucide lucide-bell')]//ancestor::button | //*[@id="showNotifications"]`).should('is.visible',true)
	})
	it('Tarjeta Token DIAN',()=>{
	    login()
	    cy.get('.\\32 xl\\:gap-14 > .bg-primary-grey-1800').should('is.visible',true)
	})
	it('Cargue Token DIAN',()=>{
	    login()
	    cy.get('#dianTokenCard').click(configMethod)
	    cy.get('input[type="file"]').attachFile('Token_DIAN/09d0c107-7f61-40bd-8b9e-1fae4d1cc2c1.xlsx')
	    cy.get('#uploadToken').click()
	    cy.get('[class="text-lg font-bold mt-2 mb-4"]').should('contain.text','CUFEs Found')
	})

	it('Verificar página de soporte',()=>{
	    login()
		cy.xpath(`//span[text()='Help center']//ancestor::button | //*[@id="help-center"]`).click(configMethod)
	    cy.get('.text-4xl').should('contain.text','Do you need help or want to contact a member of our team?')
	})

	it('Ampliación información de facturas no enviadas',()=>{
	    login()
		cy.xpath(`//span[normalize-space()='Unsent Invoices']//ancestor::a | //*[@id="unsent-invoices"]`).click(configMethod)
	    cy.get(':nth-child(3) > .overflow-auto > .w-full > .\\[\\&_tr\\:last-child\\]\\:border-0 > #\\30  > :nth-child(5) > .w-fit > .inline-flex').click()
	    cy.get('.ml-4').should('contain.text','Invoice No')
	})

	it("Configuración de correo", () => {
		login()
		cy.xpath(`//span[text()='Settings']//ancestor::button | //button[@id="settings"]`).click(configMethod)
		cy.xpath(`//span[contains(text(),'correo')]//following-sibling::button | //button[@id="emailConfigGuide"]`).click(configMethod)
		cy.get(`h2`).should("contain.text", "Email Configuration")
	    cy.get(`h3`).should('contain.text','Automated electronic invoice reception with Outlook')
		cy.get(`button[aria-controls="radix-:r1j:"]`).click(configMethod)
	    cy.get(`[id='radix-:r1k:']`).should('contain.text','Automated electronic invoice reception with Gmail')
		cy.get(`[id='radix-:r1k:']`).click(configMethod)
	})
	it("Enviar a ERP", () => {
		login()
		cy.xpath(`//span[normalize-space()='Unsent Invoices']//ancestor::a | //*[@id="unsent-invoices"]`).click(configMethod)
		cy.wait(4000)
		cy.get(
			":nth-child(3) > .overflow-auto > .w-full > .\\[\\&_tr\\]\\:border-b > .border-b > #select",
		).click({ timeout: 10000 })
		cy.xpath('//button[text()="Send to ERP"]', { timeout: 10000 }).first().click(configMethod)
		cy.get('button[role="checkbox"][aria-label="Select all"]')
        .click({ force: true, multiple: true, timeout: 10000 });
        cy.get(
			":nth-child(3) > .overflow-auto > .w-full > .\\[\\&_tr\\]\\:border-b > .border-b > #select",
		).click({ timeout: 10000 })
		cy.get('button[aria-controls="radix-:rq:"]', { timeout: 10000 }).click(configMethod)
        cy.xpath("//*[local-name()='svg']//ancestor::button[@class='inline-flex capitalize items-center justify-center gap-2 whitespace-nowrap text-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 bg-primary-green-1200 text-primary-grey-1800 border font-bold hover:bg-primary-green-900 hover:border-primary-green-1400 rounded-[22px] h-9 px-4 py-2']")
        .should('be.visible')
        .click({ force: true });

	})
	it("Verificar ERP", () => {
		login()
		cy.xpath(`//span[normalize-space()='Unsent Invoices']//ancestor::a | //*[@id="unsent-invoices"]`).click(configMethod)
		cy.wait(4000)
		cy.get(
			":nth-child(3) > .overflow-auto > .w-full > .\\[\\&_tr\\]\\:border-b > .border-b > #select",
		).click({ timeout: 10000 })
		cy.xpath('//button[text()="Send to ERP"]', { timeout: 10000 }).first().click(configMethod)
		cy.xpath('//h2[text()="Send to ERP"]//ancestor::div//following-sibling::div[@class="w-full mt-2"]//button[@aria-label="Select row"]').first().click()
		cy.xpath('//div[@role="dialog"]//button[text()="Send to ERP"]').click(configMethod)
		cy.wait(4000)
		cy.contains('Error de ERP no controlado, contacte al administrador.', { timeout: 10000 }).should('not.exist')
	})

	it("Revisión información de facturas no enviadas", () => {
		login()
		cy.xpath(`//span[normalize-space()='Unsent Invoices']//ancestor::a | //*[@id="unsent-invoices"]`).click(configMethod)
		cy.get(
			":nth-child(3) > .overflow-auto > .w-full > .\\[\\&_tr\\:last-child\\]\\:border-0 > #\\30  > :nth-child(5) > .w-fit > .inline-flex",
		).click()
		cy.get(".react-pdf__Page__canvas").should("is.visible", true)
	})
	it("Agregar / editar Items", () => {
		login()
		cy.xpath(`//span[normalize-space()='Products']//ancestor::a | //*[@id="inventories"]`).click(configMethod)
		cy.get('.space-y-6 > h2').should('contain.text','Product Information')
        cy.get('[role="radio"][value="Product"]').click(configMethod)
        cy.get(`[id=":rt:-form-item"]`).click(configMethod)
        cy.get(`input[name="code"]`).click({ force: true }).type(faker?.finance?.routingNumber(), { force: true });
		cy.get('input[name="name"]').click({ force: true }).type(faker.person.firstName(), { force: true });
        cy.get(`input[name="quantity"]`).click({ force: true }).type('1',{ force: true })
        cy.get(`input[name="reference"]`).click({ force: true }).type(faker?.finance?.routingNumber(),{ force: true })
        cy.get(`input[name="unit.code"]`).click({ force: true }).type(faker?.finance?.routingNumber(),{ force: true })
        cy.get(`input[name="unit.name"]`).click({ force: true }).type(faker.commerce.product.name,{ force: true })
        cy.get(`input[name="unit.label"]`).click({ force: true }).type(faker.commerce.product.name,{ force: true })
        cy.get('button[id=":r18:-form-item"]').click({ force: true })
        cy.get(`input[name="taxConsumptionValue"]`).click({ force: true }).type('123',{ force: true })
        cy.get('#\\:r18\\:-form-item').click(configMethod);
        cy.get('div[role="option"]').contains('Taxed').click(configMethod);
        cy.get(`button[value="create"]`).click(configMethod)
        cy.get('form',{}).within(() => {
            cy.contains("String must contain at least 1 character(s)", { timeout: 5000 })
              .scrollIntoView()
              .should('not.exist');
        }); 
	})



	it('Review Accrual Invoice Information (Paid and Sent)', () => {
		login()
		cy.get('#debts > span').click(configMethod)
		cy.get('.border-b > .p-2').should('not.contain.text', 'No results.')
	})
	  
	it('API Key Visibility',()=>{
		login()
		cy.xpath('//button[@class="inline-flex capitalize items-center justify-center gap-2 whitespace-nowrap text-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 bg-primary-grey-1800 text-primary-green-1200 border font-bold hover:border-primary-grey-1800 hover:bg-primary-grey-1300 rounded-[22px] h-9 px-4 py-2"]').click(configMethod)
		cy.xpath('//input[@id="apiSecret"]//following-sibling::button').click(configMethod)
		cy.xpath('//input[@id="apiSecret"]').should('not.have.attr','type','password')
	})

	it('Verified Generate accounting certificate',()=>{
		login()
		cy.get('#settings').click(configMethod)
		cy.get(':nth-child(7) > div > .inline-flex').click(configMethod)
		cy.xpath('//h3/button').click(configMethod)
		cy.xpath('//div[@class="pb-4 pt-0"]').should('be.visible')
	})

	it(`Ver más (Facturas pagadas)`,()=>{
	    login()
		cy.get('#debts > span').click(configMethod)
		cy.get('.border-b > .p-2').should('not.contain.text', 'No results.')
	})
	it(`Ver más (Facturas enviadas)`,()=>{
	    login()
		cy.xpath('//h2[text()="Paid Invoices"]//following-sibling::div//td').should('not.contain.text', 'No results.')
			
	})

	it(`Revisar información de facturas de causación (Pagadas y enviadas)`,()=>{

	})

	it('Revisión información consolidada',()=>{
		Cypress.on('uncaught:exception', (err) => {
			if (err.message.includes('F.map is not a function')) {
			  return false
			}
		  })
		login()
		cy.xpath(`//span[normalize-space()='Unsent Invoices']//ancestor::a | //*[@id="unsent-invoices"]`).click(configMethod)
		cy.get(
			":nth-child(3) > .overflow-auto > .w-full > .\\[\\&_tr\\:last-child\\]\\:border-0 > #\\30  > :nth-child(5) > .w-fit > .inline-flex",
		).click()
		
		
		cy.get('[id="invoiceId"]').should('be.visible')
		cy.get('[id="invoiceId"]').scrollIntoView()
		cy.get('[id="invoiceId"]')
		.should('have.attr', 'value')
		.and('not.be.empty')
	})

	// it('Verificación de funcionamiento y secciones',()=>{})
	// it('Plataforma responsive',()=>{})
})
