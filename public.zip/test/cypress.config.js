import { defineConfig } from "cypress";
import { allureCypress } from "allure-cypress/reporter";
import dotenv from "dotenv";
import fs from "fs";
import dotenvPlugin from "cypress-dotenv";

// Cargar variables de entorno desde .env
dotenv.config();

export default defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // Cargar variables desde el .env
      config = dotenvPlugin(config); // Esto asegura que `.env` se cargue en todas las ejecuciones

      on("task", {
        getFiles(folder) {
          return new Promise((resolve, reject) => {
            const folderPath = `cypress/fixtures/${folder}`;
            fs.readdir(folderPath, (err, files) => {
              if (err) {
                return reject(err);
              }
              resolve(files.map(file => `${folder}/${file}`)); // Retorna la ruta completa
            });
          });
        }
      });

      // Fusionar variables de Cypress con las de .env
      config.env = {
        ...process.env,
        ...config.env,
      };
      
      // Configurar Allure
      allureCypress(on, config, {
        resultsDir: "allure-results",
      });

      return config;
    },
    retries: 1,
    video: true,
    screenshotOnRunFailure: true,
  },
});