import { useEffect, useState } from "react"
import Cookies from "js-cookie"
import { pdfjs } from "react-pdf"

import Routing from "@/modules/common/routes"
import { useDispatch } from "react-redux"
import { login } from "@/modules/common/lib/redux/userSlice"
import { authToken } from "@/modules/auth/services/user"
import { syncNotifications } from "@/modules/common/lib/redux/notificationsSlice"
import { getAllNotificationsByFilter } from "@/modules/notifications/services/notifications"
import LogoLoader from "./modules/common/components/app/LogoLoader/LogoLoader"

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/legacy/build/pdf.worker.min.mjs`

const App = () => {
	const [loading, setLoading] = useState(true)
	const dispatch = useDispatch()

	useEffect(() => {
		const verifyToken = async () => {
			try {
				const verifyTokenData = await authToken()
				setLoading(false)
				if (verifyTokenData.status === 200) {
					dispatch(login(verifyTokenData.data))
					dispatch(
						syncNotifications(
							await getAllNotificationsByFilter({
								type: { provider: true, inventory: true, uploadERP: true },
								status: { pending: true },
								priority: { info: true, warning: true, error: true },
							}),
						),
					)
				}
			} catch (error) {
				console.error(error)
				Cookies.remove("token")
				window.location.reload()
			}
		}

		if (Cookies.get("token")) {
			verifyToken()
		} else {
			setLoading(false)
		}
	}, [dispatch])

	if (loading) {
		return (
			<main className="flex items-center justify-center h-screen w-screen">
				<LogoLoader className="h-32 w-32" />
			</main>
		)
	}

	return <Routing />
}

export default App
