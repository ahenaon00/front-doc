// src/pages/NotFound.tsx
import { Link } from 'react-router-dom'

const NotFound = () => {
	return (
		<div className="flex flex-col items-center justify-center min-h-screen">
			<img
				src="/public/full-logo.svg"
				alt="Logo Bucks"
				width={300}
				height={300}
				className="mb-4"
			/>
			<h1 className="text-4xl font-bold mb-4">404 - Page Not Found</h1>
			<p className="mb-8">The page you are looking for does not exist.</p>
			<Link to="/" className="bg-green-500 p-2 rounded text-white font-semibold tracking-wide shadow-md hover:bg-green-600 hover:shadow-lg transition duration-300">
				Go back Home
			</Link>
		</div>
	)
}

export default NotFound