import * as React from "react"
import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react"

import { cn } from "@/modules/common/lib/utils"
import { buttonVariants } from "@/modules/common/components/ui/button"

const Pagination = ({ className, ...props }: React.HTMLAttributes<HTMLElement>) => (
	<nav
		role="navigation"
		aria-label="pagination"
		className={cn("mx-auto flex w-full justify-center", className)}
		{...props}
	/>
)
Pagination.displayName = "Pagination"

const PaginationContent = React.forwardRef<HTMLUListElement, React.ComponentPropsWithoutRef<"ul">>(
	({ className, ...props }, ref) => (
		<ul ref={ref} className={cn("flex flex-row items-center gap-1", className)} {...props} />
	),
)
PaginationContent.displayName = "PaginationContent"

const PaginationItem = React.forwardRef<HTMLLIElement, React.ComponentPropsWithoutRef<"li">>(
	({ className, ...props }, ref) => <li ref={ref} className={cn("", className)} {...props} />,
)
PaginationItem.displayName = "PaginationItem"

interface PaginationLinkProps extends React.HTMLAttributes<HTMLAnchorElement> {
	isActive?: boolean
	disabled?: boolean
	size?: "icon" | "default"
}

const PaginationLink = ({
	className,
	isActive,
	disabled,
	size = "icon",
	...props
}: PaginationLinkProps) => (
	<a
		aria-current={isActive ? "page" : undefined}
		className={cn(
			buttonVariants({
				variant: isActive ? "outline" : "ghost",
				size,
			}),
			"text-primary-grey-1200 cursor-pointer",
			{
				"bg-primary-grey-200 border-0 hover:bg-primary-grey-200 hover:text-primary-grey-1200":
					isActive,
				"text-primary-grey-800 hover:bg-transparent hover:text-primary-grey-800":
					!isActive && disabled,
			},
			className,
		)}
		{...(disabled ? { "aria-disabled": true } : {})}
		{...props}
	/>
)
PaginationLink.displayName = "PaginationLink"

interface PaginationPreviousProps extends React.HTMLAttributes<HTMLAnchorElement> {
	displayName?: string
	disabled?: boolean
}

const PaginationPrevious = ({
	className,
	displayName = "Previous",
	...props
}: PaginationPreviousProps) => (
	<PaginationLink
		aria-label="Go to previous page"
		size="default"
		className={cn("gap-1 pl-2.5 cursor-pointer", className)}
		{...props}
	>
		<ChevronLeft className="h-4 w-4" />
		<span>{displayName}</span>
	</PaginationLink>
)
PaginationPrevious.displayName = "PaginationPrevious"

interface PaginationNextProps extends React.HTMLAttributes<HTMLAnchorElement> {
	displayName?: string
	disabled?: boolean
}

const PaginationNext = ({ className, displayName = "Next", ...props }: PaginationNextProps) => (
	<PaginationLink
		aria-label="Go to next page"
		size="default"
		className={cn("gap-1 pr-2.5 cursor-pointer", className)}
		{...props}
	>
		<span>{displayName}</span>
		<ChevronRight className="h-4 w-4" />
	</PaginationLink>
)
PaginationNext.displayName = "PaginationNext"

const PaginationEllipsis = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => (
	<span
		aria-hidden
		className={cn("flex h-9 w-9 items-center justify-center text-primary-grey-1200", className)}
		{...props}
	>
		<MoreHorizontal className="h-4 w-4" />
		<span className="sr-only">More pages</span>
	</span>
)
PaginationEllipsis.displayName = "PaginationEllipsis"

export {
	Pagination,
	PaginationContent,
	PaginationLink,
	PaginationItem,
	PaginationPrevious,
	PaginationNext,
	PaginationEllipsis,
}
