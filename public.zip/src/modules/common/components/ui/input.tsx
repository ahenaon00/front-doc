// Input.jsx

import React from "react"
import { cva, VariantProps } from "class-variance-authority"
import { cn } from "@/modules/common/lib/utils"
import { Search } from "lucide-react"

const inputVariants = cva(
	"flex h-12 rounded-full bg-primary-grey-50 px-4 py-2 text-base border border-primary-grey-300 focus-visible:outline-none",
	{
		variants: {
			variant: {
				default: "",
				search: "pl-10",
				form: "rounded-none bg-transparent border-0 border-b border-primary-grey-300 px-0 h-min",
			},
		},
		defaultVariants: {
			variant: "default",
		},
	},
)

export interface InputProps
	extends React.InputHTMLAttributes<HTMLInputElement>,
		VariantProps<typeof inputVariants> {
	asChild?: boolean
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
	({ className, type, variant, ...props }, ref) => {
		if (variant === "search") {
			return (
				<div className={cn("relative flex items-center px-2", className)}>
					<Search className="absolute left-5 h-4 text-gray-500" />
					<input
						type={type}
						className={cn(inputVariants({ variant }), "flex h-full text-sm w-full")}
						ref={ref}
						{...props}
					/>
				</div>
			)
		}

		return (
			<input
				type={type}
				className={cn(inputVariants({ variant }), className)}
				ref={ref}
				{...props}
			/>
		)
	},
)

Input.displayName = "Input"

export { Input }
