import {
	FormControl,
	FormDescription,
	FormItem,
	FormLabel,
	FormMessage,
} from "@/modules/common/components/ui/form"
import { Input } from "@/modules/common/components/ui/input"
import { cn } from "@/modules/common/lib/utils"
import { forwardRef } from "react"

export interface Props extends React.InputHTMLAttributes<HTMLInputElement> {
	label?: string
	description?: string
	error?: string
}

const FormInput = forwardRef<HTMLInputElement, Props>(
	({ label, description, className, error, ...field }, ref) => {
		return (
			<FormItem className="relative">
				<FormControl>
					<Input
						ref={ref}
						variant="form"
						className={cn("peer focus:border-primary-green-1500 w-full", className)}
						{...field}
						placeholder=""
					/>
				</FormControl>
				<FormLabel className="absolute w-full top-0 -translate-y-4 cursor-text text-xs peer-focus:-translate-y-4 transition-all peer-focus:text-primary-green-1500 peer-placeholder-shown:translate-y-1 peer-placeholder-shown:text-base">
					{label}
				</FormLabel>
				<FormDescription>{description}</FormDescription>
				<FormMessage>
					{error && error}
				</FormMessage>
			</FormItem>
		)
	},
)

// Add a displayName for debugging
FormInput.displayName = "FormInput"

export default FormInput
