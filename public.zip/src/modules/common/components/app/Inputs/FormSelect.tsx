import {
	FormControl,
	FormDescription,
	FormItem,
	FormLabel,
	FormMessage,
} from "@/modules/common/components/ui/form"
import { cn } from "@/modules/common/lib/utils"
import { forwardRef } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../ui/select"

export interface Props extends React.ComponentPropsWithoutRef<typeof Select> {
	label?: string
	options: string[]
	description?: string
	error?: string
	className?: string
}

const FormSelect = forwardRef<HTMLButtonElement, Props>(
	({ label, options, description, className, error, onValueChange, defaultValue, value }, ref) => {
		const isSelected = !!value;

		return (
			<FormItem className="relative">
				<Select onValueChange={onValueChange} defaultValue={defaultValue} value={value}>
				<FormControl>
						<SelectTrigger
							ref={ref}
							variant="form"
							className={cn(
								"group relative data-[state=open]:border-primary-green-1500 w-full groupplaceholder groupstate=open",
								className,
							)}
						>
							<SelectValue placeholder="" className="peer" />
							<FormLabel
								className={cn(
									"absolute left-0 top-0 cursor-text text-xs transition-all group-data-[state=open]:text-primary-green-1500",
									{
										"translate-y-1 text-base": !isSelected,
										"-translate-y-5 text-xs": isSelected,
									}
								)}
							>
								{label}
							</FormLabel>
						</SelectTrigger>
					</FormControl>
					<SelectContent>
						{options.map((option) => (
							<SelectItem key={option} value={option}>
								{option}
							</SelectItem>
						))}
					</SelectContent>
				</Select>
				<FormDescription>{description}</FormDescription>
				<FormMessage>{error}</FormMessage>
			</FormItem>
		)
	},
)

// Add a displayName for debugging
FormSelect.displayName = "FormSelect"

export default FormSelect
