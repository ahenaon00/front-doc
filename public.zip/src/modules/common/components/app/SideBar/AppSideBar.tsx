import { useEffect, useState } from "react"

import {
	CircleHelp,
	// Home,
	PackageOpen,
	PanelLeftClose,
	PanelLeftOpen,
	Scroll,
	Settings,
} from "lucide-react"
import { useTranslation } from "react-i18next"

import { cn } from "@/modules/common/lib/utils"
import {
	Sidebar,
	SidebarContent,
	SidebarFooter,
	SidebarGroup,
	SidebarGroupContent,
	SidebarHeader,
	SidebarMenu,
	SidebarMenuButton,
	SidebarMenuItem,
	SidebarMenuSub,
	SidebarMenuSubButton,
	SidebarMenuSubItem,
} from "@/modules/common/components/ui/sidebar"
import { Separator } from "@/modules/common/components/ui/separator"
import Logo from "@/modules/common/components/app/Icons/Logo"
import FullLogo from "@/modules/common/components/app/Icons/FullLogo"
import { Avatar } from "@/modules/common/components/ui/avatar"
import { AvatarFallback, AvatarImage } from "@/modules/common/components/ui/avatar"
import { createSelector } from "@reduxjs/toolkit"
import { useSelector } from "react-redux"
import { useLocation, useNavigate } from "react-router-dom"

const selectUser = createSelector(
	(state) => state.user,
	(user) => user,
)

export function AppSidebar() {
	const { t } = useTranslation(["sidebar"])
	const user = useSelector(selectUser)
	const navigate = useNavigate()
	const location = useLocation()
	const [collapsed, setCollapsed] = useState(false)

	useEffect(() => {
		const mediaQuery = window.matchMedia("(min-width: 1024px)")
		const handleChange = () => {
			setCollapsed(!mediaQuery.matches)
		}
		handleChange()
		mediaQuery.addEventListener("change", handleChange)
		return () => mediaQuery.removeEventListener("change", handleChange)
	}, [])

	// Menu items.
	const items = [
		// {
		// 	title: t("menu.home"),
		// 	url: "/",
		// 	icon: Home,
		// },
		{
			title: t("menu.causation"),
			url: "/",
			icon: Scroll,
			submenu: [
				{	
					id:"debts",
					title: t("menu.debts"),
					url: "/debts",
				},
				{	
					id:"unsent-invoices",
					title: t("menu.unsent-invoices"),
					url: "/invoices-not-sent",
				},
			],
		},
		{
			title: t("menu.management"),
			url: "/management",
			icon: PackageOpen,
			submenu: [
				{
					id:"inventories",
					title: t("menu.inventories"),
					url: "/inventory",
				},
				{	
					id: "providers",
					title: t("menu.suppliers"),
					url: "/providers",
				},
				{
					id:"taxes",	
					title: t("menu.taxes"),
					url: "/taxes",
				},
			],
		},
	]

	return (
		<div
			className={cn("relative h-svh min-w-[272px]", {
				"min-w-[83px]": collapsed,
			})}
		>
			<Sidebar
				className={cn("fixed z-50 bg-primary-grey-25", {
					"w-min px-2 py-4 min-w-[83px]": collapsed,
					"p-4 w-full min-w-[272px] bg-primary-grey-25/50 backdrop-blur-xl lg:w-min lg:backdrop-blur-none": !collapsed,
				})}
				collapsible="none"
			>
				<SidebarHeader
					className={cn("flex flex-row justify-between items-center gap-0", {
						"mb-6 mx-20 lg:mx-0": !collapsed,
						"flex-col-reverse justify-normal": collapsed,
					})}
				>
					<Separator
						className={cn("border-t border-primary-grey-600 w-2/3 my-4", {
							hidden: !collapsed,
						})}
					/>
					<button
						onClick={() => {
							window.scrollTo({ top: 0 })
							navigate("")
						}}
					>
						<figure className="flex flex-col gap-1.5 items-start">
							{collapsed ? (
								<Logo
									className={cn("w-8 h-8 ml-1.5 transition-colors duration-300", {
										"m-0 fill-primary-grey-600 hover:fill-primary-green-1200": collapsed,
									})}
								/>
							) : (
								<div className="w-40 h-8">
									<FullLogo
										className={cn("w-40 h-20 -ml-3 -mt-3 transition-colors duration-300", {
											"m-0 fill-primary-grey-600 hover:fill-primary-green-1200": collapsed,
										})}
									/>
								</div>
							)}
							{/* <div className={cn("flex flex-col items-start", { hidden: collapsed })}>
								<span className="mt-3 text-3xl -mb-2 font-[FoundersGrotesk] text-primary-grey-1800">
									{t("logo.title")}
								</span>
							</div> */}
							<span className={cn("text-xs mt-1 text-primary-grey-1000 ml-[46px]", { hidden: collapsed })}>
								{t("logo.subtitle")}
							</span>
						</figure>
					</button>
					<Separator
						className={cn("border-t border-primary-grey-600 w-2/3 my-4", {
							hidden: !collapsed,
						})}
					/>
					<button
						onClick={() => setCollapsed(!collapsed)}
						className={cn({
							"mt-4": collapsed,
						})}
					>
						{collapsed ? <PanelLeftOpen /> : <PanelLeftClose />}
					</button>
				</SidebarHeader>
				<SidebarContent className={cn("flex flex-col mx-20 lg:mx-0", { "w-min mx-auto -mt-2": collapsed })}>
					<SidebarGroup>
						<SidebarGroupContent>
							<SidebarMenu>
								{items.map((item) => (
									<SidebarMenuItem key={item.title}>
										<SidebarMenuButton
											className="text-base h-9 lg:hover:bg-primary-grey-200"
											onClick={() => {
												window.scrollTo({ top: 0 })
												navigate(item.url)
											}}
											variant={location.pathname === item.url ? "active" : "default"}
										>
											<item.icon className="h-6 w-6" />
											{!collapsed && <span>{item.title}</span>}
										</SidebarMenuButton>
										{item.submenu && !collapsed && (
											<SidebarMenuSub>
												{item.submenu.map((subitem) => (
													<SidebarMenuSubItem key={subitem.title}>
														<SidebarMenuSubButton
															className={cn(
																"ease-in-out duration-300 transition text-base h-9 hover:bg-primary-grey-200 cursor-pointer border border-transparent",
																{
																	"border-primary-grey-600": location.pathname === subitem.url,
																},
															)}
															onClick={() => {
																window.scrollTo({ top: 0 })
																navigate(subitem.url)
															}}
															id={subitem.id}
														>
															<span>{subitem.title}</span>
														</SidebarMenuSubButton>
													</SidebarMenuSubItem>
												))}
											</SidebarMenuSub>
										)}
									</SidebarMenuItem>
								))}
							</SidebarMenu>
						</SidebarGroupContent>
					</SidebarGroup>
				</SidebarContent>
				<SidebarFooter className={cn("flex flex-col items-center", { "mx-20 lg:mx-0": !collapsed })}>
					<SidebarMenu className={cn("mb-4", { "w-min mx-auto": collapsed })}>
						<SidebarMenuItem>
							<SidebarMenuButton
								className="text-base h-9 hover:bg-primary-grey-200 ease-in-out duration-300 transition"
								id="settings"
								onClick={() => {
									window.scrollTo({ top: 0 })
									navigate("/settings")
								}}
								variant={location.pathname === "/settings" ? "active" : "default"}
							>
								<Settings className="h-6 w-6" />
								{!collapsed && <span>{t("menu.settings")}</span>}
							</SidebarMenuButton>
						</SidebarMenuItem>
						<SidebarMenuItem>
							<SidebarMenuButton
								className="text-base h-9 hover:bg-primary-grey-200"
								variant={location.pathname === "/help-center" ? "active" : "default"}
								onClick={() => {
									window.scrollTo({ top: 0 })
									navigate("/help-center")
								}}
								id="help-center"
							>
								<CircleHelp className="h-6 w-6" />
								{!collapsed && <span>{t("menu.help-center")}</span>}
							</SidebarMenuButton>
						</SidebarMenuItem>
					</SidebarMenu>
					<SidebarMenu>
						<SidebarMenuItem>
							<SidebarMenuButton
								className="text-base h-12 hover:bg-primary-grey-200 flex gap-4 rounded-full"
								onClick={() => {
									window.scrollTo({ top: 0 })
									navigate("/profile")
								}}
								variant={location.pathname === "/profile" ? "active" : "default"}
							>
								<Avatar className="h-8 w-8 items-center justify-center">
									<AvatarImage src="" alt={`${user.name} ${user.lastname}`} />
									<AvatarFallback className="bg-primary-grey-400">
										{user.name[0]}
										{user.lastname[0]}
									</AvatarFallback>
								</Avatar>
								{!collapsed && (
									<div className="flex flex-col">
										<span>{t("greeting")}</span>
										<span className="line-clamp-1">
											{user.name} {user.lastname}
										</span>
									</div>
								)}
							</SidebarMenuButton>
						</SidebarMenuItem>
					</SidebarMenu>
				</SidebarFooter>
			</Sidebar>
		</div>
	)
}
