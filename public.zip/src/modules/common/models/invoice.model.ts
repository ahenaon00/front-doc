export default interface InvoiceModel {
  items: Array<any>
	dueDate: string
	invoiceId: string
	invoiceTotal: string
	vendorCity: string
	customerName: string
	customerId: string
	customerAddress: string
	customerCity: string
	issueDate: string
	invoiceTax: number
	id: string
	supplierId: string
}