import { BrowserRouter, Route, Routes } from "react-router-dom"

import PrivatePageLayout from "@/modules/common/layouts/PrivatePageLayout"
import AccountVerification from "@/modules/auth/pages/accountVerification/AccountVerification"
// import Home from "@/components/pages/Home/Home"
import { ForgotPassword } from "@/modules/auth/pages/ForgotPassword/ForgotPassword.tsx"
import Inventory from "@/modules/management/pages/Inventory/Inventory"
import { Login } from "@/modules/auth/pages/Login/Login"
import Notifications from "@/modules/notifications/pages/notifications/Notifications.tsx"
import Orders from "@/modules/sales/pages/Orders/Orders"
import Profile from "@/modules/preferences/pages/Profile/Profile"
import ProviderBySales from "@/modules/sales/pages/providerBySales/providerBySales"
import Providers from "@/modules/management/pages/Providers/Providers"
import { ResetController } from "@/modules/auth/pages/ResetPassword/Reset"
import SalesForm from "@/modules/sales/pages/SaleForm/SaleForm"
import Sales from "@/modules/sales/pages/Sales/Sales"
import { TransactionEntity } from "@/modules/causation/pages/transactionEntity/TransactionEntity.tsx"
import PayrollCalculations from "@/modules/payroll/pages/PayrollCalculations/PayrollCalculations"
import Deductions from "@/modules/payroll/pages/Deductions/Deductions"
import Contributions from "@/modules/payroll/pages/Contributions/Contributions"
import ExpenseReports from "@/modules/payroll/pages/ExpenseReports/ExpenseReports"
import Payroll from "@/modules/payroll/pages/Payroll/Payroll"
import Employees from "@/modules/payroll/pages/Employees/Employees"
import PayrollPeriods from "@/modules/payroll/pages/PayrollPeriods/PayrollPeriods"
import { PrivateRoutes, PublicRoutes } from "@/modules/common/lib/utils/PrivateRoute"
import Causation from "@/modules/causation/pages/Causation/Causation"
import InvoicesNotSent from "@/modules/causation/pages/InvoicesNotSent/InvoicesNotSent"
import ConsolidatedInfo from "@/modules/causation/pages/ConsolidatedInfo/ConsolidatedInfo.tsx"
import Debts from "@/modules/causation/pages/Debts/Debts"
import HelpCenter from "@/modules/support/pages/HelpCenter/HelpCenter"
import Settings from "@/modules/preferences/pages/Settings/Settings"
import Taxes from "@/modules/management/pages/Taxes/Taxes.tsx"
import Management from "@/modules/management/pages/Mangement/Management.tsx"
import PaidInvoices from "@/modules/causation/pages/PaidInvoices/PaidInvoices"
import SentInvoices from "@/modules/causation/pages/SentInvoices/SentInvoices"
import InvoicesLoaded from "@/modules/causation/pages/InvoicesLoaded/InvoicesLoaded"
import NotFound from "@/modules/common/pages/NotFound"
import Invoice from "@/modules/causation/pages/Invoice/Invoice"

const Routing = () => {
	return (
		<BrowserRouter>
			<Routes>
				{/* Imported the public Routes */}
				<Route element={<PublicRoutes />}>
					<Route path="/login" element={<Login />} />
					<Route path="/forgot-password" element={<ForgotPassword />} />
					<Route path="/password-reset/:token" element={<ResetController />} />
					<Route path="/verify/:token" element={<AccountVerification />} />
				</Route>
				{/* Imported the private Routes */}
				<Route
					element={
						<PrivatePageLayout>
							<PrivateRoutes />
						</PrivatePageLayout>
					}
				>
					{/* <Route path="/" element={<Home />} /> */}
					<Route path="/" element={<Causation />} />

					{/* Workflow Routes */}
					<Route path="/home/invoices-loaded" element={<InvoicesLoaded />} />
					<Route path="/causation" element={<Causation />} />
					<Route path="/causation/paid-invoices" element={<PaidInvoices />} />
					<Route path="/causation/sent-invoices" element={<SentInvoices />} />
					<Route path="/management" element={<Management />} />
					<Route path="/invoices-not-sent" element={<InvoicesNotSent />} />
					<Route path="/debts" element={<Debts />} />
					<Route path="/consolidated-info/:id" element={<ConsolidatedInfo />} />
					<Route path="/settings" element={<Settings />} />
					<Route path="/get-report/:id" element={<TransactionEntity />} />
					<Route path="/invoice/:id" element={<Invoice />} />
					<Route path="/providers" element={<Providers />} />
					<Route path="/profile" element={<Profile />} />
					<Route path="/inventory" element={<Inventory />} />
					<Route path="/notifications" element={<Notifications />} />
					<Route path="/orders" element={<Orders />} />
					<Route path="/sales" element={<ProviderBySales />} />
					<Route path="/sales/:id" element={<Sales />} />
					<Route path="/sales/form" element={<SalesForm />} />
					<Route path="/taxes" element={<Taxes />} />
					<Route path="/payroll" element={<Payroll />} />
					<Route path="/payroll/periods" element={<PayrollPeriods />} />
					<Route path="/employees" element={<Employees />} />
					<Route path="/payroll/calculations" element={<PayrollCalculations />} />
					<Route path="/payroll/deductions" element={<Deductions />} />
					<Route path="/payroll/contributions" element={<Contributions />} />
					<Route path="/payroll/expenseReports" element={<ExpenseReports />} />
					<Route path="/help-center" element={<HelpCenter />} />
				</Route>
				<Route path="*" element={<NotFound />} />
			</Routes>
		</BrowserRouter>
	)
}

export default Routing
