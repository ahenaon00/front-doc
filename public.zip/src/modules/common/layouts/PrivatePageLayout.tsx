import { AppSidebar } from "@/modules/common/components/app/SideBar/AppSideBar"
import { SidebarProvider } from "@/modules/common/components/ui/sidebar"
import { Toaster } from "sonner"

interface Props {
	children: React.ReactNode
}

export default function PrivatePageLayout({ children }: Props) {
	return (
		<div className="w-full flex">
			<SidebarProvider>
				<AppSidebar />
				<div className="relative w-full min-h-screen">{children}</div>
			</SidebarProvider>
			<Toaster />
		</div>
	)
}
