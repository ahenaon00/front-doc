export function formatNumber(num: number) {
	// Convierte el número en un formato con comas y dos decimales
	const formatted = num.toLocaleString("es-ES", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2,
	})

	return "$ " + formatted
}
