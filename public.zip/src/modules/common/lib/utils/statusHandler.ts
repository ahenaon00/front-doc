export const statusHandler = (status: number) => {
    if (status === 200) {
        return "Success";
    } else if (status === 400) {
        return "Bad Request";
    } else if (status === 401) {
        return "Unauthorized";
    } else if (status === 403) {
        return "Forbidden";
    } else if (status === 404) {
        return "Not Found";
    } else if (status === 500) {
        return "Internal Server Error";
    } else {
        return "Unknown";
    }
}