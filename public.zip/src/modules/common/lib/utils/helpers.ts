export const formatPrice = (value: number | string) => {
	// Verificar que el valor sea un número o cadena
	if (typeof value !== "number" && typeof value !== "string") {
		console.error("El valor debe ser un número o una cadena.")
	}

	// Convertir el valor a un número, en caso de ser cadena
	const numericValue = typeof value === "string" ? parseFloat(value) : value

	if (isNaN(numericValue)) {
		console.error("El valor no es un número válido.")
	}

	// Formatear el número usando Intl.NumberFormat para el formato colombiano
	return new Intl.NumberFormat("es-CO", {
		style: "currency",
		currency: "COP",
		minimumFractionDigits: 2,
		maximumFractionDigits: 2,
	}).format(numericValue)
}

export const formatPercentage = (value: number | string) => {
	const numericValue = typeof value === "string" ? parseFloat(value) : value
	if (isNaN(numericValue)) {
		console.error("El valor no es un número válido.")
		return "0%"
	}

	// Formatear el número como porcentaje
	return new Intl.NumberFormat("es-CO", {
		style: "percent",
		minimumFractionDigits: 2,
		maximumFractionDigits: 2,
	}).format(numericValue / 100)
}

export const transformDataForTable = (data: any[]) => {
	const groupedByRows: { [key: number]: any[] } = {}

	// Group items by rowIndex
	data.forEach((item: any) => {
		if (!groupedByRows[item.rowIndex]) {
			groupedByRows[item.rowIndex] = []
		}
		groupedByRows[item.rowIndex].push(item)
	})

	// Convert object to array of rows for easier mapping
	const rows = Object.values(groupedByRows)

	// Optionally, sort rows by rowIndex if necessary (assuming it's already in order)
	rows.sort((a, b) => a[0].rowIndex - b[0].rowIndex)
	return rows
}

export const getDetailedData = (data: any[]) => {
	return data.map((row) => {
		const Total = row.total
		const description = row.description
		const quantity = row.quantity //parseInt(row.quantity?.value)

		const UnitPrice = row.unitPrice
		const TaxRate = row.unitTax

		return {
			total: Total,
			description,
			quantity,
			unitPrice: UnitPrice,
			unitTax: TaxRate,
		}
	})
}

export function isBase64(str: string) {
	try {
		return btoa(atob(str)) === str
	} catch (err) {
		return false
	}
}
