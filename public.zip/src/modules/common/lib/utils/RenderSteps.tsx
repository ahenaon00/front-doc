export function renderSteps(steps: any[], start = 1) {
  return steps.map((step, index) => {
    if (Array.isArray(step)) {
      // Renderiza subpasos con indentación y guiones verdes
      return (
        <ul key={`substep-${index}`} className="ml-6">
          {step.map((substep, subIndex) => (
            <li key={`substep-${index}-${subIndex}`} className="text-gray-700">
              <span className="text-primary-green-1400 font-bold">-</span>{" "}
              {substep}
            </li>
          ))}
        </ul>
      );
    } else {
      // Renderiza pasos normales con número y color
      return (
        <p key={`step-${index}`} className="mb-2">
          <span className="text-primary-green-1400 font-bold">
            {index + start}.
          </span>{" "}
          {step}
        </p>
      );
    }
  });
}
