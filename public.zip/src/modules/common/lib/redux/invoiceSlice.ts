import { createSlice } from "@reduxjs/toolkit"

const initialState: any = {
	invoices: [],
	fetchInvoices: false,
}

export const invoiceSlice = createSlice({
	name: "invoice",
	initialState,
	reducers: {
		addInvoice: (state, action) => {
			const { status, name, description, extension, blobid, invoiceId, module,date } = action.payload
			state.invoices.push({
				status,
				name,
				description,
				extension,
				blobid,
				invoiceId,
				module,
				date
			})
			state.fetchInvoices = true
		},
		fetchInvoicesSuccess: (state) => {
			state.fetchInvoices = false
		},
		clearInvoices: (state) => {
			state.invoices = []
      state.fetchInvoices = true
		},
	},
})

export const { addInvoice, clearInvoices, fetchInvoicesSuccess } = invoiceSlice.actions
export default invoiceSlice.reducer
