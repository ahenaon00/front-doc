import { configureStore } from "@reduxjs/toolkit"

// Import Reducers
import userReducer from "./userSlice.ts"
import invoiceSlice from "./invoiceSlice.ts"
import notificationsSlice from "./notificationsSlice.ts"
import providersSlice from "./providersSlice.ts"
import progressSlice from "./progressSlice.ts"

export const store = configureStore({
	reducer: {
		user: userReducer,
		invoice: invoiceSlice,
		notifications: notificationsSlice,
		providers: providersSlice,
		progress: progressSlice,
	},
})
