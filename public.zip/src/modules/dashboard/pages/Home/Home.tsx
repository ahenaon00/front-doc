import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux" // Importa el hook para acceder al estado de Redux
import Header from "@/modules/common/components/app/Header/Header"
import "react-toastify/dist/ReactToastify.css"
import "./Home.css"

import { useTranslation } from "react-i18next"
import LookerDashboard from "@/modules/dashboard/components/LookerDashboard/LookerDashboard"
import { setWelcome } from "@/modules/common/lib/redux/userSlice"

export default function Home() {
	const { t } = useTranslation(["home"])

	const user = useSelector((state: any) => state.user)
	const dispatch = useDispatch()

	useEffect(() => {
		if (user.newUser && !user.welcome) {
			dispatch(setWelcome())
		}
	}, [user, dispatch])

	return (
		<>
			<Header title={t("title")} sections={[{ title: t("home"), href: "/" }]} />
			<LookerDashboard />
		</>
	)
}
