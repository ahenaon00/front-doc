import { useCallback, useState } from "react"

import { toast } from "sonner"
import { Loader2 } from "lucide-react"
import DropzoneUpload from "@/components/common/popUps/dragNdrop/dropZone"
import { uploadTemplateFile } from "../../services/export"

interface Props {
	onUploadSuccess: (templateUploadResult: any) => void
}

export function UploadExportTemplate({ onUploadSuccess }: Props) {
	const [loading, setLoading] = useState(false)

	const handleDrop = useCallback(
		async (files: File[]) => {
			const file = files[0]
			if (!file) return

			setLoading(true)
			try {
				const result = await uploadTemplateFile(file)
				if (result.success) {
					toast.success("Plantilla cargada correctamente")
					onUploadSuccess(result)
				} else {
					toast.error("Error al procesar la plantilla")
				}
			} catch (error) {
				console.error("Upload error:", error)
				toast.error("Error al subir la plantilla")
			} finally {
				setLoading(false)
			}
		},
		[onUploadSuccess],
	)

	return (
		<div className="mt-2">
			{loading ? (
				<div className="flex items-center justify-center gap-2">
					<Loader2 className="animate-spin" />
					<p>Cargando...</p>
				</div>
			) : (
				<DropzoneUpload
					onDrop={handleDrop}
					multiple={false}
					className="p-4 bg-white"
				/>
			)}
		</div>
	)
}
