import { useEffect, useState } from "react"
import {
	ColumnDef,
	ColumnFiltersState,
	flexRender,
	getCoreRowModel,
	getFilteredRowModel,
	getPaginationRowModel,
	getSortedRowModel,
	SortingState,
	useReactTable,
} from "@tanstack/react-table"
import { BadgePercent, Send, Undo2 } from "lucide-react"
import { useTranslation } from "react-i18next"
import { Checkbox } from "@/modules/common/components/ui/checkbox"
import { Popover, PopoverContent, PopoverTrigger } from "@/modules/common/components/ui/popover"
import { Button } from "@/modules/common/components/ui/button"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import { formatPercentage, formatPrice } from "@/modules/common/lib/utils/helpers"
import {
	Select,
	SelectContent,
	SelectGroup,
	SelectItem,
	SelectLabel,
	SelectTrigger,
	SelectValue,
} from "@/modules/common/components/ui/select"
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger,
} from "@/modules/common/components/ui/tooltip"
import { HiSparkles } from "react-icons/hi2"
import { getProviderInfoInInvoice, uploadInvoiceToERP } from "../../services/invoice"
import { PulseLoader } from "react-spinners"

interface Props {
	data: any[]
	setData: (data: any[]) => void
}

export function DataTableSendToERP({ data, setData }: Props) {
	const [sorting, setSorting] = useState<SortingState>([])
	const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([])
	const [columnVisibility, setColumnVisibility] = useState({})
	const [rowSelection, setRowSelection] = useState({})
	const [selectedInvoices, setSelectedInvoices] = useState<any[]>([])
	const [uploading, setUploading] = useState(false)
	const [loadingInvoices, setLoadingInvoices] = useState<boolean[]>([])
	const [invoiceResponses, setInvoiceResponses] = useState<any[]>([])

	const { t } = useTranslation(["invoicesNotSent"])

	const handleRowSelectionChange = (row: any, isSelected: boolean) => {
		setSelectedInvoices((prev) =>
			isSelected ? [...prev, row] : prev.filter((item) => item.mongoId !== row.mongoId),
		)
	}

	const columns: ColumnDef<any>[] = [
		{
			id: "select",
			header: ({ table }) => (
				<Checkbox
					checked={
						table.getIsAllPageRowsSelected() ||
						(table.getIsSomePageRowsSelected() && "indeterminate")
					}
					onCheckedChange={(value) => {
						table.toggleAllPageRowsSelected(!!value)
						setSelectedInvoices(value ? table.getRowModel().rows.map((row) => row.original) : [])
					}}
					aria-label="Select all"
				/>
			),
			cell: ({ row }) => (
				<Checkbox
					checked={row.getIsSelected()}
					onCheckedChange={(value) => {
						row.toggleSelected(!!value)
						handleRowSelectionChange(row.original, !!value)
					}}
					aria-label="Select row"
				/>
			),
			enableSorting: false,
			enableHiding: false,
		},
		{
			accessorKey: "invoiceId",
			header: t("table.numInvoice"),
			cell: ({ row }) => row.getValue("invoiceId"),
		},
		{
			accessorKey: "invoiceTotal",
			header: () => t("table.total"),
			cell: ({ row }) => <div>{formatPrice(row.getValue("invoiceTotal"))}</div>,
		},
		{
			accessorKey: "providerName",
			header: () => t("table.provider"),
			cell: ({ row }) => <div>{row.getValue("providerName")}</div>,
		},
		{
			accessorKey: "PUC",
			header: () => <div className="text-right">PUC</div>,
			cell: ({ row }: any) => {
				const invoice = row.original

				return (
					<div className="capitalize text-right">
						<Select
							onValueChange={(value) => {
								const newData = data.map((item) => {
									if (item._id === invoice._id) {
										return {
											...item,
											defaultPUC: value,
										}
									}
									return item
								})
								setData(newData)
							}}
							defaultValue={
								invoice.defaultPUC !== ""
									? invoice.defaultPUC
									: invoice.inferedPuc !== ""
										? invoice.inferedPuc
										: undefined
							}
						>
							<SelectTrigger className="group/selected border-primary-grey-600">
								<SelectValue placeholder="No PUC" />
							</SelectTrigger>
							<SelectContent>
								<SelectGroup>
									<SelectLabel>{t("pucCodes")}</SelectLabel>
									{!invoice.defaultPUC && invoice.inferedPuc && (
										<SelectItem value={invoice.inferedPuc} className="relative group/options">
											<span>{invoice.inferedPuc}</span>
											<TooltipProvider>
												<Tooltip>
													<TooltipTrigger className="group-only/selected:hidden size-4 p-0 absolute right-2 top-1/2 transform -translate-y-1/2 group-data-[state=checked]/options:right-6">
														<HiSparkles className="text-tertiary-mint-1200 size-4" />
													</TooltipTrigger>
													<TooltipContent>
														<div className="bg-primary-grey-50 text-primary-grey-1000 p-2 rounded-md">
															{t("inferredAI")}
														</div>
													</TooltipContent>
												</Tooltip>
											</TooltipProvider>
										</SelectItem>
									)}
									{invoice.defaultPUC && (
										<SelectItem value={invoice.defaultPUC} className="relative group/options">
											{invoice.defaultPUC}
										</SelectItem>
									)}
									{row
										.getValue("PUC")
										.filter((puc: string) => puc !== invoice.defaultPUC)
										.map((puc: string) => (
											<SelectItem value={puc}>{puc}</SelectItem>
										))}
								</SelectGroup>
							</SelectContent>
						</Select>
					</div>
				)
			},
		},
		{
			id: "actions",
			enableHiding: false,
			header: () => <div className="w-8"></div>,
			cell: ({ row }) => {
				const invoice = row.original

				return (
					<div className="w-fit ml-auto flex items-center">
						<Popover>
							<PopoverTrigger asChild>
								<Button
									variant="ghost"
									className="h-8 w-8 p-0 hover:bg-primary-grey-200"
									onClick={() => {}}
								>
									<BadgePercent className="stroke-primary-grey-1600" />
								</Button>
							</PopoverTrigger>
							<PopoverContent className="w-80">
								<p>{t("table.taxes")}</p>
								<Table>
									<TableHeader>
										<TableRow>
											<TableHead>{t("table.name")}</TableHead>
											<TableHead>{t("table.amount")}</TableHead>
											<TableHead className="text-right">{t("table.rate")}</TableHead>
										</TableRow>
									</TableHeader>
									<TableBody>
										{[...invoice.taxes, ...(invoice.calculatedTaxes || [])].map((tax: any) => (
											<TableRow>
												<TableCell className="font-medium">{tax.name}</TableCell>
												<TableCell>{formatPrice(tax.amount)}</TableCell>
												<TableCell className="text-right">
													{formatPercentage(tax.percent)}
												</TableCell>
											</TableRow>
										))}
									</TableBody>
								</Table>
							</PopoverContent>
						</Popover>
					</div>
				)
			},
		},
	]
	const table = useReactTable({
		data,
		columns,
		onSortingChange: setSorting,
		onColumnFiltersChange: setColumnFilters,
		getCoreRowModel: getCoreRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		getSortedRowModel: getSortedRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		onColumnVisibilityChange: setColumnVisibility,
		onRowSelectionChange: setRowSelection,
		state: {
			sorting,
			columnFilters,
			columnVisibility,
			rowSelection,
		},
	})

	useEffect(() => {
		table.toggleAllPageRowsSelected(true)
		setSelectedInvoices(table.getRowModel().rows.map((row) => row.original))
	}, [table])

	const handleLogFinalItems = async () => {
		setUploading(true)
		setLoadingInvoices(selectedInvoices.map(() => true))
		const responses: any[] = []

		const uploadPromises = selectedInvoices.map(async (file, index) => {
			try {
				const response = await uploadInvoiceToERP(
					file._id,
					file.defaultPUC ? file.defaultPUC : file.inferedPuc,
				)
				console.log(response)

				responses[index] = {
					status: response.status,
					message: "Factura subida al ERP",
				}
			} catch (error: any) {
				console.error("Error uploading invoice to ERP:", error)

				const errorcode =
					error.response?.data?.error?.body?.code ||
					error.response?.data?.error?.data?.code ||
					"unhandled_error"

				responses[index] = {
					status: error.response?.status || "error",
					message: await handleErrorMessage(errorcode, file),
				}
			} finally {
				setLoadingInvoices((prev) => {
					const newLoading = [...prev]
					newLoading[index] = false
					return newLoading
				})
			}
		})

		await Promise.all(uploadPromises)

		setInvoiceResponses(responses)
	}

	const handleErrorMessage = async (error: any, file: any) => {
		try {
			switch (error) {
				case "unhandled_error":
					return "Error de ERP no controlado, contacte al administrador."
				case "invalid_document":
					return "El id del tipo de comprobante no corresponde al que estás creando"
				case "documents_service":
					return "El servicio de documentos no está disponible o algún campo de la factura es erróneo, intente en unos minutos."
				case "duplicated_document":
					return "El Comprobante ya existe en el ERP."
				case "invalid_code":
					return "El código del documento no es válido. El código no puede tener comillas simples (') ni espacios."
				case "requests_limit":
					return "Se ha superado el límite de solicitudes, intente en unos minutos."
				case "invalid_reference": {
					if (error.response.data.error.body.params[0] === "document.id") {
						return `Hay un error con el id del documento/modulo, revise que exista en su ERP "${error.response.data.error.body.message}"`
					} else {
						const response = await getProviderInfoInInvoice(file.id)
						// setProvider(response[0])
						// setCustomerConfirmation(true)
						return `El proveedor ${response[0].vendor.name} no existe, revise el NIT.`
					}
				}
				case "length_max":
					return "La longitud del campo descripción excede el máximo permitido."
				default:
					return error.response?.data?.error[0]?.Message || "Ocurrió un error, intentelo más tarde."
			}
		} catch {
			return "Ocurrió un error, valide los datos de subida."
		}
	}

	return (
		<div className="w-full mt-2">
			<Table>
				<TableHeader>
					{uploading ? (
						<TableRow>
							<TableHead>{t("table.numInvoice")}</TableHead>
							<TableHead className="text-right">{t("table.uploadStatus")}</TableHead>
						</TableRow>
					) : (
						table.getHeaderGroups().map((headerGroup) => (
							<TableRow key={headerGroup.id}>
								{headerGroup.headers.map((header) => {
									return (
										<TableHead key={header.id}>
											{header.isPlaceholder
												? null
												: flexRender(header.column.columnDef.header, header.getContext())}
										</TableHead>
									)
								})}
							</TableRow>
						))
					)}
				</TableHeader>
				<TableBody>
					{uploading ? (
						selectedInvoices.map((invoice, index) => (
							<TableRow key={invoice?._id}>
								<TableCell>
									{invoice?.invoiceId} - {invoice?.providerName}
								</TableCell>
								<TableCell className="text-right">
									{loadingInvoices[index] ? (
										<div className="ml-auto">
											<PulseLoader
												size={10}
												color={"hsl(var(--primary-green-1200))"}
												loading={true}
											/>
										</div>
									) : (
										<p>{invoiceResponses[index]?.message}</p>
									)}
								</TableCell>
							</TableRow>
						))
					) : table.getRowModel().rows?.length ? (
						table.getRowModel().rows?.map((row) => (
							<TableRow key={row?.id} data-state={row?.getIsSelected() && "selected"}>
								{row.getVisibleCells().map((cell) => (
									<TableCell key={cell?.id}>
										{flexRender(cell?.column.columnDef.cell, cell.getContext())}
									</TableCell>
								))}
							</TableRow>
						))
					) : (
						<TableRow>
							<TableCell colSpan={columns.length} className="h-24 text-center">
								No results.
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
			<div className="w-full mt-2 flex justify-center">
				{uploading ? (
					<Button
						variant="quiet"
						disabled={selectedInvoices.length <= 0}
						onClick={() => setUploading(false)}
					>
						<Undo2 /> {t("actions.goBack")}
					</Button>
				) : (
					<Button
						variant="primary"
						disabled={selectedInvoices.length <= 0}
						onClick={handleLogFinalItems}
					>
						<Send /> {t("actions.send")}
					</Button>
				)}
			</div>
		</div>
	)
}
