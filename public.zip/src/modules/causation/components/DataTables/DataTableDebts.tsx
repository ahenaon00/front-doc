import React from "react"
import {
	ColumnDef,
	ColumnFiltersState,
	flexRender,
	getCoreRowModel,
	getFilteredRowModel,
	getPaginationRowModel,
	getSortedRowModel,
	SortingState,
	useReactTable,
} from "@tanstack/react-table"
import { Input } from "@/modules/common/components/ui/input"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import { useTranslation } from "react-i18next"
import {
	Pagination,
	PaginationContent,
	PaginationEllipsis,
	PaginationItem,
	PaginationLink,
	PaginationNext,
	PaginationPrevious,
} from "@/modules/common/components/ui/pagination"
import { useNavigate } from "react-router-dom"
import { Button } from "@/modules/common/components/ui/button"
import { ChevronRight, CircleOff } from "lucide-react"
import { formatNumber } from "@/modules/common/lib/utils/formatNumber"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/modules/common/components/ui/tooltip"

interface Props {
	data: any
}

export function DataTableDebts({ data }: Props) {
	const [sorting, setSorting] = React.useState<SortingState>([])
	const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
	const [columnVisibility, setColumnVisibility] = React.useState({})
	const [rowSelection, setRowSelection] = React.useState({})
	const [globalFilter, setGlobalFilter] = React.useState("")
	const { t } = useTranslation(["debts"])
	const navigate = useNavigate()

	const columns: ColumnDef<any>[] = [
		{
			accessorKey: "id",
			header: () => <div>{t("table.nit")}</div>,
			cell: ({ row }) => row.getValue("id"),
		},
		{
			accessorKey: "company",
			header: () => <div>{t("table.company")}</div>,
			cell: ({ row }) => <div className="capitalize">{row.getValue("company")}</div>,
		},
		{
			accessorKey: "deposit",
			header: () => <div>{t("table.deposit")}</div>,
			cell: ({ row }) => <div>{formatNumber(row.getValue("deposit"))}</div>,
		},
		{
			accessorKey: "debt",
			header: () => <div>{t("table.debt")}</div>,
			cell: ({ row }) => <div>{formatNumber(row.getValue("debt"))}</div>,
		},
		{
			accessorKey: "total",
			header: () => <div className="text-right">{t("table.total")}</div>,
			cell: ({ row }) => <div className="text-right">{formatNumber(row.getValue("total"))}</div>,
		},
		{
			id: "actions",
			enableHiding: false,
			cell: ({ row }) => (
				<div className="w-fit ml-auto flex items-center">
					{row.original.hasInvoices ? (
						<Button
							variant="ghost"
							className="h-8 w-8 p-0"
							onClick={() => navigate(`/consolidated-info/${row.original.mongoId}`)}
						>
							<ChevronRight className="stroke-primary-grey-1600" />
						</Button>
					) : (
						<TooltipProvider>
							<Tooltip>
								<TooltipTrigger asChild>
									<Button variant="ghost" className="h-8 w-8 p-0">
										<CircleOff className="stroke-semantic-red-1200" />
									</Button>
								</TooltipTrigger>
								<TooltipContent>
									<div className="p-2 text-center bg-white text-primary-grey-1800">
										{t("labels.noInvoices")}
									</div>
								</TooltipContent>
							</Tooltip>
						</TooltipProvider>
					)}
				</div>
			),
		},
	]

	const table = useReactTable({
		data,
		columns,
		onSortingChange: setSorting,
		onColumnFiltersChange: setColumnFilters,
		getCoreRowModel: getCoreRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		getSortedRowModel: getSortedRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		onColumnVisibilityChange: setColumnVisibility,
		onRowSelectionChange: setRowSelection,
		state: {
			sorting,
			columnFilters,
			columnVisibility,
			rowSelection,
			globalFilter,
		},
	})

	return (
		<div className="w-full">
			<div className="flex w-full mb-2">
				<div className="flex flex-grow">
					<Input
						type="text"
						placeholder={t("labels.inputPlaceholder")}
						variant="search"
						className="h-8 text-sm w-1/2"
						autoComplete="off"
						spellCheck="false"
						value={globalFilter}
						onChange={(event) => {
							setGlobalFilter(event.target.value)
						}}
					/>
				</div>
			</div>
			<Table>
				<TableHeader>
					{table.getHeaderGroups().map((headerGroup) => (
						<TableRow key={headerGroup.id}>
							{headerGroup.headers.map((header) => {
								return (
									<TableHead key={header.id}>
										{header.isPlaceholder
											? null
											: flexRender(header.column.columnDef.header, header.getContext())}
									</TableHead>
								)
							})}
						</TableRow>
					))}
				</TableHeader>
				<TableBody>
					{table.getRowModel().rows?.length ? (
						table.getRowModel().rows.map((row) => (
							<TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
								{row.getVisibleCells().map((cell) => (
									<TableCell key={cell.id}>
										{flexRender(cell.column.columnDef.cell, cell.getContext())}
									</TableCell>
								))}
							</TableRow>
						))
					) : (
						<TableRow>
							<TableCell colSpan={columns.length} className="h-24 text-center">
								No results.
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
			<Pagination className="mt-2">
				<PaginationContent>
					<PaginationItem>
						<PaginationPrevious
							onClick={() => {
								if (table.getCanPreviousPage()) table.previousPage()
							}}
							disabled={!table.getCanPreviousPage()}
							displayName={t("pagination.previous")}
						/>
					</PaginationItem>
					{table.getState().pagination.pageIndex > 1 && (
						<>
							<PaginationItem>
								<PaginationLink onClick={() => table.setPageIndex(0)}>1</PaginationLink>
							</PaginationItem>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
						</>
					)}
					{table.getState().pagination.pageIndex > 0 && (
						<PaginationItem>
							<PaginationLink
								onClick={() => table.setPageIndex(table.getState().pagination.pageIndex - 1)}
							>
								{table.getState().pagination.pageIndex}
							</PaginationLink>
						</PaginationItem>
					)}
					<PaginationItem>
						<PaginationLink isActive>{table.getState().pagination.pageIndex + 1}</PaginationLink>
					</PaginationItem>
					{table.getPageCount() >= table.getState().pagination.pageIndex + 2 && (
						<PaginationItem>
							<PaginationLink
								onClick={() => table.setPageIndex(table.getState().pagination.pageIndex + 1)}
							>
								{table.getState().pagination.pageIndex + 2}
							</PaginationLink>
						</PaginationItem>
					)}
					{table.getPageCount() > table.getState().pagination.pageIndex + 2 && (
						<>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
							<PaginationItem>
								<PaginationLink onClick={() => table.setPageIndex(table.getPageCount() - 1)}>
									{table.getPageCount()}
								</PaginationLink>
							</PaginationItem>
						</>
					)}
					<PaginationItem>
						<PaginationNext
							onClick={() => {
								if (table.getCanNextPage()) table.nextPage()
							}}
							disabled={!table.getCanNextPage()}
							displayName={t("pagination.next")}
						/>
					</PaginationItem>
				</PaginationContent>
			</Pagination>
		</div>
	)
}
