import { useEffect, useState } from "react"
import {
	ColumnDef,
	ColumnFiltersState,
	flexRender,
	getCoreRowModel,
	getFilteredRowModel,
	getPaginationRowModel,
	getSortedRowModel,
	SortingState,
	useReactTable,
} from "@tanstack/react-table"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import {
	Pagination,
	PaginationContent,
	PaginationEllipsis,
	PaginationItem,
	PaginationLink,
	PaginationNext,
	PaginationPrevious,
} from "@/modules/common/components/ui/pagination"
import {
	Tooltip,
	TooltipArrow,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger,
} from "@radix-ui/react-tooltip"
import { useNavigate } from "react-router-dom"
import { useTranslation } from "react-i18next"
import { ChevronsUpDown, HelpCircle } from "lucide-react"
interface Props {
	data: any[]
}

export function VendorDebtTable({ data }: Props) {
	const { t } = useTranslation(["invoice"])
	console.log("🚀 ~ VendorDebtTable ~ data:", data)
	const [sorting, setSorting] = useState<SortingState>([])
	const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([])
	const [columnVisibility, setColumnVisibility] = useState({})
	const [rowSelection, setRowSelection] = useState({})
	const [page, setPage] = useState(0)

	const StatusCell = ({
		status,
		errorMessage,
		invoiceId,
	}: {
		status: number
		errorMessage?: string
		invoiceId?: string
	}) => {
		const [menuOpen, setMenuOpen] = useState(false)
		const navigation = useNavigate()
		const handleViewInvoice = () => {
			navigation(`/invoice/${invoiceId}`)
			setMenuOpen(false)
		}

		useEffect(() => {
			const handleClickOutside = (event: MouseEvent) => {
				const target = event.target as HTMLElement
				if (!target.closest(".dropdown-menu")) {
					setMenuOpen(false)
				}
			}

			if (menuOpen) {
				document.addEventListener("mousedown", handleClickOutside)
			}

			return () => {
				document.removeEventListener("mousedown", handleClickOutside)
			}
		}, [menuOpen])

		let content = "Pendiente"
		let bg = "bg-gray-200"
		let text = "text-gray-700"

		if (status === 200) {
			content = t("labels.typeClasified")
			bg = "bg-green-200"
			text = "text-green-800"
		} else if (status >= 409) {
			content = t("labels.typeRejected")
			bg = "bg-red-200"
			text = "text-red-800"
		}

		return (
			<div className="flex items-center w-full relative">
				{/* Badge */}
				<span
					className={`p-1 px-2 rounded-full text-sm font-medium whitespace-nowrap ${bg} ${text}`}
				>
					{content}
				</span>

				{/* Tooltip si error */}
				{status >= 400 && errorMessage && (
					<TooltipProvider>
						<Tooltip>
							<TooltipTrigger asChild>
								<button tabIndex={0} className="ml-2" aria-label="Ver error">
									<HelpCircle className="size-4 text-semantic-red-1600 cursor-pointer" />
								</button>
							</TooltipTrigger>
							<TooltipContent
								side="top"
								sideOffset={5}
								className="bg-white border border-red-500 rounded-md p-2 max-w-xs text-sm text-black shadow-md"
							>
								{String(errorMessage)}
								<TooltipArrow className="fill-white" />
							</TooltipContent>
						</Tooltip>
					</TooltipProvider>
				)}

				{/* Menú contextual si status === 200 */}
				{status === 200 && (
					<div className="dropdown-menu relative ml-2">
						<button
							onClick={() => setMenuOpen(!menuOpen)}
							className="text-gray-500 hover:text-gray-800"
						>
							<span className="text-lg">⋯</span>
						</button>

						{menuOpen && (
							<div className="absolute right-0 mt-2 w-40 bg-white border border-gray-300 rounded-md shadow-lg z-50">
								<ul className="py-1">
									<li>
										<button
											onClick={handleViewInvoice}
											className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 z-10"
										>
											{t("labels.seeInvoice")}
										</button>
									</li>
								</ul>
							</div>
						)}
					</div>
				)}
			</div>
		)
	}

	interface VendorDebtRow {
		[x: string]: any
		name: string
		status: number
		errorMessage?: string
	}

	const columns: ColumnDef<VendorDebtRow>[] = [
		{
			accessorKey: "name",
			header: "Invoice",
			cell: ({ row }) => row.getValue("name"),
		},
		{
			accessorKey: "status",
			header: "Status",
			cell: ({ row }) => (
				<StatusCell
					status={row.getValue("status")}
					errorMessage={row.original?.description}
					invoiceId={row.original?.invoiceId}
				/>
			),
		},
		{
			accessorKey: "date",
			header: ({ column }) => {
				const sortState = column.getIsSorted()

				return (
					<div
						className="flex items-center gap-1 cursor-pointer select-none"
						onClick={column.getToggleSortingHandler()}
					>
						{t("labels.DateUpload")}
						{sortState === "asc" && <ChevronsUpDown className="size-4" />}
						{sortState === "desc" && <ChevronsUpDown className="size-4" />}
						{!sortState && <ChevronsUpDown className="size-4 opacity-50" />}
					</div>
				)
			},
			cell: ({ row }) => {
				return row.getValue("date")
			},
			sortingFn: (rowA, rowB, columnId) => {
				const parseDate = (value: string) => {
					if (!value) return 0

					const [datePart, timePart] = value.split(", ")
					const [day, month, year] = datePart.split("/")
					const [time, meridian] = timePart.split(" ")
					let [hours, minutes] = time.split(":")

					let parsedHours = parseInt(hours)
					if (meridian.toLowerCase().includes("p") && parsedHours < 12) {
						parsedHours += 12
					} else if (meridian.toLowerCase().includes("a") && parsedHours === 12) {
						parsedHours = 0
					}

					return new Date(
						Number("20" + year),
						Number(month) - 1,
						Number(day),
						parsedHours,
						Number(minutes),
					).getTime()
				}

				const valueA = rowA.getValue(columnId)
				const valueB = rowB.getValue(columnId)
				const dateA = parseDate(valueA as string)
				const dateB = parseDate(valueB as string)

				return dateA - dateB
			},
		},
	]

	const table = useReactTable({
		data,
		columns,
		onSortingChange: setSorting,
		onColumnFiltersChange: setColumnFilters,
		getCoreRowModel: getCoreRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		getSortedRowModel: getSortedRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		onColumnVisibilityChange: setColumnVisibility,
		onRowSelectionChange: setRowSelection,
		state: {
			sorting,
			columnFilters,
			columnVisibility,
			rowSelection,
			pagination: {
				pageIndex: page,
				pageSize: 10,
			},
		},
	})

	console.log(table)

	return (
		<div className="w-full">
			<Table>
				<TableHeader>
					{table.getHeaderGroups().map((headerGroup) => (
						<TableRow key={headerGroup.id}>
							{headerGroup.headers.map((header) => (
								<TableHead key={header.id}>
									{header.isPlaceholder
										? null
										: flexRender(header.column.columnDef.header, header.getContext())}
								</TableHead>
							))}
						</TableRow>
					))}
				</TableHeader>
				<TableBody>
					{table.getRowModel().rows?.length ? (
						table.getRowModel().rows.map((row) => (
							<TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
								{row.getVisibleCells().map((cell) => (
									<TableCell key={cell.id}>
										{flexRender(cell.column.columnDef.cell, cell.getContext())}
									</TableCell>
								))}
							</TableRow>
						))
					) : (
						<TableRow>
							<TableCell colSpan={columns.length} className="h-24 text-center">
								Sin resultados.
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
			<Pagination className="mt-2">
				<PaginationContent>
					<PaginationItem>
						<PaginationPrevious
							onClick={() => table.getCanPreviousPage() && setPage(page - 1)}
							disabled={!table.getCanPreviousPage()}
							displayName="Anterior"
						/>
					</PaginationItem>
					{page > 1 && (
						<>
							<PaginationItem>
								<PaginationLink onClick={() => setPage(0)}>1</PaginationLink>
							</PaginationItem>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
						</>
					)}
					{page > 0 && (
						<PaginationItem>
							<PaginationLink onClick={() => setPage(page - 1)}>{page}</PaginationLink>
						</PaginationItem>
					)}
					<PaginationItem>
						<PaginationLink isActive>{page + 1}</PaginationLink>
					</PaginationItem>
					{table.getPageCount() >= page + 2 && (
						<PaginationItem>
							<PaginationLink onClick={() => setPage(page + 1)}>{page + 2}</PaginationLink>
						</PaginationItem>
					)}
					{table.getPageCount() > page + 2 && (
						<>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
							<PaginationItem>
								<PaginationLink onClick={() => setPage(table.getPageCount() - 1)}>
									{table.getPageCount()}
								</PaginationLink>
							</PaginationItem>
						</>
					)}
					<PaginationItem>
						<PaginationNext
							onClick={() => table.getCanNextPage() && setPage(page + 1)}
							disabled={!table.getCanNextPage()}
							displayName="Siguiente"
						/>
					</PaginationItem>
				</PaginationContent>
			</Pagination>
		</div>
	)
}
