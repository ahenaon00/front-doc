import { useState } from "react"
import {
	ColumnDef,
	ColumnFiltersState,
	flexRender,
	getCoreRowModel,
	getFilteredRowModel,
	getPaginationRowModel,
	getSortedRowModel,
	SortingState,
	useReactTable,
} from "@tanstack/react-table"
import { ToastContainer } from "react-toastify"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import { useTranslation } from "react-i18next"
import {
	Pagination,
	PaginationContent,
	PaginationEllipsis,
	PaginationItem,
	PaginationLink,
	PaginationNext,
	PaginationPrevious,
} from "@/modules/common/components/ui/pagination"

interface Props {
	data: any
}

export function DataTableSentInvoices({ data }: Props) {
	const [sorting, setSorting] = useState<SortingState>([])
	const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([])
	const [columnVisibility, setColumnVisibility] = useState({})
	const [rowSelection, setRowSelection] = useState({})
	const [page, setPage] = useState(0)

	const { t } = useTranslation(["causation"])

	const columns: ColumnDef<any>[] = [
		{
			accessorKey: "id",
			header: () => t("sentInvoices.invoice"),
			cell: ({ row }) => row.getValue("id"),
		},
		{
			accessorKey: "provider",
			header: () => t("sentInvoices.provider"),
			cell: ({ row }) => row.getValue("provider"),
		},
		{
			accessorKey: "sentDate",
			header: () => {
				return t("sentInvoices.sentDate")
			},
			cell: ({ row }) => row.getValue("sentDate"),
		},
		{
			accessorKey: "paymentMethod",
			header: () => <div className="text-right">{t("sentInvoices.paymentMethod")}</div>,
			cell: ({ row }) => (
				<div className="capitalize text-right">{row.getValue("paymentMethod")}</div>
			),
		},
	]
	const table = useReactTable({
		data,
		columns,
		onSortingChange: setSorting,
		onColumnFiltersChange: setColumnFilters,
		getCoreRowModel: getCoreRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		getSortedRowModel: getSortedRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		onColumnVisibilityChange: setColumnVisibility,
		onRowSelectionChange: setRowSelection,
		state: {
			sorting,
			columnFilters,
			columnVisibility,
			rowSelection,
			pagination: {
				pageIndex: page,
				pageSize: 15,
			},
		},
	})

	return (
		<div className="w-full">
			<Table>
				<TableHeader>
					{table.getHeaderGroups().map((headerGroup) => (
						<TableRow key={headerGroup.id}>
							{headerGroup.headers.map((header) => {
								return (
									<TableHead key={header.id}>
										{header.isPlaceholder
											? null
											: flexRender(header.column.columnDef.header, header.getContext())}
									</TableHead>
								)
							})}
						</TableRow>
					))}
				</TableHeader>
				<TableBody>
					{table.getRowModel().rows?.length ? (
						table.getRowModel().rows.map((row) => (
							<TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
								{row.getVisibleCells().map((cell) => (
									<TableCell key={cell.id}>
										{flexRender(cell.column.columnDef.cell, cell.getContext())}
									</TableCell>
								))}
							</TableRow>
						))
					) : (
						<TableRow>
							<TableCell colSpan={columns.length} className="h-24 text-center">
								No results.
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
			<Pagination className="mt-2">
				<PaginationContent>
					<PaginationItem>
						<PaginationPrevious
							onClick={() => {
								if (table.getCanPreviousPage()) setPage(page - 1)
							}}
							disabled={!table.getCanPreviousPage()}
							displayName={t("pagination.previous")}
						/>
					</PaginationItem>
					{page > 1 && (
						<>
							<PaginationItem>
								<PaginationLink onClick={() => setPage(0)}>1</PaginationLink>
							</PaginationItem>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
						</>
					)}
					{page > 0 && (
						<PaginationItem>
							<PaginationLink onClick={() => setPage(page - 1)}>{page}</PaginationLink>
						</PaginationItem>
					)}
					<PaginationItem>
						<PaginationLink isActive>{page + 1}</PaginationLink>
					</PaginationItem>
					{table.getPageCount() >= page + 2 && (
						<PaginationItem>
							<PaginationLink onClick={() => setPage(page + 1)}>{page + 2}</PaginationLink>
						</PaginationItem>
					)}
					{table.getPageCount() > page + 2 && (
						<>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
							<PaginationItem>
								<PaginationLink onClick={() => setPage(table.getPageCount() - 1)}>
									{table.getPageCount()}
								</PaginationLink>
							</PaginationItem>
						</>
					)}
					<PaginationItem>
						<PaginationNext
							onClick={() => {
								if (table.getCanNextPage()) setPage(page + 1)
							}}
							disabled={!table.getCanNextPage()}
							displayName={t("pagination.next")}
						/>
					</PaginationItem>
				</PaginationContent>
			</Pagination>
			<ToastContainer />
		</div>
	)
}