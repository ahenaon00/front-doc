import { useId, useState } from "react"
import {
	ColumnDef,
	ColumnFiltersState,
	flexRender,
	getCoreRowModel,
	getFilteredRowModel,
	getPaginationRowModel,
	getSortedRowModel,
	SortingState,
	useReactTable,
} from "@tanstack/react-table"
import { ArrowUpDown, ChevronRight, Download, Trash2 } from "lucide-react"
import { ToastContainer } from "react-toastify"
import { Button } from "@/modules/common/components/ui/button"
import { Checkbox } from "@/modules/common/components/ui/checkbox"
import { Input } from "@/modules/common/components/ui/input"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import { RadioGroup, RadioGroupItem } from "@/modules/common/components/ui/radio-group"
import { Label } from "@/modules/common/components/ui/label"
import { useTranslation } from "react-i18next"
import {
	Pagination,
	PaginationContent,
	PaginationEllipsis,
	PaginationItem,
	PaginationLink,
	PaginationNext,
	PaginationPrevious,
} from "@/modules/common/components/ui/pagination"
import { deleteFile } from "@/modules/causation/services/file"
import { getAllNotUploadedInvoicesERP, getHydratedInvoices } from "@/modules/causation/services/invoice"
import { getIntegrationbyUID } from "../../../auth/services/integrations"
import { useNavigate } from "react-router-dom"
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger,
} from "@/modules/common/components/ui/tooltip"
import { toast } from "sonner"
import {
	getIntegrationfindByUID,
} from "@/modules/causation/services/integrations"
import { ExportTemplateDialog } from "../Dialogs/ExportTemplateDialog"
import { UploadToERPDialog } from "../Dialogs/UploadToERPDialog"

interface Props {
	data: any
	setData: any
	pageSize?: number
}

export function DataTableInvoices({ data, setData, pageSize = 10 }: Props) {
	const [sorting, setSorting] = useState<SortingState>([])
	const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([])
	const [columnVisibility, setColumnVisibility] = useState({})
	const [rowSelection, setRowSelection] = useState({})
	const [radioGroupValue, setRadioGroupValue] = useState("")
	const [page, setPage] = useState(0)
	const [globalFilter, setGlobalFilter] = useState("")
	const [selectedInvoices, setSelectedInvoices] = useState<any[]>([]) // Facturas seleccionadas
	const [selectedInvoiceDetails, setSelectedInvoiceDetails] = useState<any[]>([]) // Detalles de las facturas seleccionadas

	const [showTemplateDialog, setShowTemplateDialog] = useState(false)
	const [dialogAction, setDialogAction] = useState<"download" | "sendToERP">("sendToERP")
	const [showUploadDialog, setShowUploadDialog] = useState(false)


	const { t } = useTranslation(["invoicesNotSent"])
	const navigate = useNavigate()

	const idR1 = useId()
	const idR2 = useId()

	const validateCreds = async () => {
		try {
			await getIntegrationbyUID()
			return true
		} catch (error) {
			console.error("Error validating credentials:", error)
			return false
		}
	}
	const handleUpload = async (download: boolean = false) => {
		console.log("entre aca")
		setSelectedInvoiceDetails([])
		const invoiceDetails = []
		try {
			if (await validateCreds()) {
				// Get only selected invoices based on rowSelection
				const actualSelectedInvoices = selectedInvoices

				if (actualSelectedInvoices.length === 0) {
					toast.warning("No hay facturas seleccionadas.")
					return
				}
				console.log("ACTUAL SELECTED", actualSelectedInvoices)




				// Get integration configuration
				try {
					const integrationResponse = await getIntegrationfindByUID()

					// Check if we have a valid integration response
					if (!integrationResponse) {
						toast.error("No se pudo obtener la configuración de integración.")
						return
					}

					// Extract the integration object - it appears the response IS the data
					const integration = integrationResponse
					const integrationType = integration.name // Use 'name' field as type based on your console log

					// Validate integration type exists
					if (!integrationType) {
						toast.warning("Tipo de integración no definido. Verifique la configuración.")
						return
					}

					if (integration?.onPremise || download) {
						try {
							const invoiceIds = actualSelectedInvoices.map((invoice) => invoice.mongoId)

							if (invoiceIds.length === 0) {
								toast.warning("No hay facturas seleccionadas.")
								return
							}

							const response = await getHydratedInvoices(invoiceIds)
							console.log(response)

							if (response.success && response.data.length > 0) {
								console.log("Hydrated Invoices:", response.data)
								setSelectedInvoiceDetails(response.data)
								setDialogAction("sendToERP")
								setShowTemplateDialog(true)
							} else {
								toast.error("No se pudo hidratar las facturas seleccionadas.")
							}
						} catch (error) {
							console.error("Error al obtener facturas hidratadas:", error)
							toast.error("Ocurrió un error al obtener las facturas.")
						}
					} else {
						for (const invoice of actualSelectedInvoices) {
							try {
								const response = await getAllNotUploadedInvoicesERP(invoice.mongoId)

								if (response && response.data && response.data.length > 0) {
									invoiceDetails.push(...response.data)
								} else {
									console.log(
										"La factura",
										invoice.mongoId,
										"ya fue subida al ERP o no devolvió datos",
									)
								}
							} catch (error) {
								console.error(
									`Error al obtener información de la factura con ID ${invoice.mongoId}:`,
									error,
								)
							}
						}

						if (invoiceDetails.length > 0) {
							console.log(invoiceDetails)
							setSelectedInvoiceDetails(invoiceDetails) // Send invoices to popup
						} else {
							toast.error(
								"Las facturas seleccionadas ya fueron subidas al ERP o no se pudo obtener su información.",
							)
						}
						setShowUploadDialog(true)
					}
				} catch (integrationError) {
					console.error("Error al obtener la configuración de integración:", integrationError)
					toast.error(
						"Error al obtener la configuración de integración: " +
						(integrationError instanceof Error ? integrationError.message : "Error desconocido"),
					)
				}
			} else {
				toast.error("Por favor, configure las credenciales de Siigo.")
			}
		} catch (error) {
			console.error("Error al procesar las facturas para el ERP:", error)
			toast.error(
				"Ocurrió un error al procesar las facturas: " +
				(error instanceof Error ? error.message : "Error desconocido"),
			)
		}


	}




	const handleRowSelectionChange = (row: any, isSelected: boolean) => {
		setSelectedInvoices((prev) =>
			isSelected ? [...prev, row] : prev.filter((item) => item.mongoId !== row.mongoId),
		)
	}

	const deleteInvoices = async (id: string) => {
		try {
			await deleteFile(id)
		} catch (error) {
			console.error("Error deleting invoice:", error)
		}
	}

	const columns: ColumnDef<any>[] = [
		{
			id: "select",
			header: ({ table }) => (
				<Checkbox
					checked={
						table.getIsAllRowsSelected() || (table.getIsSomeRowsSelected() && "indeterminate")
					}
					onCheckedChange={(value) => {
						table.toggleAllRowsSelected(!!value)
						setSelectedInvoices(value ? Object.values(table.getRowModel().rowsById).map((row) => row.original) : [])
					}}
					aria-label="Select all"
				/>
			),
			cell: ({ row }) => (
				<Checkbox
					checked={row.getIsSelected()}
					onCheckedChange={(value) => {
						row.toggleSelected(!!value)
						handleRowSelectionChange(row.original, !!value)
					}}
					aria-label="Select row"
				/>
			),
			enableSorting: false,
			enableHiding: false,
		},
		{
			accessorKey: "id",
			header: () => <div className="w-52">{t("table.invoice")}</div>,
			cell: ({ row }) => row.getValue("id"),
		},
		{
			accessorKey: "creationDate",
			header: ({ column }) => {
				return (
					<Button
						variant="ghost"
						onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
					>
						{t("table.creationDate")}
						<ArrowUpDown />
					</Button>
				)
			},
			cell: ({ row }) => <div className="ml-4">{row.getValue("creationDate")}</div>,
		},
		{
			accessorKey: "paymentMethod",
			header: () => <div className="text-right">{t("table.paymentMethod")}</div>,
			cell: ({ row }) => (
				<div className="capitalize text-right">{row.getValue("paymentMethod")}</div>
			),
		},
		{
			id: "actions",
			enableHiding: false,
			header: () => <div className="w-8"></div>,
			cell: ({ row }) => {
				const payment = row.original

				return (
					<div className="w-fit ml-auto flex items-center">
						<Button
							variant="ghost"
							className="h-8 w-8 p-0"
							onClick={() => navigate(`/invoice/${payment.mongoId}`)}
						>
							<ChevronRight className="stroke-primary-grey-1600" />
						</Button>
					</div>
				)
			},
		},
	]
	const table = useReactTable({
		data,
		columns,
		onSortingChange: setSorting,
		onColumnFiltersChange: setColumnFilters,
		getCoreRowModel: getCoreRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		getSortedRowModel: getSortedRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		onColumnVisibilityChange: setColumnVisibility,
		onRowSelectionChange: setRowSelection,
		state: {
			sorting,
			columnFilters,
			columnVisibility,
			rowSelection,
			globalFilter,
			pagination: {
				pageIndex: page,
				pageSize,
			},
		},
	})

	return (
		<div className="w-full">
			<div className="flex w-full mb-2">
				<div className="flex flex-grow">
					<RadioGroup
						className="flex"
						value={radioGroupValue}
						onClick={(event) => {
							const target = event.target as HTMLInputElement
							if (target.tagName === "LABEL" && !target.value) return
							if (!target.value || target.value === radioGroupValue) {
								table.getColumn("paymentMethod")?.setFilterValue("")
								setRadioGroupValue("")
							} else {
								table.getColumn("paymentMethod")?.setFilterValue(target.value)
								setRadioGroupValue(target.value)
							}
						}}
					>
						<div className="flex items-center">
							<RadioGroupItem value={t("labels.cash")} id={idR1} />
							<Label htmlFor={idR1}>{t("labels.cash")}</Label>
						</div>
						<div className="flex items-center">
							<RadioGroupItem value={t("labels.credit")} id={idR2} />
							<Label htmlFor={idR2}>{t("labels.credit")}</Label>
						</div>
					</RadioGroup>
					<div className="w-full flex items-center ml-3 sm:ml-2 lg:mr-20 mr-10">
						<Input
							type="text"
							placeholder={t("inputPlaceholder")}
							variant="search"
							className="h-8 text-sm w-full sm:w-3/4 md:w-full"
							autoComplete="off"
							spellCheck="false"
							value={globalFilter}
							onChange={(event) => setGlobalFilter(event.target.value)}
						/>
					</div>
				</div>
				<div className="flex gap-3 items-center justify-end ml-auto">
					<Button
						variant="ghost"
						className="h-6 w-6 [&_svg]:size-6 hover:bg-transparent hover:scale-110 p-0 transition-transform duration-300 ease-in-out cursor-pointer"
						onClick={() => {
							handleUpload(true)
						}}
					>
						<Download />
					</Button>
					<Button
						variant="ghost"
						className="h-6 w-6 [&_svg]:size-6 hover:bg-transparent p-0 hover:scale-110 transition-transform duration-300 ease-in-out cursor-pointer"
						onClick={() => {
							table.getSelectedRowModel().rows.forEach((row) => {
								setData((prev: any) =>
									prev.filter((item: any) => item.mongoId !== row.original.mongoId),
								)
								deleteInvoices(row.original.mongoId)
							})
							table.resetRowSelection()
						}}
					>
						<Trash2 className="stroke-semantic-red-1200" />
					</Button>
					<TooltipProvider>
						<Tooltip>
							<TooltipTrigger>

								<Button
									variant="primary"
									onClick={() => { handleUpload() }}
									disabled={selectedInvoices.length === 0}
								>
									{t("button.send")}
								</Button>

								<UploadToERPDialog open={showUploadDialog} onClose={() => setShowUploadDialog(false)} selectedInvoiceDetails={selectedInvoiceDetails} setSelectedInvoiceDetails={setSelectedInvoiceDetails} />
								<ExportTemplateDialog
									open={showTemplateDialog}
									onClose={() => setShowTemplateDialog(false)}
									action={dialogAction}
									onTemplateSelected={(template) => {
										console.log("Selected template:", template)
									}}
									invoices={selectedInvoiceDetails}
								/>


							</TooltipTrigger>
							<TooltipContent>
								{selectedInvoices.length === 0 && (
									<div className="bg-primary-grey-50 text-primary-grey-1000 p-2 rounded-md">
										{t("tooltipSendERP")}
									</div>
								)}
							</TooltipContent>
						</Tooltip>
					</TooltipProvider>
				</div>
			</div>
			<Table>
				<TableHeader>
					{table.getHeaderGroups().map((headerGroup) => (
						<TableRow key={headerGroup.id}>
							{headerGroup.headers.map((header) => {
								return (
									<TableHead key={header.id} id={header.id}>
										{header.isPlaceholder
											? null
											: flexRender(header.column.columnDef.header, header.getContext())}
									</TableHead>
								)
							})}
						</TableRow>
					))}
				</TableHeader>
				<TableBody>
					{table.getRowModel().rows?.length ? (
						table.getRowModel().rows.map((row) => (
							<TableRow key={row.id} id={row.id} data-state={row.getIsSelected() && "selected"}>
								{row.getVisibleCells().map((cell) => (
									<TableCell key={cell.id}>
										{flexRender(cell.column.columnDef.cell, cell.getContext())}
									</TableCell>
								))}
							</TableRow>
						))
					) : (
						<TableRow>
							<TableCell colSpan={columns.length} className="h-24 text-center">
								No results.
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
			<Pagination className="mt-2">
				<PaginationContent>
					<PaginationItem>
						<PaginationPrevious
							onClick={() => {
								if (table.getCanPreviousPage()) setPage(page - 1)
							}}
							disabled={!table.getCanPreviousPage()}
							displayName={t("pagination.previous")}
						/>
					</PaginationItem>
					{page > 1 && (
						<>
							<PaginationItem>
								<PaginationLink onClick={() => setPage(0)}>1</PaginationLink>
							</PaginationItem>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
						</>
					)}
					{page > 0 && (
						<PaginationItem>
							<PaginationLink onClick={() => setPage(page - 1)}>{page}</PaginationLink>
						</PaginationItem>
					)}
					<PaginationItem>
						<PaginationLink isActive>{page + 1}</PaginationLink>
					</PaginationItem>
					{table.getPageCount() >= page + 2 && (
						<PaginationItem>
							<PaginationLink onClick={() => setPage(page + 1)}>{page + 2}</PaginationLink>
						</PaginationItem>
					)}
					{table.getPageCount() > page + 2 && (
						<>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
							<PaginationItem>
								<PaginationLink onClick={() => setPage(table.getPageCount() - 1)}>
									{table.getPageCount()}
								</PaginationLink>
							</PaginationItem>
						</>
					)}
					<PaginationItem>
						<PaginationNext
							onClick={() => {
								if (table.getCanNextPage()) setPage(page + 1)
							}}
							disabled={!table.getCanNextPage()}
							displayName={t("pagination.next")}
						/>
					</PaginationItem>
				</PaginationContent>
			</Pagination>
			<ToastContainer />
		</div>
	)
}
