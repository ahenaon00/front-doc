import React from "react"
import {
	ColumnDef,
	ColumnFiltersState,
	flexRender,
	getCoreRowModel,
	getFilteredRowModel,
	getPaginationRowModel,
	getSortedRowModel,
	SortingState,
	useReactTable,
} from "@tanstack/react-table"
import { Input } from "@/modules/common/components/ui/input"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import { useTranslation } from "react-i18next"
import {
	Pagination,
	PaginationContent,
	PaginationEllipsis,
	PaginationItem,
	PaginationLink,
	PaginationNext,
	PaginationPrevious,
} from "@/modules/common/components/ui/pagination"
import { formatNumber } from "@/modules/common/lib/utils/formatNumber"

interface Props {
	data: any[]
}

export function DataTableDianTokenInfo({ data }: Props) {
	const [sorting, setSorting] = React.useState<SortingState>([])
	const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
	const [columnVisibility, setColumnVisibility] = React.useState({})
	const [rowSelection, setRowSelection] = React.useState({})
	const [globalFilter, setGlobalFilter] = React.useState("")
	const { t } = useTranslation(["causation"])

	const columns: ColumnDef<any>[] = [
		{
			accessorKey: "cufe",
			header: t("labels.cufe"),
			cell: ({ row }) => {
				const cufe = row.getValue("cufe") as string;
				return <div className="line-clamp-1">{cufe.substring(0, 20) + "..."}</div>;
			},
		},
		{
			accessorKey: "nit",
			header: t("labels.nit"),
			cell: ({ row }) => row.getValue("nit"),
		},
		{
			accessorKey: "provider",
			header: t("labels.provider"),
			cell: ({ row }) => <div className="capitalize">{row.getValue("provider")}</div>,
		},
		{
			accessorKey: "total",
			header: () => <div className="text-right">{t("labels.total")}</div>,
			cell: ({ row }) => <div className="text-right">{formatNumber(row.getValue("total"))}</div>,
		},
	]

	const table = useReactTable({
		data,
		columns,
		onSortingChange: setSorting,
		onColumnFiltersChange: setColumnFilters,
		getCoreRowModel: getCoreRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		getSortedRowModel: getSortedRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		onColumnVisibilityChange: setColumnVisibility,
		onRowSelectionChange: setRowSelection,
		state: {
			sorting,
			columnFilters,
			columnVisibility,
			rowSelection,
			globalFilter,
		},
	})

	return (
		<div className="w-full">
			<div className="flex w-full mb-2">
				<div className="flex flex-grow">
					<Input
						type="text"
						placeholder={t("labels.inputPlaceholder")}
						variant="search"
						className="h-8 text-sm w-1/2"
						autoComplete="off"
						spellCheck="false"
						value={globalFilter}
						onChange={(event) => {
							setGlobalFilter(event.target.value)
						}}
					/>
				</div>
			</div>
			<Table>
				<TableHeader>
					{table.getHeaderGroups().map((headerGroup) => (
						<TableRow key={headerGroup.id}>
							{headerGroup.headers.map((header) => {
								return (
									<TableHead key={header.id}>
										{header.isPlaceholder
											? null
											: flexRender(header.column.columnDef.header, header.getContext())}
									</TableHead>
								)
							})}
						</TableRow>
					))}
				</TableHeader>
				<TableBody>
					{table.getRowModel().rows?.length ? (
						table.getRowModel().rows.map((row) => (
							<TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
								{row.getVisibleCells().map((cell) => (
									<TableCell key={cell.id}>
										{flexRender(cell.column.columnDef.cell, cell.getContext())}
									</TableCell>
								))}
							</TableRow>
						))
					) : (
						<TableRow>
							<TableCell colSpan={columns.length} className="h-24 text-center">
								No results.
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
			<Pagination className="mt-2">
				<PaginationContent>
					<PaginationItem>
						<PaginationPrevious
							onClick={() => {
								if (table.getCanPreviousPage()) table.previousPage()
							}}
							disabled={!table.getCanPreviousPage()}
							displayName={t("pagination.previous")}
						/>
					</PaginationItem>
					{table.getState().pagination.pageIndex > 1 && (
						<>
							<PaginationItem>
								<PaginationLink onClick={() => table.setPageIndex(0)}>1</PaginationLink>
							</PaginationItem>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
						</>
					)}
					{table.getState().pagination.pageIndex > 0 && (
						<PaginationItem>
							<PaginationLink
								onClick={() => table.setPageIndex(table.getState().pagination.pageIndex - 1)}
							>
								{table.getState().pagination.pageIndex}
							</PaginationLink>
						</PaginationItem>
					)}
					<PaginationItem>
						<PaginationLink isActive>{table.getState().pagination.pageIndex + 1}</PaginationLink>
					</PaginationItem>
					{table.getPageCount() >= table.getState().pagination.pageIndex + 2 && (
						<PaginationItem>
							<PaginationLink
								onClick={() => table.setPageIndex(table.getState().pagination.pageIndex + 1)}
							>
								{table.getState().pagination.pageIndex + 2}
							</PaginationLink>
						</PaginationItem>
					)}
					{table.getPageCount() > table.getState().pagination.pageIndex + 2 && (
						<>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
							<PaginationItem>
								<PaginationLink onClick={() => table.setPageIndex(table.getPageCount() - 1)}>
									{table.getPageCount()}
								</PaginationLink>
							</PaginationItem>
						</>
					)}
					<PaginationItem>
						<PaginationNext
							onClick={() => {
								if (table.getCanNextPage()) table.nextPage()
							}}
							disabled={!table.getCanNextPage()}
							displayName={t("pagination.next")}
						/>
					</PaginationItem>
				</PaginationContent>
			</Pagination>
		</div>
	)
}
