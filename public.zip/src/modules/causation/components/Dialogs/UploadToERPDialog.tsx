import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/modules/common/components/ui/dialog"
import { DataTableSendToERP } from "../DataTables/DataTableSendToERP"
import { useTranslation } from "react-i18next"
//import { UploadDropzone } from "@/modules/common/components/UploadDropzone" // Or custom uploader component

interface UploadToERPDialogProps {
    open: boolean
    onClose: () => void,
    selectedInvoiceDetails: any,
    setSelectedInvoiceDetails: any,
}

export function UploadToERPDialog({
    open,
    onClose,
    selectedInvoiceDetails,
    setSelectedInvoiceDetails

}: UploadToERPDialogProps) {
    const { t } = useTranslation(["invoicesNotSent"])
    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-max min-w-[70%] flex flex-col gap-2">
                <DialogHeader>
                    <DialogTitle>{t("button.send")}</DialogTitle>
                    <DialogDescription className="text-xs">
                        {t("descriptionSendERP")}
                    </DialogDescription>
                </DialogHeader>
                <DataTableSendToERP
                    data={selectedInvoiceDetails}
                    setData={setSelectedInvoiceDetails}
                />
            </DialogContent>
        </Dialog>
    )
}
