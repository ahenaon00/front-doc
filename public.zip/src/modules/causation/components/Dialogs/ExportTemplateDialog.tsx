import { useEffect, useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/modules/common/components/ui/dialog"
import { getExportFieldsCatalog, createExportTemplate } from "@/modules/causation/services/export"
import { SelectExportTemplate } from "../Export/SelectExportTemplate"
import { UploadAndMapTemplate } from "../Export/UploadAndMapTemplate"
import { UploadExportTemplate } from "../DropZone/UploadExportTemplate"

interface ExportTemplateDialogProps {
  open: boolean
  onClose: () => void
  action: "download" | "sendToERP"
  onTemplateSelected: (template: any) => void
  invoices: any[] // <- Add this line
}

export function ExportTemplateDialog({
  open,
  onClose,
  action,
  onTemplateSelected,
  invoices
}: ExportTemplateDialogProps) {
  const [mode, setMode] = useState<"select" | "upload">("select")
  const [catalog, setCatalog] = useState<any[]>([])
  const [uploadResult, setUploadResult] = useState<any | null>(null)

  useEffect(() => {
    if (open) {
      setMode("select")
      getExportFieldsCatalog()
        .then((res) => {
          setCatalog(res.catalogs || [])
          console.log(res)
        })
        .catch(console.error)
    }
  }, [open])

  const handleTemplateCreated = async (templatePayload: any) => {
    try {
      const result = await createExportTemplate(templatePayload)
      console.log(result)
      if (result.success) {
        onTemplateSelected(result.template)
        setMode("select") // ✅ go back to dropdown
      }
    } catch (error) {
      console.error("Error saving template:", error)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-[95vw]">
        <DialogHeader>
          <DialogTitle>
            {action === "download" ? "Descargar con plantilla" : "Enviar al ERP con plantilla"}
          </DialogTitle>
          <DialogDescription>
            {mode === "select"
              ? "Selecciona una plantilla existente o crea una nueva."
              : "Sube un archivo y configura su mapeo para crear una nueva plantilla."}
          </DialogDescription>
        </DialogHeader>

        {mode === "select" ? (
          <SelectExportTemplate
            onSelect={onTemplateSelected}
            onCreateNew={() => setMode("upload")}
            invoices={invoices}
          />
        ) : uploadResult ? (
          <UploadAndMapTemplate
            uploadResult={uploadResult}
            catalog={catalog}
            onSave={handleTemplateCreated}
          />
        ) : (
          // Upload dropzone placeholder component you already have
          <div className="mt-4">
            <p className="text-sm text-muted-foreground mb-2">Sube el archivo para empezar el mapeo.</p>
            <div className="border border-dashed rounded-lg p-4">
              {/* Replace this with your actual dropzone that calls `setUploadResult` */}
              <UploadExportTemplate onUploadSuccess={setUploadResult} />
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
