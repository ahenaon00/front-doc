// Import utils
import { Each } from "@/modules/common/lib/utils/Each"
import { useTranslation } from "react-i18next"

interface Props {
	data: any[]
	ActionComponent?: any
	onClick: (item: any) => void
}

export const TableComponent = ({ data, ActionComponent, onClick }: Props) => {
	// Mover el hook useTranslation dentro del componente
	const { t } = useTranslation(["debtSummary"])

	if (!data || data.length === 0) {
		return <p>{t("noInfo")}</p> // Corregir la clave de traducción
	}

	// Filtrar los encabezados, excluyendo "Url" si existe
	const headers = Object.keys(data[0]).filter((header) => header !== "Url")

	return (
		<table className="table" style={{ marginBottom: "1rem" }}>
			<thead>
				<tr>
					<Each
						data={headers}
						render={(header: string, headerIndex: number) => {
							// Traducir cada encabezado de la tabla
							return <th key={headerIndex}>{t(`headers.${header}`)}</th>
						}}
					/>
					{ActionComponent && <th>{t("headers.actions")}</th>}{" "}
					{/* Agregar encabezado para acciones */}
				</tr>
			</thead>
			<tbody>
				<Each
					data={data}
					render={(item: any, itemIndex: number) => (
						<tr key={itemIndex} onClick={() => onClick(item)}>
							{headers.map((header, headerIndex) => (
								<td key={headerIndex}>{item[header]}</td>
							))}
							{ActionComponent && (
								<td>
									<ActionComponent item={item} />
								</td>
							)}
						</tr>
					)}
				/>
			</tbody>
		</table>
	)
}
