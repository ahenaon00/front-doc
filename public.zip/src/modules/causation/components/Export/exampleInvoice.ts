export const exampleInvoice = {
	provider: {
		name: "Surtiflora SAS",
		id: "900123456",
		type: "supplier",
		addresses: [
			{
				address: "Calle 123 #45-67",
				city: {
					countryCode: "CO",
					stateCode: "11",
					cityCode: "11001",
				},
			},
		],
		contacts: [
			{
				firstName: "Lucía",
				lastName: "Gómez",
				email: "lucia@surtiflora.com",
			},
		],
		fiscalResponsibility: [
			{ code: "48", name: "Responsable de IVA" },
			{ code: "49", name: "Gran contribuyente" },
		],
		defaultPUC: {
			code: "413515",
			description: "Ventas nacionales gravadas",
		},
		defaultPaymentMethod: {
			id: 1,
			name: "Transferencia",
		},
	},
	items: [
		{
			product: {
				name: "Ramo de Rosas",
				code: "RR001",
				available_quantity: 120,
				prices: [
					{
						currency_code: "COP",
						price_list: [{ position: 1, name: "Base", value: 10000 }],
					},
				],
				unit_label: "Unidad",
				warehouses: [
					{ id: 1, name: "Bodega Central", quantity: 80 },
					{ id: 2, name: "Sucursal Norte", quantity: 40 },
				],
			},
			quantity: 3,
			unitPrice: 10000,
			total: 30000,
		},
	],
	invoiceId: "INV-001",
	issueDate: "2024-07-02T00:00:00.000+00:00",
	customerName: "Supermercado La 14",
	invoiceTotal: 34500,
	debt: 4500,
	taxes: [
		{ name: "IVA", amount: 4500 },
		{ name: "ReteFuente", amount: 1000 },
	],
	credit: [{ amount: 5000, paymentType: "CASH" }],
}
