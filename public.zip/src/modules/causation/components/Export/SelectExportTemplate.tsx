import { useEffect, useState } from "react"
import { Button } from "@/modules/common/components/ui/button"
import { getAllExportTemplates, generateAndDownloadTemplate } from "@/modules/causation/services/export"
import jsonata from "jsonata"
import { Loader2 } from "lucide-react"

interface Props {
	onSelect: (template: any) => void
	onCreateNew: () => void
	invoices: any[]
}

export function SelectExportTemplate({ onCreateNew, invoices = [] }: Props) {

	const [templates, setTemplates] = useState<any[]>([])
	const [selectedTemplate, setSelectedTemplate] = useState<any | null>(null)
	const [previewRow, setPreviewRow] = useState<string[]>([])
	const [isDownloading, setIsDownloading] = useState(false)


	useEffect(() => {
		getAllExportTemplates()
			.then((res) => setTemplates(res.templates || []))
			.catch(console.error)
	}, [])

	useEffect(() => {
		if (!selectedTemplate || invoices.length === 0) return;

		const entries = Object.entries(selectedTemplate.columnMapping || {})
			.sort(([a], [b]) => Number(a) - Number(b));

		const evaluatePreview = async () => {
			const invoice = invoices[0];
			const annotation = invoice.accountingEntries?.annotations?.[0];
			if (!annotation) {
				setPreviewRow([]);
				return;
			}

			const context = {
				...invoice,
				annotation,
				BUCKSconsecutivo: 1, // 👈 puedes dejarlo como número o string, según el template
			};

			const values = await Promise.all(
				entries.map(async ([, mapping]: any) => {
					try {
						if (!mapping.value) return "-";
						const expr = jsonata(mapping.value);
						const result = await expr.evaluate(context);
						return result != null ? String(result) : "-";
					} catch {
						return "Error";
					}
				})
			);

			setPreviewRow(values);
		};

		evaluatePreview();
	}, [selectedTemplate, invoices]);


	const handleSelect = (template: any) => {
		setSelectedTemplate(template)
		console.log(template)
	}
	const handleDownloadTemplate = async (template: any) => {
		if (!invoices.length) {
			alert("No hay facturas seleccionadas para exportar")
			return
		}

		try {
			setIsDownloading(true)
			await generateAndDownloadTemplate(
				invoices.map((inv) => inv._id),
				template._id
			)
			setIsDownloading(false)
		} catch (error) {
			console.error("Error downloading template:", error)
			setIsDownloading(false)
			alert("Error al generar y descargar el archivo")
		}
	}

	const previewColumns = selectedTemplate
		? Object.entries(selectedTemplate.columnMapping || {})
			.sort(([a], [b]) => Number(a) - Number(b))
		: []

	const totalAnnotations = invoices.reduce(
		(acc, inv) => acc + (inv.accountingEntries?.annotations?.length || 0),
		0
	)

	const remainingRows = Math.max(totalAnnotations - 1, 0)

	return (
		<div className="flex flex-col gap-4 max-h-[80vh] overflow-y-auto p-2">
			{templates.length > 0 ? (
				<>
					<div className="flex gap-2 items-center">
						<select
							className="border px-3 py-1 rounded-md text-sm"
							value={selectedTemplate?._id || ""}
							onChange={(e) => {
								const template = templates.find((t) => t._id === e.target.value)
								handleSelect(template)
							}}
						>
							<option value="">Selecciona una plantilla</option>
							{templates.map((template) => (
								<option key={template._id} value={template._id}>
									{template.name}
								</option>
							))}
						</select>
						<Button variant="primary" onClick={onCreateNew}>
							Crear nueva plantilla
						</Button>
					</div>

					{selectedTemplate && Array.isArray(invoices) && invoices.length > 0 && (
						<div className="mt-2">
							<h4 className="text-sm font-medium mb-1">Vista previa</h4>
							<div className="overflow-x-auto border rounded">
								<table className="min-w-full text-sm border-collapse">
									<thead>
										<tr>
											{previewColumns.map(([colIndex, mapping]: any) => (
												<th key={colIndex} className="border px-2 py-1 text-left bg-gray-100">
													{mapping.label || `Columna ${colIndex}`}
												</th>
											))}
										</tr>
									</thead>
									<tbody>
										<tr>
											{previewRow.map((val, i) => (
												<td key={i} className="border px-2 py-1">
													{val}
												</td>
											))}
										</tr>
									</tbody>
								</table>
							</div>
							{remainingRows > 0 && (
								<p className="text-xs text-gray-500 mt-1">
									+ {remainingRows} filas adicionales se generarán
								</p>
							)}
						</div>
					)}

					{selectedTemplate && (
						<div className="sticky bottom-0 bg-white pt-2 pb-4">
							<Button variant="primary" onClick={() => handleDownloadTemplate(selectedTemplate)} disabled={isDownloading}>
								{isDownloading ? <Loader2 className="animate-spin mr-2" /> : null}
								Usar esta plantilla
							</Button>
						</div>
					)}
				</>
			) : (
				<div className="text-sm text-muted-foreground">
					No hay plantillas disponibles.{" "}
					<Button variant="primary" onClick={onCreateNew}>
						Crear una nueva
					</Button>
				</div>
			)}
		</div>

	)
}
