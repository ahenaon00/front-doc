import { useEffect, useMemo, useState } from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@/modules/common/components/ui/table"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/modules/common/components/ui/select"
import { Input } from "@/modules/common/components/ui/input"
import { Button } from "@/modules/common/components/ui/button"
import { Label } from "@/modules/common/components/ui/label"
import jsonata from "jsonata"
import { exampleInvoice } from "@/modules/causation/components/Export/exampleInvoice"

interface Props {
  uploadResult: {
    templateFileUrl: string
    fileType: string
    availableHeaders: Record<string, string[]>
  }
  catalog: { groupTitle: string; fields: { label: string; value: string }[] }[]
  onSave: (mapping: {
    name: string
    headerRowIndex: number
    columnMapping: Record<string, { value: string | null; label: string | null }>
    fileType: string
    templateFileUrl: string
  }) => void
}

export function UploadAndMapTemplate({ uploadResult, catalog, onSave }: Props) {
  const headerRowOptions = Object.keys(uploadResult.availableHeaders)
  const [headerRowIndex, setHeaderRowIndex] = useState<string>(headerRowOptions[0] || "0")
  const [mapping, setMapping] = useState<Record<string, string | null>>({})
  const [templateName, setTemplateName] = useState("")
  const [openDropdownIndex, setOpenDropdownIndex] = useState<number | null>(null)
  const [mappedRow, setMappedRow] = useState<(string | number | null)[]>([])

  const headers = uploadResult.availableHeaders[headerRowIndex] || []

  const handleMappingChange = (colIndex: number, value: string | null) => {
    setMapping((prev) => ({ ...prev, [colIndex]: value }))
  }


  const handleSubmit = () => {
    if (!templateName) return alert("Debes dar un nombre a la plantilla.")
    onSave({
      name: templateName,
      headerRowIndex: Number(headerRowIndex),
      columnMapping: Object.fromEntries(
        headers.map((label, index) => {
          const value = mapping[index] ?? null
          return [
            index.toString(),
            {
              value,
              label
            },
          ]
        })
      )
      ,
      fileType: uploadResult.fileType,
      templateFileUrl: uploadResult.templateFileUrl,
    })
  }

  useEffect(() => {
    const computeRow = async () => {
      const row: (string | number | null)[] = []

      for (const index in headers) {
        const expression = mapping[index]
        if (!expression || typeof expression !== "string") {
          row.push(null)
        } else {
          try {
            const jsonataExp = jsonata(expression)
            const result = await jsonataExp.evaluate(exampleInvoice)
            row.push(result ?? null)
          } catch (err) {
            console.warn(`⚠️  Error evaluating expression "${expression}"`, err)
            row.push("⚠️ Error")
          }
        }
      }

      setMappedRow(row)
    }

    computeRow()
  }, [headers, mapping])

  const memoizedMappingTable = useMemo(() => (

    <Table>
      <TableBody>
        <TableRow>
          {headers.map((colName, colIndex) => (
            <TableHead key={colIndex} className="text-xs max-w-[200px] truncate">
              {colName}
            </TableHead>
          ))}
        </TableRow>
        <TableRow>
          {headers.map((_, colIndex) => (
            <TableCell key={colIndex}>
              <Select
                open={openDropdownIndex === colIndex}
                onOpenChange={(isOpen) => setOpenDropdownIndex(isOpen ? colIndex : null)}
                value={mapping[colIndex] ?? "__unmapped__"}
                onValueChange={(value) =>
                  handleMappingChange(colIndex, value === "__unmapped__" ? null : value)
                }
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sin asignar" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="__unmapped__">Sin asignar</SelectItem>
                  </SelectGroup>

                  {openDropdownIndex !== colIndex && mapping[colIndex] &&
                    catalog
                      .flatMap((group) => group.fields)
                      .filter((field) => field.value === mapping[colIndex])
                      .map((field) => (
                        <SelectItem key={field.value} value={field.value}>
                          {field.label}
                        </SelectItem>
                      ))}

                  {openDropdownIndex === colIndex &&
                    catalog.map((group) => (
                      <SelectGroup key={group.groupTitle}>
                        <div className="px-2 py-1 text-xs text-muted-foreground font-semibold">
                          {group.groupTitle}
                        </div>
                        {group.fields.map((field) => (
                          <SelectItem key={field.value} value={field.value}>
                            {field.label}
                          </SelectItem>
                        ))}
                      </SelectGroup>
                    ))}
                </SelectContent>
              </Select>
            </TableCell>
          ))}
        </TableRow>
      </TableBody>
    </Table>

  ), [headers, mapping, openDropdownIndex, catalog])

  return (<>
    <div className="space-y-6">
      <TemplateNameInput value={templateName} onChange={setTemplateName} />

      <div className="space-y-2">
        <Label>Fila que contiene los encabezados</Label>
        <Select value={headerRowIndex} onValueChange={setHeaderRowIndex}>
          <SelectTrigger>
            <SelectValue placeholder="Selecciona la fila" />
          </SelectTrigger>
          <SelectContent>
            {headerRowOptions.map((rowKey) => (
              <SelectItem key={rowKey} value={rowKey}>
                Fila {Number(rowKey) + 1}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>

    <div className="overflow-x-auto max-w-full mt-6">
      <div className="min-w-[800px]">

        {memoizedMappingTable}

      </div>
    </div>
    <div className="mt-6">
      <Label className="mb-2 block">Vista previa de cómo se verá la fila exportada</Label>
    </div>
    <div className="overflow-x-auto max-w-full">
      <table className="min-w-[800px] border text-sm border-collapse border-gray-300">
        <thead>
          <tr className="bg-gray-100">
            {headers.map((h, i) => (
              <th key={i} className="border px-2 py-1 font-semibold text-left">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr>
            {mappedRow.map((value, i) => (
              <td key={i} className="border px-2 py-1 text-left">
                {value === null ? (
                  <span className="text-muted-foreground italic">Sin asignar</span>
                ) : (
                  String(value)
                )}
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>

    <div className="pt-2">
      <Button variant="primary"  onClick={handleSubmit}>Guardar plantilla</Button>
    </div>
  </>
  )
}

function TemplateNameInput({
  value,
  onChange,
}: {
  value: string
  onChange: (v: string) => void
}) {
  return (
    <div className="space-y-2">
      <Label>Nombre de la plantilla</Label>
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Ej: Plantilla World Office 2025"
      />
    </div>
  )
}
