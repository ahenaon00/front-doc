import { useTranslation } from "react-i18next"
import { getPaidInvoices } from "../../services/invoice"
import { useEffect, useState } from "react"
import Header from "@/modules/common/components/app/Header/Header"
import { DataTablePaidInvoices } from "../../components/DataTables/DataTablePaidInvoices"

export default function PaidInvoices() {
	const { t } = useTranslation(["causation"])
	const [paidInvoices, setPaidInvoices] = useState([])

	useEffect(() => {
		const fetchRecentActivity = async () => {
			const paidInvoices = (await getPaidInvoices()).map((invoice: any) => ({
				id: invoice.invoiceId,
				provider: invoice.provider,
				paymentDate: new Date(invoice.issueDate).toLocaleDateString(),
				paymentMethod: invoice.longTermPayment ? t("labels.credit") : t("labels.cash"),
				totalAmount: invoice.invoiceTotal,
			}))

			setPaidInvoices(paidInvoices.reverse().slice(0, 5))
		}

		fetchRecentActivity()
	}, [t])

	return (
		<>
			<Header
				title={t("paidInvoices.title")}
				sections={[{ title: t("title"), href: "/causation" }]}
			/>
			<main className="m-5 flex flex-col gap-5">
				<div className="flex flex-col gap-1">
					<h1 className="text-xl">{t("paidInvoices.title")}</h1>
					<h2 className="text-sm text-primary-grey-1200">{t("recentActivity")}</h2>
				</div>
				<DataTablePaidInvoices data={paidInvoices} />
			</main>
		</>
	)
}
