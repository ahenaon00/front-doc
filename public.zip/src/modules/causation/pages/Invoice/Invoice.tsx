import Header from "@/modules/common/components/app/Header/Header"
import { Dispatch, SetStateAction, useEffect, useState } from "react"
import { useTranslation } from "react-i18next"
import { useParams } from "react-router-dom"
import { getInvoiceByUID, updateInvoice } from "../../services/invoice"
import { getFile } from "../../services/file"
import LogoLoader from "@/modules/common/components/app/LogoLoader/LogoLoader"
import { PdfViewer } from "@/components/common/PdfViewer/PdfViewer"
import { getAllProviders, getProviderById } from "@/modules/management/services/providers"
import { formatNumber } from "@/modules/common/lib/utils/formatNumber"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import { Button } from "@/modules/common/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/modules/common/components/ui/popover"
import { Check, ChevronsUpDown, Pencil, Trash2, X } from "lucide-react"
import { cn } from "@/modules/common/lib/utils"
import {
	Command,
	CommandEmpty,
	CommandGroup,
	CommandInput,
	CommandItem,
	CommandList,
} from "@/modules/common/components/ui/command"
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger,
} from "@/modules/common/components/ui/tooltip"
import {
	Dialog,
	DialogClose,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
	DialogTrigger,
} from "@/modules/common/components/ui/dialog"

interface AccountLine {
	id: string
	code?: string
	description: string
	puc?: string
	movement: string
	value: number
	taxBase?: number
	costCenter?: string
	quantity?: number
	mediUnit?: string
}

export default function Invoice() {
	const { id } = useParams()
	const { t } = useTranslation(["transaction"])
	const [fileURL, setFileURL] = useState("")
	const [fileData, setFileData] = useState<any>(false)
	const [sections, setSections] = useState([
		{ title: t("transaction.causation"), href: "/causation" },
	])
	const [loading, setLoading] = useState(true)
	const [, setProviders] = useState<any[]>([])
	const [provider, setProvider] = useState<any>(null)
	const [accountingLines, setAccountingLines] = useState<AccountLine[]>([])
	const [editingLines, setEditingLines] = useState<Map<string, boolean>>(new Map())
	const [linesEdited, setLinesEdited] = useState<Map<string, AccountLine>>(new Map())
	const [pucCodes, setPucCodes] = useState<string[]>([])

	useEffect(() => {
		if (!fileData) return
		updateInvoice(id!, {
			...fileData,
			accountingEntries: {
				transactions: accountingLines.map((line) => ({
					accountCode: line.puc,
					accountName: line.description,
					debit: line.movement === t("transaction.table.fields.debit") ? line.value : 0,
					credit: line.movement === t("transaction.table.fields.credit") ? line.value : 0,
					baseRetention: line.taxBase,
					costCenter: line.costCenter,
				})),
				journalNumber: accountingLines[0]?.code || "",
			},
		})
			.then(() => {
				console.log(t("transaction.messages.invoiceUpdated"))
			})
			.catch((error) => {
				console.error(t("transaction.messages.errorUpdatingInvoice"), error)
			})
	}, [id, accountingLines, t, fileData])

	useEffect(() => {
		const calculateInvoiceLines = (data: any) => {
			setAccountingLines(
				data?.accountingEntries?.transactions.map((transaction: any, index: number) => {
					setPucCodes((prev) => {
						if (!prev.includes(transaction.accountCode)) {
							return [...prev, transaction.accountCode]
						}
						return prev
					})
					return {
						id: crypto.randomUUID(),
						code: data.accountingEntries.journalNumber,
						description: transaction.accountName,
						movement:
							transaction.credit === 0
								? t("transaction.table.fields.debit")
								: t("transaction.table.fields.credit"),
						value: transaction.credit === 0 ? transaction.debit : transaction.credit,
						puc: transaction.accountCode, // Assuming puc is optional
						taxBase: transaction.baseRetention,
						costCenter: transaction.costCenter,
						quantity: data.items[index]?.quantity,
						mediUnit: data.items[index]?.unit,
					}
				}),
			)
		}

		const fetchInvoice = async (id: string) => {
			try {
				const response = await getInvoiceByUID(id)
				calculateInvoiceLines(response)
				setFileData(response)
				setTimeout(() => setLoading(false), 2000)
				if (response.uploadedERP) {
					setSections([
						{ title: t("transaction.causation"), href: "/causation" },
						{ title: t("transaction.debts"), href: "/debts" },
						{
							title: t("transaction.consolidatedInfo"),
							href: `/consolidated-info/${fileData.supplierId}`,
						},
					])
				} else {
					setSections([
						{ title: t("transaction.causation"), href: "/causation" },
						{ title: t("transaction.invoicesNotSent"), href: "/invoices-not-sent" },
					])
				}
				return response
			} catch (error) {
				console.error(t("transaction.messages.errorFetchingDocument"), error)
			}
		}
		const getData = async () => {
			try {
				const response = await getFile(id!)
				const fileUrl = URL.createObjectURL(response)
				setFileURL(fileUrl)

				await fetchInvoice(id!)
			} catch (error) {
				console.error(t("transaction.messages.errorFetchingFile"), error)
			}
		}

		getData()
	}, [id, t, fileData.supplierId])
	useEffect(() => {
		const getProviders = async (supplierId: string) => {
			const providers = await getAllProviders({ limit: 10, page: 1, personType: "all" })

			setProviders(providers)
			const provider = await getProviderById(supplierId)
			setProvider(provider)
		}
		if (fileData && fileData.supplierId) {
			getProviders(fileData.supplierId)
		}
	}, [fileData, t])

	return (
		<div className="relative h-full w-full">
			<Header
				title={
					loading
						? t("transaction.labels.loadingInvoice")
						: `${t("transaction.labels.invoiceNumber")} ${fileData.invoiceId}`
				}
				sections={sections}
			/>
			{loading ? (
				<LogoLoader className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2" />
			) : (
				<div className="grid grid-cols-1 gap-x-12 gap-y-8 p-4 md:grid-cols-2">
					<PdfViewer pdfFile={fileURL} zoom={0.75} className="h-full max-h-[520px]" />
					<article className="flex flex-col gap-6">
						<div>
							<h2 className="mb-2 font-medium">{t("transaction.table.invoiceInfo")}</h2>
							<ul className="grid grid-cols-3">
								<li>
									<h3 className="text-sm font-medium">{t("transaction.table.fields.invoiceId")}</h3>
									<p className="text-sm text-primary-grey-1200">{fileData.invoiceId}</p>
								</li>
								<li>
									<h3 className="text-sm font-medium">{t("transaction.table.fields.issueDate")}</h3>
									<p className="text-sm text-primary-grey-1200">
										{new Date(fileData.issueDate).toLocaleDateString()}
									</p>
								</li>
								<li>
									<h3 className="text-sm font-medium">{t("transaction.table.fields.dueDate")}</h3>
									<p className="text-sm text-primary-grey-1200">
										{new Date(fileData.dueDate).toLocaleDateString()}
									</p>
								</li>
							</ul>
							<div className="mt-4 w-fit rounded-full bg-primary-green-200 px-4 py-2 text-sm">
								<span>{t("transaction.table.fields.invoiceTotal")}:</span> {fileData.invoiceTotal}
							</div>
						</div>
						<hr />
						<div>
							<h2 className="mb-2 font-medium">{t("transaction.table.providerInfo")}</h2>
							<h3 className="text-sm font-medium">{t("transaction.table.fields.vendorName")}</h3>
							<p className="mb-2 text-sm text-primary-grey-1200">
								{provider?.name ?? fileData.vendorName}
							</p>
							<ul className="grid grid-cols-3">
								<li>
									<h3 className="text-sm font-medium">{t("transaction.table.fields.vendorNit")}</h3>
									<p className="text-sm text-primary-grey-1200">
										{provider?.id ?? fileData.vendorNit}
									</p>
								</li>
								<li>
									<h3 className="text-sm font-medium">
										{t("transaction.table.fields.vendorAddress")}
									</h3>
									<p className="text-sm text-primary-grey-1200">
										{provider?.addresses[0]?.address ?? fileData.vendorAddress}
									</p>
								</li>
								<li>
									<h3 className="text-sm font-medium">
										{t("transaction.table.fields.vendorCity")}
									</h3>
									<p className="text-sm text-primary-grey-1200">{fileData.vendorCity}</p>
								</li>
							</ul>
						</div>
						<hr />
						<div>
							<h2 className="mb-2 font-medium">{t("transaction.table.customerInfo")}</h2>
							<h3 className="text-sm font-medium">{t("transaction.table.fields.customerName")}</h3>
							<p className="mb-2 text-sm text-primary-grey-1200">{fileData.customerName}</p>
							<ul className="grid grid-cols-3">
								<li>
									<h3 className="text-sm font-medium">
										{t("transaction.table.fields.customerId")}
									</h3>
									<p className="text-sm text-primary-grey-1200">{fileData.customerId}</p>
								</li>
								<li>
									<h3 className="text-sm font-medium">
										{t("transaction.table.fields.customerAddress")}
									</h3>
									<p className="text-sm text-primary-grey-1200">{fileData.customerAddress}</p>
								</li>
								<li>
									<h3 className="text-sm font-medium">
										{t("transaction.table.fields.customerCity")}
									</h3>
									<p className="text-sm text-primary-grey-1200">{fileData.customerCity}</p>
								</li>
							</ul>
						</div>
					</article>
					<article className="col-span-2">
						<Table>
							<TableHeader>
								<TableRow>
									<TableHead>{t("transaction.table.fields.code")}</TableHead>
									<TableHead>{t("transaction.table.fields.description")}</TableHead>
									<TableHead>{t("transaction.table.fields.account")}</TableHead>
									<TableHead>{t("transaction.table.fields.movement")}</TableHead>
									<TableHead>{t("transaction.table.fields.value")}</TableHead>
									<TableHead>{t("transaction.table.fields.taxBase")}</TableHead>
									<TableHead>{t("transaction.table.fields.costCenter")}</TableHead>
									<TableHead>{t("transaction.table.fields.quantity")}</TableHead>
									<TableHead className="text-right">
										{t("transaction.table.fields.mediUnit")}
									</TableHead>
									<TableHead></TableHead>
								</TableRow>
							</TableHeader>
							<TableBody>
								{(accountingLines?.length === 0 || accountingLines === undefined) && (
									<TableRow>
										<TableCell colSpan={9} className="h-24 text-center">
											No results.
										</TableCell>
									</TableRow>
								)}
								{accountingLines?.map((line: any) => (
									<TableRow key={line.id}>
										{editingLines.get(line.id) ? (
											<>
												<TableCell className="p-0">
													<input
														className="h-full w-full border-none p-2 focus:outline-0"
														value={linesEdited.get(line.id)?.code}
														onChange={(e) =>
															setLinesEdited(
																new Map(linesEdited).set(line.id, {
																	...linesEdited.get(line.id)!,
																	code: e.target.value ?? line.code,
																}),
															)
														}
													/>
												</TableCell>
												<TableCell className="p-0">
													<input
														className="h-full w-full border-none p-2 focus:outline-0"
														value={linesEdited.get(line.id)?.description}
														onChange={(e) =>
															setLinesEdited(
																new Map(linesEdited).set(line.id, {
																	...linesEdited.get(line.id)!,
																	description: e.target.value ?? line.description,
																}),
															)
														}
														defaultValue={line.description}
													/>
												</TableCell>
												<TableCell>
													<div className="flex h-full items-center">
														<PucCombobox
															defaultPuc={linesEdited.get(line.id)?.puc ?? line.puc}
															setDefaultPuc={(puc) =>
																setLinesEdited(
																	new Map(linesEdited).set(line.id, {
																		...linesEdited.get(line.id)!,
																		puc: puc ?? line.puc,
																	}),
																)
															}
															pucCodes={pucCodes}
															setPucCodes={setPucCodes}
														/>
													</div>
												</TableCell>
												<TableCell className="p-0">
													<input
														className="h-full w-full border-none p-2 focus:outline-0"
														defaultValue={line.movement}
														onChange={(e) =>
															setLinesEdited(
																new Map(linesEdited).set(line.id, {
																	...linesEdited.get(line.id)!,
																	movement: e.target.value ?? line.movement,
																}),
															)
														}
													/>
												</TableCell>
												<TableCell className="p-0">
													<input
														className="h-full w-full border-none p-2 focus:outline-0"
														defaultValue={line.value}
														type="number"
														onChange={(e) =>
															setLinesEdited(
																new Map(linesEdited).set(line.id, {
																	...linesEdited.get(line.id)!,
																	value: Number(e.target.value ?? line.value),
																}),
															)
														}
													/>
												</TableCell>
												<TableCell className="p-0">
													<input
														className="h-full w-full border-none p-2 focus:outline-0"
														defaultValue={line.taxBase}
														type="number"
														onChange={(e) =>
															setLinesEdited(
																new Map(linesEdited).set(line.id, {
																	...linesEdited.get(line.id)!,
																	taxBase: Number(e.target.value ?? line.taxBase),
																}),
															)
														}
													/>
												</TableCell>
												<TableCell className="p-0">
													<input
														className="h-full w-full border-none p-2 focus:outline-0"
														defaultValue={line.costCenter}
														onChange={(e) =>
															setLinesEdited(
																new Map(linesEdited).set(line.id, {
																	...linesEdited.get(line.id)!,
																	costCenter: e.target.value ?? line.costCenter,
																}),
															)
														}
													/>
												</TableCell>
												<TableCell className="p-0">
													<input
														className="h-full w-full border-none p-2 focus:outline-0"
														defaultValue={line.quantity}
														onChange={(e) =>
															setLinesEdited(
																new Map(linesEdited).set(line.id, {
																	...linesEdited.get(line.id)!,
																	quantity: Number(e.target.value ?? line.quantity),
																}),
															)
														}
													/>
												</TableCell>
												<TableCell className="p-0 text-right">
													<input
														className="h-full w-full border-none p-2 text-right focus:outline-0"
														defaultValue={line.mediUnit}
														onChange={(e) =>
															setLinesEdited(
																new Map(linesEdited).set(line.id, {
																	...linesEdited.get(line.id)!,
																	mediUnit: e.target.value ?? line.mediUnit,
																}),
															)
														}
													/>
												</TableCell>
												<TableCell>
													<div className="flex items-center justify-end">
														<Button
															variant="icon"
															size="none"
															type="button"
															className="group/puc:block z-[100] p-0.5 [&_svg]:size-4"
															onClick={() => {
																setAccountingLines((prev) =>
																	prev.map((l) =>
																		l.id === line.id
																			? {
																					...l,
																					...linesEdited.get(line.id),
																				}
																			: l,
																	),
																)
																setEditingLines(new Map(editingLines).set(line.id, false))
															}}
														>
															<Check className="group/puc stroke-primary-green-1200" />
														</Button>
														<Button
															variant="icon"
															size="none"
															type="button"
															className="group/puc:block z-[100] p-0.5 [&_svg]:size-4"
															onClick={() => {
																const newMap = new Map(linesEdited)
																newMap.delete(line.id)
																setLinesEdited(newMap)
																setEditingLines(new Map(editingLines).set(line.id, false))
															}}
														>
															<X className="group/puc stroke-semantic-red-1200" />
														</Button>
													</div>
												</TableCell>
											</>
										) : (
											<>
												<TableCell></TableCell>
												<TableCell>{line.description}</TableCell>
												<TableCell>
													<div className="flex h-full items-center">
														<PucCombobox
															defaultPuc={line.puc}
															pucCodes={pucCodes}
															setPucCodes={setPucCodes}
															disabled
														/>
													</div>
												</TableCell>
												<TableCell>{line.movement}</TableCell>
												<TableCell>{formatNumber(line.value)}</TableCell>
												<TableCell>{line.taxBase}</TableCell>
												<TableCell>{line.costCenter}</TableCell>
												<TableCell>{line.quantity}</TableCell>
												<TableCell className="text-right">{line.mediUnit}</TableCell>
												<TableCell>
													<div className="flex items-center justify-end">
														<Button
															variant="icon"
															size="none"
															type="button"
															className="group/puc:block z-[100] p-0.5 [&_svg]:size-4"
															onClick={() =>
																setEditingLines(new Map(editingLines).set(line.id, true))
															}
														>
															<Pencil className="group/puc stroke-semantic-yellow-1500" />
														</Button>
														<Dialog>
															<DialogTrigger asChild>
																<Button
																	variant="icon"
																	size="none"
																	type="button"
																	className="group/puc:block z-[100] p-0.5 [&_svg]:size-4"
																>
																	<Trash2 className="group/puc stroke-semantic-red-1200" />
																</Button>
															</DialogTrigger>
															<DialogContent>
																<DialogHeader>
																	<DialogTitle>
																		{t("transaction.table.messages.deleteLine")}
																	</DialogTitle>
																	<DialogDescription>
																		{t("transaction.table.messages.deleteLineDescription")}
																	</DialogDescription>
																</DialogHeader>
																<DialogFooter className="mt-4">
																	<DialogClose asChild>
																		<Button variant="quiet">
																			{t("transaction.table.messages.cancel")}
																		</Button>
																	</DialogClose>
																	<DialogClose asChild>
																		<Button
																			variant="negative"
																			onClick={() => {
																				setEditingLines(new Map(editingLines).set(line.id, false))
																				setAccountingLines((prev) =>
																					prev.filter((l) => l.id !== line.id),
																				)
																			}}
																		>
																			{t("transaction.table.messages.delete")}
																		</Button>
																	</DialogClose>
																</DialogFooter>
															</DialogContent>
														</Dialog>
													</div>
												</TableCell>
											</>
										)}
									</TableRow>
								))}
								<TableRow className="cursor-pointer hover:bg-muted">
									<TableCell colSpan={9} className="p-0 text-center text-muted-foreground">
										<Button
											variant="ghost"
											className="w-full"
											onClick={() => {
												const newLine: AccountLine = {
													id: crypto.randomUUID(),
													code: "",
													description: "",
													puc: undefined,
													movement: "",
													value: 0,
													taxBase: undefined,
													costCenter: "",
													quantity: undefined,
													mediUnit: "",
												}
												setAccountingLines((prev) => [...prev, newLine])
												setEditingLines(new Map(editingLines).set(newLine.id, true))
											}}
										>
											+ Agregar fila
										</Button>
									</TableCell>
								</TableRow>
							</TableBody>
						</Table>
						<div className="bg-gray-500"></div>
					</article>
				</div>
			)}
		</div>
	)
}

interface PucComboboxProps {
	defaultPuc: string
	setDefaultPuc?: Dispatch<SetStateAction<string | undefined>>
	pucCodes: string[]
	disabled?: boolean
	setPucCodes: Dispatch<SetStateAction<string[]>>
}

function PucCombobox({
	defaultPuc,
	pucCodes,
	setPucCodes,
	disabled = false,
	setDefaultPuc,
}: PucComboboxProps) {
	const [pucFilter, setPucFilter] = useState("")
	const { t } = useTranslation(["transaction"])

	useEffect(() => {
		if (!pucCodes.includes(defaultPuc || "")) {
			console.log(defaultPuc)
			setDefaultPuc?.(undefined)
		}
	}, [pucCodes, defaultPuc, setDefaultPuc])

	return (
		<Popover>
			<PopoverTrigger asChild>
				<Button
					variant="outline"
					role="combobox"
					className={cn(
						"group/combobox w-full max-w-40 justify-between disabled:opacity-100",
						!defaultPuc && "text-muted-foreground",
					)}
					disabled={disabled}
				>
					{defaultPuc ? defaultPuc : t("transaction.table.fields.selectPUC")}
					<ChevronsUpDown className="opacity-50 group-disabled/combobox:opacity-20" />
				</Button>
			</PopoverTrigger>
			<PopoverContent className="p-0">
				<Command>
					<CommandInput
						value={pucFilter}
						onChangeCapture={(e) => {
							if (!Number.isNaN(Number((e.target as HTMLInputElement).value))) {
								setPucFilter((e.target as HTMLInputElement).value)
							}
						}}
						placeholder="Search PUC Code"
						className="h-9"
					/>
					<CommandList>
						{pucFilter === "" && (
							<CommandEmpty>{t("transaction.table.fields.noPUCCodes")}</CommandEmpty>
						)}
						<CommandGroup>
							{pucCodes.map((puc) => (
								<CommandItem
									value={puc}
									key={puc}
									className="group/puc cursor-pointer"
									onSelect={() => {
										setPucFilter("")
										setDefaultPuc?.(defaultPuc === puc ? undefined : puc)
									}}
								>
									{puc}
									<div className="ml-auto flex items-center gap-2">
										<Button
											variant="ghost"
											size="none"
											className="z-[100] hidden p-0.5 hover:bg-primary-grey-200 group-hover/puc:block [&_svg]:size-4"
											onClick={() => {
												setPucCodes((prev) => prev.filter((code) => code !== puc))
												if (defaultPuc === puc) {
													setDefaultPuc?.(undefined)
												}
											}}
										>
											<Trash2 className="stroke-semantic-red-1200" />
										</Button>
										{puc === defaultPuc && (
											<TooltipProvider>
												<Tooltip>
													<TooltipTrigger>
														<Check />
													</TooltipTrigger>
													<TooltipContent>
														<div className="rounded-md bg-primary-grey-50 p-2 text-primary-grey-1000">
															{t("transaction.table.fields.selectedPUC")}
														</div>
													</TooltipContent>
												</Tooltip>
											</TooltipProvider>
										)}
									</div>
								</CommandItem>
							))}
						</CommandGroup>
					</CommandList>
				</Command>
				{pucFilter !== "" && !pucCodes.find((code) => code === pucFilter) && (
					<Button
						variant="ghost"
						className="m-1 w-[calc(100%-8px)] px-2 py-1.5 normal-case"
						size="none"
						onClick={() => {
							setPucCodes([...pucCodes, pucFilter])
							setPucFilter("")
						}}
					>
						{t("transaction.table.fields.addPUC")} '{pucFilter}'
					</Button>
				)}
			</PopoverContent>
		</Popover>
	)
}
