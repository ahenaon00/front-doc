import Header from "@/modules/common/components/app/Header/Header"
import { useSelector } from "react-redux"
import { VendorDebtTable } from "../../components/DataTables/VendorDebtTable"
import { useTranslation } from "react-i18next"
import DropzoneUpload from "@/components/common/popUps/dragNdrop/dropZone"
import useFileUpload from "@/components/common/popUps/dragNdrop/useFileUpload"


const InvoicesLoaded = () => {
	const { t } = useTranslation(["invoice"])
	const invoices = useSelector((state: { invoice: { invoices: any[] } }) => state.invoice.invoices)
	const { onDrop } = useFileUpload(t)


	return (
		<>
			<Header title={"Invoices Loaded"} sections={[{ title: "Inicio", href: "/causation" }]} />
			<div className="p-2">
				<div className="flex gap-2 p-2">
					<div>
						<h2>{t('labels.invoicesLoaded')}</h2>
						<p className="font-medium text-xs text-gray-400">
							{t('messages.descriptionInvoiceLoaded')}
						</p>
					</div>
					<div className="w-full border-2 p-2 rounded-md">
					<DropzoneUpload
					onDrop={onDrop}
					landScape="Horizontal"
					className="w-full p-2 gap-2 items-center"
					accept={["application/zip", "application/x-zip-compressed"]}
					/>
					</div>
					

				</div>

				<VendorDebtTable data={invoices} />
			</div>
		</>
	)
}

export default InvoicesLoaded
