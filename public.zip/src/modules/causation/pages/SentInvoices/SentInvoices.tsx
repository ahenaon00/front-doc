import { useTranslation } from "react-i18next"
import { useEffect, useState } from "react"
import Header from "@/modules/common/components/app/Header/Header"
import { getSentInvoices } from "../../services/invoice"
import { DataTableSentInvoices } from "../../components/DataTables/DataTableSentInvoices"

export default function SentInvoices() {
	const { t } = useTranslation(["causation"])
	const [sentInvoices, setSentInvoices] = useState([])

	useEffect(() => {
		const fetchRecentActivity = async () => {

			const sentInvoices = (await getSentInvoices()).map((invoice: any) => ({
				id: invoice.invoiceId,
				provider: invoice.provider,
				sentDate: new Date(invoice.issueDate).toLocaleDateString(),
				paymentMethod: invoice.longTermPayment ? t("labels.credit") : t("labels.cash"),
			}))

			setSentInvoices(sentInvoices.reverse().slice(0, 5))
		}

    fetchRecentActivity()
	}, [t])

	return (
		<>
			<Header
				title={t("sentInvoices.title")}
				sections={[{ title: t("title"), href: "/causation" }]}
			/>
			<main className="m-5 flex flex-col gap-5">
				<div className="flex flex-col gap-1">
					<h1 className="text-xl">{t("sentInvoices.title")}</h1>
					<h2 className="text-sm text-primary-grey-1200">{t("recentActivity")}</h2>
				</div>
				<DataTableSentInvoices data={sentInvoices} />
			</main>
		</>
	)
}
