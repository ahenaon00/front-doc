import axios from "axios"
import Cookies from "js-cookie"

const VITE_BASE_URL = import.meta.env.VITE_BASE_URL + "/api/transaction-entity"

// Create
export const createTransactionEntity = async (
	module: any,
	blobID: string,
	name: string,
	longTermPayment: any,
	data: any,
) => {
	try {
		const response = await axios.post(
			`${VITE_BASE_URL}`,
			{
				name,
				module,
				blobID,
				longTermPayment,
				data,
			},
			{
				headers: {
					Authorization: `Bearer ${Cookies.get("token")}`,
				},
			},
		)
		return response.data
	} catch (error) {
		console.error("Error creating item:", error)
		throw error
	}
}

// Get all workspaces
export const getTransactionEntitiesOnWorkSpaceId = async (id: string) => {
	try {
		const response = await axios.get(`${VITE_BASE_URL}/${id}`, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
			/*params: {
				moduleId: id,
				consolidate: false, // Añadimos este parámetro para filtrar
			},*/
		})
		return response
	} catch (error) {
		console.error("Error getting workspaces:", error)
		throw error
	}
}

export const updateTransactionEntity = async (
	id: string,
	items: any,
	dueDate: Date,
	invoiceId: string,
	invoiceTotal: number,
	vendorAddress: string,
	vendorName: string,
	vendorTaxId: string,
) => {
	try {
		const response = await axios.put(
			`${VITE_BASE_URL}/${id}`,
			{
				items,
				dueDate,
				invoiceId,
				invoiceTotal,
				vendorAddress,
				vendorName,
				vendorTaxId,
			},
			{
				headers: {
					Authorization: `Bearer ${Cookies.get("token")}`,
				},
			},
		)
		return response.data
	} catch (error) {
		console.error("Error updating item:", error)
		throw error
	}
}

//update transaction entity consolidated status by id
export const updateTransactionEntityConsolidatedStatusById = async (id: string) => {
	try {
		const response = await axios.put(
			`${VITE_BASE_URL}/consolidated/${id}`,
			{ consolidated: true },
			{
				headers: {
					Authorization: `Bearer ${Cookies.get("token")}`,
				},
			},
		)
		return response.data
	} catch (error) {
		console.error("Error updating item:", error)
		throw error
	}
}
export const getAllExtractedDataFromWorkSpace = async (id: string) => {
	try {
		const response = await axios.get(`${VITE_BASE_URL}/${id}/extracted-data`, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
		})
		return response.data
	} catch (error) {
		console.error("Error getting extracted data:", error)
		return error
	}
}
export const deleteTransactionEntity = async (id: string) => {
	try {
		const response = await axios.delete(`${VITE_BASE_URL}/${id}`, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error deleting item:", error)
		throw error
	}
}

export const getTransactionEntityById = async (id: string) => {
	try {
		const response = await axios.get(`${VITE_BASE_URL}/one/${id}`, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error getting workspaces:", error)
		throw error
	}
}

export const consolidateTransactionEntities = async (invoiceIds: string[]) => {
	try {
		const response = await axios.put(
			`${VITE_BASE_URL}/consolidated`,
			{ ids: invoiceIds },
			{
				headers: {
					Authorization: `Bearer ${Cookies.get("token")}`,
				},
			},
		)
		return response.data
	} catch (error) {
		console.error("Error consolidating transactions:", error)
		throw error
	}
}

export const getConsolidatedTransactions = async () => {
	try {
		const response = await axios.get(`${VITE_BASE_URL}/consolidated/status`, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error getting consolidated transactions:", error)
		throw error
	}
}
