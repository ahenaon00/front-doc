import axios from "axios"
import Cookies from "js-cookie"

const VITE_BASE_URL = import.meta.env.VITE_BASE_URL + "/api/file" // URL for file upload

export const uploadFile = async (file: any) => {
	try {
		const response = await axios.post(`${VITE_BASE_URL}/upload`, file, {
			headers: {
				"Content-Type": "multipart/form-data",
				"Authorization": `Bearer ${Cookies.get("token")}`,
			},
		})
		return response
	} catch (error) {
		console.error("Error uploading file:", error)
		throw error
	}
}

export const uploadOnboardingFile = async (files: File[]) => {
	try {
		const formData = new FormData()
		files.forEach((file) => formData.append("files", file)) // Campo "file" en plural si backend espera array

		const response = await axios.post(`${VITE_BASE_URL}/on-boarding/upload`, formData, {
			headers: {
				"Content-Type": "multipart/form-data",
				"Authorization": `Bearer ${Cookies.get("token")}`,
			},
		})
		return response
	} catch (error) {
		console.error("Detalle del error:", (error as any).response?.data) // ¡Importante para debug!
		throw error
	}
}

export const getFile = async (id: string) => {
	try {
		const response = await axios.get(`${VITE_BASE_URL}/${id}`, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
			responseType: "blob",
		})
		return response.data
	} catch (error) {
		console.error("Error getting file:", error)
		throw error
	}
}

export const deleteFile = async (id: string) => {
	try {
		const response = await axios.delete(`${VITE_BASE_URL}/${id}`, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
		})
		return response
	} catch (error) {
		console.error("Error deleting file:", error)
		throw error
	}
}
