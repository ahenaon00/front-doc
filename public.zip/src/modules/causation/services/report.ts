import axios from "axios"
import Cookies from "js-cookie"
import { consolidateTransactionEntities } from "@/modules/causation/services/transactionEntity"

const VITE_BASE_URL = import.meta.env.VITE_BASE_URL + "/api/wo" // Replace with your API base URL// Replace with your API base URL
// Get
export const getWoReport = async (invoiceIds: string[] = []) => {
	try {
		// 1. Primero descargar el reporte
		const response = await axios.get(`${VITE_BASE_URL}/test`, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
			responseType: "blob",
			params: { invoiceIds: invoiceIds.length > 0 ? invoiceIds.join(",") : undefined },
		})

		// 2. Crear enlace de descarga
		const url = window.URL.createObjectURL(new Blob([response.data]))
		const link = document.createElement("a")
		link.href = url
		link.setAttribute("download", "report.xlsx")
		document.body.appendChild(link)
		link.click()
		document.body.removeChild(link)

		// 3. Actualizar estados (PUT y PATCH)
		if (invoiceIds.length > 0) {
			await consolidateTransactionEntities(invoiceIds)

			//await updateInvoiceERPStatus(invoiceIds)
		}

		return { success: true, data: response.data }
	} catch (error) {
		console.error("Error:", error)
		return { success: false, error }
	}
}
