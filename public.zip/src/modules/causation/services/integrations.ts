import axios from "axios"
import Cookies from "js-cookie"

const VITE_BASE_URL = import.meta.env.VITE_BASE_URL + "/api/integrations"

export const createIntegration = async () => {
	try {
		const response = await axios.post(
			VITE_BASE_URL,
			{
				name: "Otros", // Se envía como "Otros" al backend
				apiKey: "", // Se envían vacíos porque es "Otros"
				apiSecret: "",
				onPremise: false,
			},
			{
				headers: {
					"Authorization": `Bearer ${Cookies.get("token")}`,
					"Content-Type": "application/json",
				},
			},
		)
		return response.data
	} catch (error) {
		console.error("Error creating integration:", error)
		throw error
	}
}

export const getIntegrationfindByUID = async () => {
	try {
		const response = await axios.get(VITE_BASE_URL, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data // This is returning the data directly, not { data: ... }
	} catch (error) {
		console.error("Error fetching integration:", error)
		throw error
	}
}

export const getIntegrationById = async (id: string) => {
	try {
		const response = await axios.get(`${VITE_BASE_URL}/${id}`, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error fetching integration:", error)
		throw error
	}
}
