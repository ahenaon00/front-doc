import axios from "axios"
import Cookies from "js-cookie"

const BASE_URL = import.meta.env.VITE_BASE_URL + "/api/exports"

// Get all templates for current user
export const getAllExportTemplates = async () => {
	try {
		const response = await axios.get(`${BASE_URL}/templates`, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error fetching templates:", error)
		return { success: false, error }
	}
}

// Get one template by ID
export const getExportTemplateById = async (id: string) => {
	try {
		const response = await axios.get(`${BASE_URL}/templates/${id}`, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error fetching template:", error)
		return { success: false, error }
	}
}

// Delete a template
export const deleteExportTemplate = async (id: string) => {
	try {
		const response = await axios.delete(`${BASE_URL}/templates/${id}`, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error deleting template:", error)
		return { success: false, error }
	}
}

// Create a new template (after selecting headers)
export const createExportTemplate = async (payload: {
	name: string
	fileType: string
	headerRowIndex: number
	columnMapping: Record<string, string | null>
	templateFileUrl: string
}) => {
	try {
		const response = await axios.post(`${BASE_URL}/templates`, payload, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error creating template:", error)
		return { success: false, error }
	}
}

// Update existing template
export const updateExportTemplate = async (
	id: string,
	updates: Partial<{
		name: string
		headerRowIndex: number
		columnMapping: Record<string, string | null>
	}>,
) => {
	try {
		const response = await axios.put(`${BASE_URL}/templates/${id}`, updates, {
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		})
		return response.data
	} catch (error) {
		console.error("Error updating template:", error)
		return { success: false, error }
	}
}

export const uploadTemplateFile = async (file: File) => {
	try {
		const formData = new FormData()
		formData.append("file", file)

		const response = await axios.post(`${BASE_URL}/templates/upload`, formData, {
			headers: {
				"Authorization": `Bearer ${Cookies.get("token")}`,
				"Content-Type": "multipart/form-data",
			},
		})

		return response.data
	} catch (error) {
		console.error("Upload error:", error)
		return { success: false, error }
	}
}

export const getExportFieldsCatalog = async () => {
	try {
		const response = await axios.get(`${BASE_URL}/catalogs`, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
		})
		return response.data
	} catch (error) {
		console.error("Error fetching export catalog:", error)
		return { success: false, error }
	}
}

export const generateAndDownloadTemplate = async (invoiceIds: string[], templateId: string) => {
	const response = await axios.post(
		`${BASE_URL}/generate-file`,
		{ invoiceIds, templateId },
		{
			responseType: "blob",
			headers: { Authorization: `Bearer ${Cookies.get("token")}` },
		},
	)
	console.log(response)

	const url = window.URL.createObjectURL(new Blob([response.data]))
	const link = document.createElement("a")
	link.href = url
	link.setAttribute("download", `export-${Date.now()}.xlsx`)
	document.body.appendChild(link)
	link.click()
	document.body.removeChild(link)
}
