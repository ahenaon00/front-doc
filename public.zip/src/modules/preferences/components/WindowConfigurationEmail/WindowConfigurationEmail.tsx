import { useTranslation } from "react-i18next"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/modules/common/components/ui/dialog"
import {
	Accordion,
	AccordionItem,
	AccordionTrigger,
	AccordionContent,
} from "@/modules/common/components/ui/accordion"
import { renderSteps } from "@/modules/common/lib/utils/RenderSteps"

interface Props {
	show?: boolean
	onClose?: () => void
}

function WindowConfigurationEmail({ show, onClose }: Props) {
	const { t } = useTranslation("windowConfigEmail")

	return (
		<Dialog
			open={show}
			onOpenChange={(val) => {
				if (!val && onClose) onClose()
			}}
		>
			<DialogContent>
				<div className="px-14 py-6">
					<DialogHeader>
						<DialogTitle>{t("dialogTitle")}</DialogTitle>
					</DialogHeader>

					<Accordion type="single" collapsible className="w-full mt-2">
						<AccordionItem value="item-1">
							<AccordionTrigger>{t("accordion.step1Title")}</AccordionTrigger>
							<AccordionContent>
								{renderSteps(t("accordion.step1Desc", { returnObjects: true }) as any[])}
							</AccordionContent>
						</AccordionItem>
						<AccordionItem value="item-2">
							<AccordionTrigger>{t("accordion.step2Title")}</AccordionTrigger>
							<AccordionContent>
								{renderSteps(t("accordion.step2Desc", { returnObjects: true }) as any[])}
							</AccordionContent>
						</AccordionItem>
					</Accordion>
				</div>
			</DialogContent>
		</Dialog>
	)
}

export default WindowConfigurationEmail
