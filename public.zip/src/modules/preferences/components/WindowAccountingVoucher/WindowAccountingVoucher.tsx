import { useTranslation } from "react-i18next"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/modules/common/components/ui/dialog"
import {
	Accordion,
	AccordionItem,
	AccordionTrigger,
	AccordionContent,
} from "@/modules/common/components/ui/accordion"
import { DialogTrigger } from "@radix-ui/react-dialog"
import { Button } from "@/modules/common/components/ui/button"
import { renderSteps } from "@/modules/common/lib/utils/RenderSteps"

interface Props {
	show?: boolean
	onClose?: () => void
}

export default function WindowAccountingVoucher({ show, onClose }: Props) {
	const { t } = useTranslation("windowAccountingVoucher")

	return (
		<Dialog
			open={show}
			onOpenChange={(val) => {
				if (!val && onClose) onClose()
			}}
		>
			<DialogContent>
				<div className="px-14 py-6">
					<DialogHeader>
						<DialogTitle>{t("dialogTitle")}</DialogTitle>
					</DialogHeader>

					<Accordion type="single" collapsible className="w-full mt-2">
						<AccordionItem value="item-1">
							<AccordionTrigger>{t("accordion.step1Title")}</AccordionTrigger>
							<AccordionContent>
								{renderSteps(t("accordion.step1DescP1", { returnObjects: true }) as any[])}
								<Dialog>
									<DialogTrigger asChild>
										<Button variant="link" className="relative text-primary-green-1400 underline p-0 mr-4 bottom-2">
											{t("accordion.step1Img1")}
										</Button>
									</DialogTrigger>
									<DialogContent>
										<img
											src="/imgs/siigoAccountingVoucherConfig1.png"
											alt="siigoAccountingVoucherConfig1"
										/>
									</DialogContent>
								</Dialog>
								<Dialog>
									<DialogTrigger asChild>
										<Button variant="link" className="relative text-primary-green-1400 underline p-0 bottom-2">
											{t("accordion.step1Img2")}
										</Button>
									</DialogTrigger>
									<DialogContent className="min-w-[100vw] md:min-w-[90vw]">
										<img
											src="/imgs/siigoAccountingVoucherConfig2.png"
											alt="siigoAccountingVoucherConfig2"
										/>
									</DialogContent>
								</Dialog>
								{renderSteps(t("accordion.step1DescP2", { returnObjects: true }) as any[], 5)}
							</AccordionContent>
						</AccordionItem>
					</Accordion>
				</div>
			</DialogContent>
		</Dialog>
	)
}
