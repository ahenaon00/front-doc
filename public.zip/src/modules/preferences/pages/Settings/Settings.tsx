import { useEffect, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { createSelector } from "reselect"
import Cookies from "js-cookie"
import { useTranslation } from "react-i18next"
import Header from "@/modules/common/components/app/Header/Header"

import { updatePreferences } from "../../../auth/services/user"
import { editUser } from "@/modules/common/lib/redux/userSlice"
import { Button } from "@/modules/common/components/ui/button"
import WindowConfigurationEmail from "@/modules/preferences/components/WindowConfigurationEmail/WindowConfigurationEmail"
import WindowAccountingVoucher from "@/modules/preferences/components/WindowAccountingVoucher/WindowAccountingVoucher"
import { toast } from "sonner"
import { Separator } from "@/modules/common/components/ui/separator"
import { BellRing, ChartLine, Cpu, Info, Languages } from "lucide-react"
import { Label } from "@radix-ui/react-label"
import {
	Select,
	SelectContent,
	SelectGroup,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@/modules/common/components/ui/select"
import { Checkbox } from "@/modules/common/components/ui/checkbox"

const selectUser = createSelector(
	(state) => state.user,
	(user) => user,
)

export default function Settings() {
	const { t, i18n } = useTranslation(["profile"])
	const dispatch = useDispatch()
	const user = useSelector(selectUser)

	const [lang, setLang] = useState(i18n.language.split("-")[0] ?? "es")
	const [preferences, setPreferences] = useState({
		inventoryManagement: user.preferences?.inventoryManagement || "general",
		salesPullConcurrency: user.preferences?.salesPullConcurrency || "fortnightly",
		inferPucAi: user.preferences?.inferPucAi || false,
		notificationsFrequency: user.preferences?.notificationsFrequency || "Daily",
	})

	const [showEmailConfig, setShowEmailConfig] = useState(false)
	const [showAccountingVoucherConfig, setShowAccountingVoucherConfig] = useState(false)

	const handleLanguageChange = (value: string) => {
		setLang(value)
	}

	const savePreferences = async () => {
		try {
			const token = Cookies.get("token")

			await Promise.all([
				updatePreferences(token!, {
					preferences,
				}),
				i18n.changeLanguage(lang),
			])
			dispatch(editUser({ preferences }))
			toast.success(t("labels.saved"))
		} catch (error) {
			console.error("Error al guardar preferencias:", error)
		}
	}

	useEffect(() => {
		if (user?.preferences) {
			setPreferences({
				inventoryManagement: user.preferences.inventoryManagement || "general",
				salesPullConcurrency: user.preferences.salesPullConcurrency || "fortnightly",
				inferPucAi: user.preferences.inferPucAi || false,
				notificationsFrequency: user.preferences.notificationsFrequency || "Daily",
			})
		}
	}, [user])

	return (
		<>
			<Header title={t("profile.titleSettings")} />
			<main className="px-12 w-full py-8 flex flex-col gap-12">
				<h1 className="text-2xl">{t("profile.preferences")}</h1>
				<section className="grid grid-cols-2 gap-8">
					<article className="flex gap-8 items-center">
						<Label htmlFor="language" className="flex gap-4 items-center w-2/3">
							<Languages />
							<div>
								<h2 className="text-lg">{t("labels.language")}</h2>
								<p className="text-sm">{t("labels.languageDescription")}</p>
							</div>
						</Label>
						<Select onValueChange={handleLanguageChange} defaultValue={i18n.language.split("-")[0]}>
							<SelectTrigger id="language" className="border-primary-grey-600 max-w-32">
								<SelectValue />
							</SelectTrigger>
							<SelectContent>
								<SelectGroup>
									<SelectItem value="es">{t("profile.buttons.Español")}</SelectItem>
									<SelectItem value="en">{t("profile.buttons.English")}</SelectItem>
								</SelectGroup>
							</SelectContent>
						</Select>
					</article>
					<article className="flex gap-8 items-center">
						<Label htmlFor="notifications" className="flex gap-4 items-center w-2/3">
							<BellRing />
							<div>
								<h2 className="text-lg">{t("labels.notifications")}</h2>
								<p className="text-sm">{t("labels.notificationsDescription")}</p>
							</div>
						</Label>
						<Select
							onValueChange={(value) =>
								setPreferences({
									...preferences,
									notificationsFrequency: value as string,
								})
							}
							defaultValue={preferences.notificationsFrequency}
						>
							<SelectTrigger id="notifications" className="border-primary-grey-600 max-w-32">
								<SelectValue />
							</SelectTrigger>
							<SelectContent>
								<SelectGroup>
									<SelectItem value="Daily">{t("profile.buttons.Diario")}</SelectItem>
									<SelectItem value="Weekly">{t("profile.buttons.Semanal")}</SelectItem>
									<SelectItem value="Fortnightly">{t("profile.buttons.Quincenal")}</SelectItem>
								</SelectGroup>
							</SelectContent>
						</Select>
					</article>
					<article className="flex gap-8 items-center">
						<Label htmlFor="sales" className="flex gap-4 items-center w-2/3">
							<ChartLine />
							<div>
								<h2 className="text-lg">{t("labels.sales")}</h2>
								<p className="text-sm">{t("labels.salesDescription")}</p>
							</div>
						</Label>
						<Select
							onValueChange={(value) =>
								setPreferences({
									...preferences,
									salesPullConcurrency: value as string,
								})
							}
							defaultValue={preferences.salesPullConcurrency}
						>
							<SelectTrigger id="sales" className="border-primary-grey-600 max-w-32">
								<SelectValue />
							</SelectTrigger>
							<SelectContent>
								<SelectGroup>
									<SelectItem value="fortnightly">{t("profile.options.fortnightly")}</SelectItem>
									<SelectItem value="monthly">{t("profile.options.monthly")}</SelectItem>
									<SelectItem value="quarterly">{t("profile.options.quarterly")}</SelectItem>
								</SelectGroup>
							</SelectContent>
						</Select>
					</article>
					<article className="flex gap-8 items-center">
						<Label htmlFor="inferPUC" className="flex gap-4 items-center w-2/3">
							<Cpu />
							<div>
								<h2 className="text-lg">{t("labels.inferPUC")}</h2>
								<p className="text-sm">{t("labels.inferPUCDescription")}</p>
							</div>
						</Label>
						<div className="w-full max-w-32 flex items-center">
							<Checkbox
								id="inferPUC"
								className="text-primary-green-1200 bg-primary-grey-25 shadow-none"
								checked={preferences.inferPucAi}
								onCheckedChange={(checked) =>
									setPreferences({
										...preferences,
										inferPucAi: checked,
									})
								}
							/>
						</div>
					</article>
					<Separator className="col-span-2" />
					<article className="flex gap-4 items-center">
						<Info />
						<div>
							<h2 className="text-lg">{t("labels.emailConfig")}</h2>
							<Button
								variant="link"
								id="emailConfigGuide"
								className="text-primary-green-1400 underline p-0 m-0 h-fit"
								onClick={() => setShowEmailConfig(true)}
							>
								{t("emailConfig.button")}
							</Button>
						</div>
					</article>
					<article className="flex gap-4 items-center">
						<Info />
						<div>
							<h2 className="text-lg">{t("labels.accountingVoucherConfig")}</h2>
							<Button
								variant="link"
								className="text-primary-green-1400 underline p-0 m-0 h-fit"
								onClick={() => setShowAccountingVoucherConfig(true)}
							>
								{t("accountingVoucherConfig.button")}
							</Button>
						</div>
					</article>
				</section>
				<Button variant="primary" className="w-fit" onClick={savePreferences}>
					{t("profile.buttons.savePreferences")}
				</Button>
			</main>
			<WindowConfigurationEmail show={showEmailConfig} onClose={() => setShowEmailConfig(false)} />
			<WindowAccountingVoucher
				show={showAccountingVoucherConfig}
				onClose={() => setShowAccountingVoucherConfig(false)}
			/>
		</>
	)
}
