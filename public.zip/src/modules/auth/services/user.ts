import axios from "axios"
import Cookies from "js-cookie"
const API_URL = import.meta.env.VITE_BASE_URL + "/api/user"

// Create a new user
export const createUser = async (userData: any) => {
	try {
		const response = await axios.post(`${API_URL}/create`, userData)
		return response
	} catch (error) {
		console.error("Error creating user:", error)
		throw error
	}
}

//Login user
export const loginUser = async (userData: any) => {
	const { email, password } = userData
	try {
		const response = await axios.post(`${API_URL}/login`, {
			email,
			password,
		})
		return response
	} catch (error) {
		console.error("Error authenticating user:", error)
		throw error
	}
}

// Verify user
export const authOTP = async (token: string, otp: string) => {
	try {
		const response = await axios.post(`${API_URL}/auth-otp`, {
			otp,
			token,
		})
		return response
	} catch (error) {
		console.error("Error authenticating user:", error)
		throw error
	}
}

//Authenticating user
export const authToken = async (): Promise<any> => {
	try {
		const response = await axios.get(`${API_URL}/auth`, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
		})
		return response
	} catch (error) {
		console.error("Error:", error)
	}
}

export const verifyToken = async (token: string) => {
	try {
		const response = await axios.get(`${API_URL}/auth`, {
			headers: {
				Authorization: `Bearer ${token}`,
			},
		})
		return response
	} catch (error) {
		console.error("Error:", error)
	}
}

//Reset password
export const resetPassword = async (userData: any) => {
	const { email } = userData
	try {
		const response = await axios.post(`${API_URL}/reset-password`, {
			email,
		})
		return response
	} catch (error) {
		console.error("Error resetting password:", error)
		throw error
	}
}

// Update password
export const updatePassword = async (token: string, password: string) => {
	try {
		const response = await axios.post(`${API_URL}/update-password`, {
			token,
			password,
		})
		return response
	} catch (error) {
		console.error("Error updating password:", error)
		throw error
	}
}

// Get all users
export const getUsers = async () => {
	try {
		const response = await axios.get(API_URL)
		return response.data
	} catch (error) {
		console.error("Error getting users:", error)
		throw error
	}
}

// Get a user by ID
export const getUserById = async (userId: string) => {
	try {
		const response = await axios.get(`${API_URL}/${userId}`)
		return response.data
	} catch (error) {
		console.error("Error getting user:", error)
		throw error
	}
}

export const updatePreferences = async (token: string, preferences: any) => {
	try {
		const response = await axios.put(`${API_URL}/preferences`, preferences, {
			headers: {
				Authorization: `Bearer ${token}`,
			},
		})
		return response.data
	} catch (error) {
		console.error("Error updating preferences:", error)
		throw error
	}
}

// Update a user
export const updateUser = async (token: string, userData: any) => {
	try {
		const response = await axios.put(`${API_URL}/update`, userData, {
			headers: {
				Authorization: `Bearer ${token}`,
			},
		})
		return response.data
	} catch (error) {
		console.error("Error updating user:", error)
		throw error
	}
}
// Update a userNew
export const updateUserNew = async () => {
	try {
		const response = await axios.put(
			`${API_URL}/update`, {},
			{
				headers: {
					Authorization: `Bearer ${Cookies.get("token")}`,
				},
			}
		)
		return response
	} catch (error) {
		console.error("Error updating user:", error)
		throw error
	}
}

// Delete a user
export const deleteUser = async (userId: string) => {
	try {
		const response = await axios.delete(`${API_URL}/${userId}`)
		return response.data
	} catch (error) {
		console.error("Error deleting user:", error)
		throw error
	}
}

export const verifyUser = async (token: string) => {
	try {
		const response = await axios.get(`${API_URL}/verify/${token}`)
		return response
	} catch (error) {
		console.error("Error verifying user:", error)
		throw error
	}
}

export async function updateFrecuencyEmails(frecuency: string) {
	try {
		const response = await axios.put(`${API_URL}/update-frecuency-emails`, { frecuency }, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
		}
		)
		return response
	} catch (error) {
		console.error("Error updating frecuency emails:", error)
		throw error
	}
}
// Obtiene la frecuencia de notificaciones desde la base de datos
export const getFrecuencyEmails = async () => {
	try {
		const response = await axios.get(`${API_URL}/get-frecuency-emails`, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
		});
		return response.data.frequency;
	} catch (error) {
		console.error("Error al obtener la frecuencia de notificaciones:", error);
		throw error;
	}
};

