import { FormEventHandler, useEffect, useState } from "react"
import { useTranslation } from "react-i18next"

import {
	createIntegration,
	authorizeIntegration,
	getIntegrationbyUID,
	updateIntegration,
} from "@/modules/auth/services/integrations"
import { updateUserNew } from "@/modules/auth/services/user"
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogDescription,
} from "@/modules/common/components/ui/dialog"
import { Button } from "@/modules/common/components/ui/button"
import { Input } from "@/modules/common/components/ui/input"
import { Label } from "@/modules/common/components/ui/label"
import {
	Accordion,
	AccordionItem,
	AccordionTrigger,
	AccordionContent,
} from "@/modules/common/components/ui/accordion"
import {
	HoverCard,
	HoverCardTrigger,
	HoverCardContent,
} from "@/modules/common/components/ui/hover-card"
import { CalendarIcon, Eye, EyeClosed } from "lucide-react"
import { useDispatch } from "react-redux"
import { startProgress } from "@/modules/common/lib/redux/progressSlice"

interface Props {
	show?: boolean
	onClose?: () => void
}

function WindowApiKey({ show, onClose }: Props) {
	const { t } = useTranslation("windowApiKey")

	// Estados principales
	const [apiUser, setApiUser] = useState("")
	const [apiSecret, setApiSecret] = useState("")
	const [originalApiUser, setOriginalApiUser] = useState("")
	const [originalApiSecret, setOriginalApiSecret] = useState("")
	const [isLoading, setIsLoading] = useState(false)
	const [haveApi, setHaveApi] = useState(false)
	const [isEditing, setIsEditing] = useState(false)
	const [showPassword, setShowPassword] = useState(false)

	const dispatch = useDispatch()

	/**
	 * Al montar el componente, consultamos si ya existe la integración.
	 * Si sí existe, guardamos los valores y bloqueamos los inputs.
	 */
	useEffect(() => {
		const checkIntegration = async () => {
			try {
				const result = await getIntegrationbyUID()
				if (result?.apiKey && result?.apiSecret) {
					setApiUser(result.apiKey)
					setApiSecret(result.apiSecret)
					setOriginalApiUser(result.apiKey)
					setOriginalApiSecret(result.apiSecret)
					setHaveApi(true)
				}
			} catch (error) {
				console.error("Error fetching integration:", error)
			}
		}
		checkIntegration()
	}, [])

	// Manejo del envío del formulario
	const handleSubmit: FormEventHandler<HTMLFormElement> = async (e) => {
		e.preventDefault()

		setIsLoading(true)
		try {
			// Autorizar la integración
			const authresponse = await authorizeIntegration({
				apiKey: apiUser,
				apiSecret: apiSecret,
			})

			if (authresponse.status === 200) {
				// Crear o actualizar integración
				if (haveApi) {
					await updateIntegration({
						name: "Siigo",
						apiKey: apiUser,
						apiSecret: apiSecret,
					})
				} else {
					await createIntegration({
						name: "Siigo",
						onPremise: false,
						apiKey: apiUser,
						apiSecret: apiSecret,
					})
				}

				dispatch(startProgress())
				await updateUserNew()

				// Actualizar valores originales después de guardar
				setOriginalApiUser(apiUser)
				setOriginalApiSecret(apiSecret)
				setHaveApi(true)
				setIsEditing(false)
			}
		} catch (error) {
			console.error("Error during submission:", error)
		} finally {
			setIsLoading(false)
		}
	}

	const handleCancelEdit = () => {
		// Restaurar valores originales
		setApiUser(originalApiUser)
		setApiSecret(originalApiSecret)
		setIsEditing(false)
	}

	return (
		<Dialog
			open={show}
			onOpenChange={(val) => {
				if (!val && onClose) onClose()
			}}
		>
			<DialogContent>
				<div className="px-14 py-6">
					<DialogHeader>
						<DialogTitle>{t("dialogTitle")}</DialogTitle>
					</DialogHeader>

					{/* Acordeón con pasos para obtener llaves */}
					<Accordion type="single" collapsible className="w-full mt-2">
						<AccordionItem value="item-1">
							<AccordionTrigger>{t("accordion.step1Title")}</AccordionTrigger>
							<AccordionContent>
								{t("accordion.stepDesc")}{" "}
								<a
									className="text-primary-green-1400 underline"
									href="https://www.siigo.com"
									target="_blank"
									rel="noopener noreferrer"
								>
									{"siigo.com"}
								</a>{" "}
								{t("accordion.step1Desc")}
							</AccordionContent>
						</AccordionItem>
						<AccordionItem value="item-2">
							<AccordionTrigger>{t("accordion.step2Title")}</AccordionTrigger>
							<AccordionContent>{t("accordion.step2Desc")}</AccordionContent>
						</AccordionItem>
						<AccordionItem value="item-3">
							<AccordionTrigger>{t("accordion.step3Title")}</AccordionTrigger>
							<AccordionContent>{t("accordion.step3Desc")}</AccordionContent>
						</AccordionItem>
					</Accordion>

					{/* Descripción del diálogo con HoverCard */}
					<DialogDescription className="mt-4">
						{t("dialogDescription.beforeHoverCard")}{" "}
						<HoverCard>
							<HoverCardTrigger asChild>
								<a
									className="text-primary-green-1400 underline"
									href="https://youtu.be/bijTt6s5sFs"
									target="_blank"
									rel="noopener noreferrer"
								>
									{t("dialogDescription.videoButton")}
								</a>
							</HoverCardTrigger>
							<HoverCardContent className="w-80">
								<div className="flex justify-between space-x-4">
									<div className="space-y-1">
										<h4 className="text-sm font-semibold">{t("dialogDescription.videoTitle")}</h4>
										<p className="text-sm">{t("dialogDescription.videoDesc")}</p>
										<div className="flex items-center pt-2">
											<CalendarIcon className="mr-2 h-4 w-4 opacity-70" />
											<span className="text-xs text-muted-foreground">
												{t("dialogDescription.videoDate")}
											</span>
										</div>
									</div>
								</div>
							</HoverCardContent>
						</HoverCard>
					</DialogDescription>

					{/* Formulario principal */}
					<form onSubmit={handleSubmit} className="mt-6 space-y-4 flex flex-col">
						{/* Input: API User */}
						<div className="flex flex-col gap-2">
							<Label htmlFor="apiUser">{t("form.apiUser")}</Label>
							<Input
								id="apiUser"
								value={apiUser}
								onChange={(e) => setApiUser(e.target.value)}
								readOnly={!isEditing && haveApi}
							/>
						</div>

						{/* Input: API Secret */}
						<div className="flex flex-col gap-2">
							<Label htmlFor="apiSecret">{t("form.apiSecret")}</Label>
							<div className="relative">
								<Input
									id="apiSecret"
									type={showPassword ? "text" : "password"}
									value={apiSecret}
									onChange={(e) => setApiSecret(e.target.value)}
									readOnly={!isEditing && haveApi}
									className="w-full pr-12"
								/>
								<button
									type="button"
									className="absolute right-4 top-1/2 -translate-y-1/2"
									onClick={() => setShowPassword(!showPassword)}
								>
									{showPassword ? (
										<Eye className="h-6 w-6 text-primary-grey-1200 hover:text-primary-grey-2200" />
									) : (
										<EyeClosed className="h-6 w-6 text-primary-grey-1200 hover:text-primary-grey-2200" />
									)}
								</button>
							</div>
						</div>

						{/* Botones de acción */}
						{!haveApi ? (
							<Button
								type="submit"
								variant="primary"
								className="self-center w-fit"
								disabled={isLoading}
							>
								{isLoading ? t("Conectando") : t("Conectar")}
							</Button>
						) : isEditing ? (
							<div className="flex justify-evenly">
								<Button type="button" variant="secondary" onClick={handleCancelEdit}>
									{t("Cancelar")}
								</Button>
								<Button type="submit" variant="primary" disabled={isLoading}>
									{isLoading ? t("Conectando") : t("Conectar")}
								</Button>
							</div>
						) : (
							<Button
								type="button"
								variant="primary"
								className="self-center w-fit"
								onClick={() => setIsEditing(true)}
							>
								{t("Editar ApiKeys")}
							</Button>
						)}
					</form>
				</div>
			</DialogContent>
		</Dialog>
	)
}

export default WindowApiKey
