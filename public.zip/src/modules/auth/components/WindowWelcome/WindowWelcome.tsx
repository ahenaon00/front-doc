import { useState, useRef } from "react"
import { useTranslation } from "react-i18next"
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogDescription,
} from "@/modules/common/components/ui/dialog"
import { Button } from "@/modules/common/components/ui/button"
import WindowApiKey from "@/modules/auth/components/WindowApiKey/WindowApiKey"
import { ChevronDown, ChevronUp, UploadCloud, X, CheckCircle2 } from "lucide-react"
import { uploadOnboardingFile } from "@/modules/causation/services/file"
import WindowConfigurationEmail from "@/modules/preferences/components/WindowConfigurationEmail/WindowConfigurationEmail"
import { createIntegration } from "@/modules/causation/services/integrations"

function WindowWelcome() {
	const { t } = useTranslation("windowWelcome")
	const [isOpen, setIsOpen] = useState(true)
	const [showKeyRequest, setShowKeyRequest] = useState(false)
	const [showErpSelection, setShowErpSelection] = useState(true)
	const [showWorldOfficeInstructions, setShowWorldOfficeInstructions] = useState(false)
	const [selectedErp, setSelectedErp] = useState("")
	const [showUploadDialog, setShowUploadDialog] = useState(false)
	const [onboardingFiles, setOnboardingFiles] = useState<File[]>([])
	const [uploadStatus, setUploadStatus] = useState("")
	const [isUploading, setIsUploading] = useState(false)
	const [isDragging, setIsDragging] = useState(false)
	const [expandedSection, setExpandedSection] = useState(1)
	const fileInputRef = useRef<HTMLInputElement>(null)
	const [showSuccessDialog, setShowSuccessDialog] = useState(false)
	const [showEmailConfig, setShowEmailConfig] = useState(false)

	const MAX_FILES = 4

	const handleSubmit = (e: React.FormEvent<HTMLDivElement>) => {
		e.preventDefault()
		alert(t("messages.connectionSuccess"))
	}

	const handleCloseSuccessDialog = () => {
		setShowSuccessDialog(false)
		setIsOpen(false) // Cierra también el diálogo principal
	}

	const openWindowApiKey = () => {
		setIsOpen(false)
		setShowKeyRequest(true)
	}

	const openEmailConfig = () => {
		// Cerrar todos los diálogos actuales
		setShowSuccessDialog(false) // Cierra el diálogo de éxito
		setIsOpen(false) // Cierra el diálogo principal
		setShowUploadDialog(false) // Cierra el diálogo de carga de archivos si está abierto
		setShowKeyRequest(false) // Cierra la ventana de API Key si está abierta

		// Abre la ventana de configuración de email
		setShowEmailConfig(true)
	}

	const selectSiigo = () => {
		setShowErpSelection(false)
		openWindowApiKey()
	}

	const selectWorldOffice = () => {
		setShowErpSelection(false)
		setShowWorldOfficeInstructions(true)
	}

	const backToErpSelection = () => {
		setShowWorldOfficeInstructions(false)
		setShowErpSelection(true)
	}

	const handleConfirmSelection = async () => {
		if (selectedErp === "siigo") {
			selectSiigo()
		} else if (selectedErp === "world_office" || selectedErp === "other") {
			try {
				selectWorldOffice()
				await createIntegration()
			} catch (error) {
				console.error("Error al crear la integración:", error)
			}
		}
	}

	const handleErpChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
		setSelectedErp(e.target.value)
	}

	const toggleSection = (section: number) => {
		setExpandedSection(expandedSection === section ? 0 : section)
	}

	const validateFiles = (files: File[]) => {
		if (onboardingFiles.length + files.length > MAX_FILES) {
			setUploadStatus(`Solo puedes subir hasta ${MAX_FILES} archivos`)
			return false
		}

		const invalidFile = files.find(
			(file) =>
				![
					"application/vnd.ms-excel",
					"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
				].includes(file.type) && !file.name.match(/\.(xls|xlsx)$/),
		)

		if (invalidFile) {
			setUploadStatus("Solo se permiten archivos Excel (.xls, .xlsx)")
			return false
		}

		return true
	}

	const handleOnboardingFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		if (e.target.files && e.target.files.length > 0) {
			const newFiles = Array.from(e.target.files)
			if (validateFiles(newFiles)) {
				setOnboardingFiles((prev) => [...prev, ...newFiles])
				setUploadStatus("")
			}
		}
	}

	const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
		e.preventDefault()
		e.stopPropagation()
		setIsDragging(true)
	}

	const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
		e.preventDefault()
		e.stopPropagation()
		setIsDragging(false)
	}

	const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
		e.preventDefault()
		e.stopPropagation()
		if (!isDragging) setIsDragging(true)
	}

	const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
		e.preventDefault()
		e.stopPropagation()
		setIsDragging(false)
		if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
			const droppedFiles = Array.from(e.dataTransfer.files)
			if (validateFiles(droppedFiles)) {
				setOnboardingFiles((prev) => [...prev, ...droppedFiles])
				setUploadStatus("")
			}
		}
	}

	const removeFile = (index: number) => {
		setOnboardingFiles((prev) => prev.filter((_, i) => i !== index))
		setUploadStatus("")
	}

	const handleOnboardingFileUpload = async () => {
		if (onboardingFiles.length === 0) {
			setUploadStatus(t("messages.pleaseSelectFile") || "Selecciona al menos un archivo")
			return
		}

		setUploadStatus("Subiendo archivos...")
		setIsUploading(true)

		try {
			const response = await uploadOnboardingFile(onboardingFiles)
			console.log("Respuesta del servidor:", response.data)
			setUploadStatus("¡Archivos subidos correctamente!")

			// Mostrar mensaje de éxito
			setShowSuccessDialog(true)

			// Reset de estados después de un tiempo
			setTimeout(() => {
				setShowUploadDialog(false)
				setOnboardingFiles([])
				setUploadStatus("")
			}, 1500)
		} catch (error: any) {
			console.error("Error subiendo archivos:", error)

			let errorMessage = "Error desconocido al subir los archivos"
			if (error.response?.data?.message) {
				errorMessage = error.response.data.message
			} else if (error.response?.data?.error) {
				errorMessage = error.response.data.error
			} else if (error.message) {
				errorMessage = error.message
			}

			setUploadStatus(`Error: ${errorMessage}`)
		} finally {
			setIsUploading(false)
		}
	}

	return (
		<>
			{showKeyRequest && (
				<WindowApiKey show={showKeyRequest} onClose={() => setShowKeyRequest(false)} />
			)}
			{showEmailConfig && (
				<WindowConfigurationEmail
					show={showEmailConfig}
					onClose={() => setShowEmailConfig(false)}
				/>
			)}

			<Dialog open={isOpen} onOpenChange={setIsOpen}>
				<DialogContent className="max-w-2xl max-h-[70vh] overflow-y-auto">
					{showErpSelection && (
						<div className="px-6 py-6 flex flex-col gap-4 items-center">
							<DialogHeader className="text-center w-full space-y-1">
								<DialogTitle className="text-center text-xl font-bold">
									¡Bienvenidos a Bucks!
								</DialogTitle>
								<DialogDescription className="text-center mx-auto max-w-md text-sm">
									Accede a herramientas diseñadas para simplificar la gestión financiera y potenciar
									tus decisiones empresariales.
								</DialogDescription>
							</DialogHeader>

							<p className="text-center text-sm font-medium mt-2">
								Selecciona el ERP que utiliza tu empresa
							</p>

							<div className="w-full mt-2">
								<div className="relative w-full">
									<select
										className="w-full p-2 border rounded-md appearance-none bg-white pr-8 cursor-pointer"
										value={selectedErp}
										onChange={handleErpChange}
										data-testid="erp-select"
									>
										<option value="" disabled>
											Selecciona un ERP
										</option>
										<option value="siigo">Siigo</option>
										<option value="world_office">World Office</option>
										<option value="other">Otro ERP</option>
									</select>
									<div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
										<ChevronDown className="h-4 w-4 text-gray-500" />
									</div>
								</div>
							</div>

							<p className="text-center text-xs text-gray-500 mt-2">
								Si deseas cambiarlo más adelante,
								<br />
								por favor contacta al equipo de Bucks.
							</p>

							<Button
								variant="default"
								className="bg-green-500 hover:bg-green-600 text-white rounded-full py-2 px-6 mt-2"
								onClick={handleConfirmSelection}
								disabled={!selectedErp}
								data-testid="confirm-erp-button"
							>
								Confirmar
							</Button>
						</div>
					)}

					{showWorldOfficeInstructions && (
						<div className="px-6 py-4 flex flex-col gap-4">
							<DialogHeader className="text-center w-full mb-0 pb-0">
								<DialogTitle className="text-xl font-bold w-full">Guía de conexión:</DialogTitle>
							</DialogHeader>

							<div className="flex flex-col gap-2">
								{/* Step 1 */}
								<div className="border-b pb-4">
									<div
										className="flex justify-between items-center cursor-pointer"
										onClick={() => toggleSection(1)}
									>
										<h3 className="font-medium text-lg">
											1. Abre World Office y exporta los libros auxiliares de los últimos 3 años de
											operación de tu organización
										</h3>
										{expandedSection === 1 ? (
											<ChevronUp className="h-5 w-5 text-gray-500" />
										) : (
											<ChevronDown className="h-5 w-5 text-gray-500" />
										)}
									</div>
								</div>

								{/* Step 2 */}
								<div className="border-b py-4">
									<div
										className="flex justify-between items-center cursor-pointer"
										onClick={() => toggleSection(2)}
									>
										<h3 className="font-medium text-lg">2. Nombra los libros auxiliares</h3>
										{expandedSection === 2 ? (
											<ChevronUp className="h-5 w-5 text-gray-500" />
										) : (
											<ChevronDown className="h-5 w-5 text-gray-500" />
										)}
									</div>

									{expandedSection === 2 && (
										<div className="mt-4 ml-4">
											<p className="mb-2">
												Nombra cada uno de los archivos descargados con la siguiente estructura:
											</p>
											<ul className="list-disc ml-6">
												<li>Razón Social de tu empresa_Año del libro auxiliar.xls</li>
											</ul>
										</div>
									)}
								</div>

								{/* Step 3 */}
								<div className="border-b py-4">
									<div
										className="flex justify-between items-center cursor-pointer"
										onClick={() => toggleSection(3)}
									>
										<h3 className="font-medium text-lg">
											3. Sube los libros auxiliares que descargaste y guardaste. Puedes subir hasta
											4 archivos en formato de Excel
										</h3>
										{expandedSection === 3 ? (
											<ChevronUp className="h-5 w-5 text-gray-500" />
										) : (
											<ChevronDown className="h-5 w-5 text-gray-500" />
										)}
									</div>
								</div>

								{/* File Upload Section */}
								<div className="mt-4">
									<div className="flex items-center gap-2">
										<button
											className="flex items-center text-green-600 font-medium"
											onClick={() => setShowUploadDialog(true)}
											data-testid="upload-file-button"
										>
											<span className="flex items-center justify-center h-6 w-6 rounded-full bg-green-600 text-white mr-2">
												+
											</span>
											Subir archivo
										</button>
										<span className="text-gray-500 ml-auto">Archivos compatibles: xls, xlsx.</span>
									</div>
								</div>

								{onboardingFiles.length > 0 && (
									<div className="mt-4">
										{onboardingFiles.map((file, index) => (
											<div key={index} className="flex items-center justify-between py-2 border-b">
												<div className="flex items-center">
													<span className="text-green-600 mr-2">📄</span>
													<span>{file.name}</span>
												</div>
												<button onClick={() => removeFile(index)} className="text-gray-500">
													<X size={16} />
												</button>
											</div>
										))}
									</div>
								)}

								{/* Note Section */}
								<div className="mt-4">
									<p className="text-gray-700">
										Nuestro equipo procesará la información y te notificaremos cuando esté lista.
									</p>
									<p className="mt-2 font-bold">
										Nota: Esta información es clave para entrenar nuestro modelo PUC con tu
										historial contable.
									</p>
								</div>

								{/* Actions */}
								<div className="mt-6 flex justify-between">
									<Button
										variant="outline"
										className="text-gray-700 rounded-full py-2 px-8"
										onClick={backToErpSelection}
									>
										Volver
									</Button>
									<Button
										variant="default"
										className="bg-green-500 hover:bg-green-600 text-white rounded-full py-2 px-8"
										onClick={() => setShowUploadDialog(true)}
										data-testid="connect-button"
									>
										Subir Archivos
									</Button>
								</div>
							</div>
						</div>
					)}

					{!showErpSelection && !showWorldOfficeInstructions && (
						<div className="px-12 py-6 flex flex-col gap-5 items-center">
							<DialogHeader className="text-center w-full">
								<DialogTitle className="text-center text-xl font-bold w-full">
									¡Bienvenidos a Bucks!
								</DialogTitle>
							</DialogHeader>
							<p className="text-center">
								Accede a herramientas diseñadas para simplificar la gestión financiera y potenciar
								tus decisiones empresariales.
							</p>
							<p className="text-center font-bold">
								Conecta las API Keys de tu software contable y comienza a optimizar tus procesos.
							</p>
							<div onSubmit={handleSubmit} className="mt-6 space-y-4">
								<div className="flex justify-center">
									<Button
										variant="primary"
										type="button"
										className="bg-green-500 hover:bg-green-600 text-white rounded-full py-2 px-6"
										onClick={openWindowApiKey}
									>
										Conecta Tus API Keys
									</Button>
								</div>
								<DialogDescription className="mt-4 text-center">
									¿No sabes cómo hacerlo? Sigue esta{" "}
									<a className="text-green-500 underline cursor-pointer" onClick={openWindowApiKey}>
										guía
									</a>
									.
								</DialogDescription>
							</div>
						</div>
					)}
				</DialogContent>
			</Dialog>

			<Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
				<DialogContent className="max-w-xl">
					<DialogHeader>
						<DialogTitle className="text-primary-green-1200">
							{t("Subir archivos Excel")}
						</DialogTitle>
						<DialogDescription className="text-primary-grey-1800">
							{t("Puedes subir hasta 4 archivos Excel (.xls, .xlsx)")}
						</DialogDescription>
					</DialogHeader>

					<div className="flex flex-col gap-4">
						{onboardingFiles.length > 0 && (
							<div className="border rounded-md p-3">
								<h4 className="font-medium mb-2">
									Archivos seleccionados: {onboardingFiles.length}/{MAX_FILES}
								</h4>
								<ul className="space-y-2">
									{onboardingFiles.map((file, index) => (
										<li
											key={index}
											className="flex justify-between items-center p-2 bg-gray-50 rounded"
										>
											<span className="truncate max-w-xs">{file.name}</span>
											<button
												onClick={() => removeFile(index)}
												className="text-red-500 hover:text-red-700"
												data-testid={`remove-file-${index}`}
											>
												<X size={16} />
											</button>
										</li>
									))}
								</ul>
							</div>
						)}

						<div
							className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
								isDragging
									? "border-primary-green-800 bg-primary-green-50"
									: "border-primary-grey-400 hover:bg-primary-green-50"
							}`}
							onDragEnter={handleDragEnter}
							onDragLeave={handleDragLeave}
							onDragOver={handleDragOver}
							onDrop={handleDrop}
							onClick={() => fileInputRef.current?.click()}
							data-testid="dropzone"
						>
							<input
								type="file"
								accept=".xls,.xlsx"
								onChange={handleOnboardingFileChange}
								className="hidden"
								id="file-upload"
								ref={fileInputRef}
								multiple
								data-testid="file-input"
							/>
							<div className="cursor-pointer flex flex-col items-center gap-2">
								<UploadCloud
									className={`h-12 w-12 ${
										isDragging ? "text-primary-green-800" : "text-primary-green-1200"
									}`}
								/>
								<span
									className={`font-medium ${
										isDragging ? "text-primary-green-800" : "text-primary-green-1200"
									}`}
								>
									{isDragging ? "Suelta los archivos aquí" : "Arrastra archivos o haz clic aquí"}
								</span>
								<span className="text-sm text-primary-grey-1800">
									{onboardingFiles.length > 0
										? `${onboardingFiles.length} archivo(s) seleccionado(s)`
										: t("Formatos soportados: .xls, .xlsx")}
								</span>
								<span className="text-xs text-primary-grey-800">Máximo {MAX_FILES} archivos</span>
							</div>
						</div>

						{uploadStatus && (
							<div
								className={`px-4 py-2 rounded-md ${
									uploadStatus.includes("correctamente") || uploadStatus.includes("¡Archivos")
										? "bg-green-100 text-green-700"
										: uploadStatus.includes("Subiendo")
											? "bg-blue-100 text-blue-700"
											: "bg-red-100 text-red-700"
								}`}
								data-testid="upload-status"
							>
								{uploadStatus}
							</div>
						)}

						<div className="flex justify-end gap-3 mt-4">
							<Button
								variant="quiet"
								onClick={() => {
									setShowUploadDialog(false)
									setUploadStatus("")
								}}
								className="text-primary-grey-1800"
								data-testid="cancel-upload"
							>
								{t("Cancelar")}
							</Button>
							<Button
								variant="primary"
								onClick={handleOnboardingFileUpload}
								disabled={onboardingFiles.length === 0 || isUploading}
								data-testid="confirm-upload"
							>
								{isUploading ? "Subiendo..." : t("Subir Archivos")}
							</Button>
						</div>
					</div>
				</DialogContent>
			</Dialog>

			<Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
				<DialogContent className="max-w-md py-6">
					<div className="flex flex-col items-center text-center">
						{/* Ícono de check verde */}
						<div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
							<CheckCircle2 className="h-8 w-8 text-green-500" />
						</div>

						{/* Título */}
						<h2 className="text-lg font-semibold text-gray-800 mb-4">
							¡Tu información ha sido recibida con éxito!
						</h2>

						{/* Texto informativo */}
						<p className="text-sm text-gray-600 mb-1">
							No olvides configurar tu correo electrónico,
							<br />
							consulta cómo hacerlo{" "}
							<a href="#" className="text-green-500" onClick={openEmailConfig}>
								aquí
							</a>
						</p>

						<p className="text-sm text-gray-600 mb-6">
							Nuestro equipo procesará la información de tus
							<br />
							libros contables y te notificaremos cuando todo
							<br />
							esté listo para que puedas visualizarla.
						</p>

						{/* Botón */}
						<Button
							variant="default"
							className="bg-gray-900 hover:bg-gray-800 text-green-400 font-semibold rounded-full px-6"
							onClick={handleCloseSuccessDialog}
							data-testid="success-ok-button"
						>
							Entendido
						</Button>
					</div>
				</DialogContent>
			</Dialog>
		</>
	)
}

export default WindowWelcome
