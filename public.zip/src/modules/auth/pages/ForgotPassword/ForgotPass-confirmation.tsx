// export const SucessMessage = () => {
//   return (
//     <div className="login-register">
//       <div className="custom-container">
//         <form>
//           <h1>Email enviado de forma exitosa</h1>
//           <p>Revisa tu Email, Hemos enviado un link para restablecer la contraseña</p>
//         </form>
//       </div>
//     </div>
//   );
// };

export const SucessMessage = () => {
  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-50 p-5">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-10 text-center">
        <div className="flex justify-center mb-6">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="currentColor"
            className="w-16 h-16 text-green-500"
          >
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
          </svg>
        </div>
        <h1 className="text-2xl font-semibold text-gray-800 mb-4">
          Email enviado de forma exitosa
        </h1>
        <p className="text-gray-600">
           Revisa tu Email, Hemos enviado un link para restablecer la contraseña
        </p>
      </div>
    </div>
  );
};
