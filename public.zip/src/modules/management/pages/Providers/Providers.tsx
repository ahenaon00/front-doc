import { BaseSyntheticEvent, useState } from "react"
import { useTranslation } from "react-i18next"

import Header from "@/modules/common/components/app/Header/Header.tsx"
import { Button } from "@/modules/common/components/ui/button.tsx"
import {
	Command,
	CommandEmpty,
	CommandGroup,
	CommandInput,
	CommandItem,
	CommandList,
} from "@/modules/common/components/ui/command.tsx"
import {
	Form,
	FormControl,
	FormField,
	FormItem,
	FormLabel,
	FormMessage,
} from "@/modules/common/components/ui/form.tsx"
import { Popover, PopoverContent, PopoverTrigger } from "@/modules/common/components/ui/popover.tsx"
import { RadioGroup, RadioGroupItem } from "@/modules/common/components/ui/radio-group.tsx"
import { Skeleton } from "@/modules/common/components/ui/skeleton.tsx"
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger,
} from "@/modules/common/components/ui/tooltip.tsx"
import { cn } from "@/modules/common/lib/utils/index.ts"
import { zodResolver } from "@hookform/resolvers/zod"
import { Check, ChevronsUpDown, Loader, Trash2 } from "lucide-react"
import { useForm, useWatch } from "react-hook-form"
import { HiSparkles } from "react-icons/hi2"
import { toast } from "sonner"
import { z } from "zod"
import FormInput from "../../../common/components/app/Inputs/FormInput.tsx"
import useContacts from "../../hooks/useContacts.ts"
import {
	createProvider,
	deleteProvider,
	inferPUCFromAI,
	putProvider,
} from "../../services/providers.ts"
import { DataTableProviders } from "../../components/DataTables/DataTableProviders.tsx"

const FormSchema = z
	.object({
		id: z.string().optional(),
		type: z.enum(["company", "individual"]),
		documentType: z.enum(["NIT", "CC"]),
		document: z.string().min(1),
		name: z.string().min(1),
		defaultPucCode: z.string().optional(),
		inferredPucCode: z.string().optional(),
		pucCodes: z.array(z.string()),
		contacts: z.array(
			z.object({
				id: z.number().optional(),
				firstName: z.string().optional(),
				lastName: z.string().optional(),
				email: z.string().email(),
			}),
		),
	})
	.refine((data) => !(data.type === "company" && data.documentType === "CC"), {
		path: ["documentType"],
	})

export default function Providers() {
	const { t } = useTranslation(["providers"])
	const [pucFilter, setPucFilter] = useState("")
	const [inferringPuc, setInferringPuc] = useState(false)
	const [selected, setSelected] = useState<boolean>(false)
	const [isSync, setIsSync] = useState(false)
	const [loading, setLoading] = useState(false)

	const form = useForm<z.infer<typeof FormSchema>>({
		resolver: zodResolver(FormSchema),
		defaultValues: {
			type: "company",
			documentType: "NIT",
			document: "",
			name: "",
			pucCodes: [],
			defaultPucCode: "",
			inferredPucCode: "",
			contacts: [
				{
					id: 1,
					firstName: "",
					lastName: "",
					email: "",
				},
			],
		},
	})

	const { addContact, removeContact } = useContacts(
		() => form.getValues("contacts"),
		(contacts) => form.setValue("contacts", contacts),
	)

	const pucCodes = useWatch({
		control: form.control,
		name: "pucCodes",
	})

	const transformPucArray = (pucArray: any[]) => {
		return pucArray.map(pucObj => {
		  const digits = Object.keys(pucObj)
			.filter(key => /^\d+$/.test(key))
			.sort((a, b) => Number(a) - Number(b))
	  
		  const code = digits.map(d => pucObj[d]).join("");
	  
		  return {
			code,
			_id: pucObj._id
		  };
		});
	  };
	  
	// Select provider to edit
	const selectProvider = async (provider: any) => {
		form.reset()

		setSelected(true)
		if (provider.inferredPUC && provider.inferredPUC.code) {
			form.setValue("inferredPucCode", provider.inferredPUC.code)
		} else {
			setInferringPuc(true)
			inferPUCFromAI(provider).then((puc) => {
				form.setValue("inferredPucCode", puc)
				setInferringPuc(false)
			})
		}

		form.setValue("id", provider._id)
		form.setValue("type", provider.personType === "Company" ? "company" : "individual")
		form.setValue("documentType", provider.idType === "13" ? "CC" : "NIT")
		form.setValue("document", provider.id)
		form.setValue("name", provider.name)
		const newContacts = provider.contacts.map((contact: any, index: number) => ({
			id: index + 1,
			firstName: contact.firstName,
			lastName: contact.lastName,
			email: contact.email,
		}))
		form.setValue("contacts", newContacts)
		form.setValue("defaultPucCode", provider.defaultPUC?.code)
		form.setValue(
			"pucCodes",
			transformPucArray(provider.PUC).map((puc) => puc.code)
		  );
	}

	async function onSubmit(data: z.infer<typeof FormSchema>, event?: BaseSyntheticEvent) {
		const triggerButton = (event?.nativeEvent as SubmitEvent).submitter as HTMLButtonElement

		if (triggerButton.value === "create") {
			setLoading(true)
			try {
				await createProvider({
					personType: data.type === "company" ? "Company" : "Person",
					idType: data.documentType === "CC" ? "13" : "31",
					id: data.document,
					inferredPUC: { code: data.inferredPucCode },
					type: "supplier",
					name: data.name,
					contacts: data.contacts,
					defaultPUC: { code: data.defaultPucCode },
					PUC: data.pucCodes.map((code) => ({ code })),
				})
				form.reset()
				toast(t("messages.proveedorCreado"))
			} catch (error) {
				toast.error(t("messages.proveedorError"))
			} finally {
				setLoading(false)
			}
		} else if (triggerButton.value === "update") {
			try {
				await putProvider({
					personType: data.type === "company" ? "Company" : "Person",
					idType: data.documentType === "CC" ? "13" : "31",
					id: data.document,
					name: data.name,
					inferredPUC: { code: data.inferredPucCode },
					type: "supplier",
					contacts: data.contacts,
					defaultPUC: { code: data.defaultPucCode },
					PUC: data.pucCodes.map((code) => ({ code })),
					_id: data.id,
				})

				form.reset()
				toast(t("messages.proveedorEditado"))
			} catch (error) {
				toast.error(t("messages.proveedorError"))
			}
		}
		setIsSync(false)
	}

	async function removeProvider(id?: string) {
		if (!id) return
		try {
			await deleteProvider({ _id: id })
			setIsSync(false)
			form.reset()
			toast(t("messages.proveedorEliminado"))
		} catch (error) {
			toast.error(error as string)
		}
	}

	return (
		<>
			<Header title={t("title")} sections={[{ title: t("management"), href: "/management" }]} />
			<main className="flex min-h-[calc(80vh)] w-full gap-8 px-12">
				<section className="min-h-[calc(80vh)] w-96 pt-6">
					<Form {...form}>
						<form
							onSubmit={form.handleSubmit(onSubmit)}
							onReset={() => {
								form.reset()
								setSelected(false)
							}}
							className="flex h-full w-full flex-col justify-between"
						>
							<main className="space-y-6">
								<h2>{t("labels.informacionProveedor")}</h2>
								<div className="flex flex-col gap-2">
									<FormField
										control={form.control}
										name="type"
										render={({ field }) => (
											<FormItem className="mb-4 space-y-3">
												<FormControl>
													<RadioGroup
														onValueChange={field.onChange}
														defaultValue={field.value}
														value={field.value}
														className="flex gap-6"
													>
														<FormItem className="flex items-center space-x-3 space-y-0">
															<FormControl>
																<RadioGroupItem value="company" />
															</FormControl>
															<FormLabel className="font-normal">
																{t("options.tipoPersona.Empresa")}
															</FormLabel>
														</FormItem>
														<FormItem className="flex items-center space-x-3 space-y-0">
															<FormControl>
																<RadioGroupItem value="individual" />
															</FormControl>
															<FormLabel className="font-normal">
																{t("options.tipoPersona.Persona")}
															</FormLabel>
														</FormItem>
													</RadioGroup>
												</FormControl>
												<FormMessage />
											</FormItem>
										)}
									/>
									<FormField
										control={form.control}
										name="documentType"
										render={({ field }) => (
											<FormItem className="mb-2 space-y-3">
												<FormLabel className="text-black">{t("labels.tipoDoc")}</FormLabel>
												<FormControl>
													<RadioGroup
														onValueChange={field.onChange}
														defaultValue={field.value}
														value={field.value}
														className="flex gap-6"
													>
														<FormItem className="flex items-center space-x-3 space-y-0">
															<FormControl>
																<RadioGroupItem value="NIT" />
															</FormControl>
															<FormLabel className="font-normal">NIT</FormLabel>
														</FormItem>
														<FormItem className="flex items-center space-x-3 space-y-0">
															<FormControl>
																<RadioGroupItem value="CC" />
															</FormControl>
															<FormLabel className="font-normal">CC</FormLabel>
														</FormItem>
													</RadioGroup>
												</FormControl>
												<FormMessage>{t("messages.tipoDocInvalid")}</FormMessage>
											</FormItem>
										)}
									/>
									<FormField
										control={form.control}
										name="document"
										render={({ field }) => (
											<FormInput
												data-testid={"document"}
												label={t("labels.documento")}
												error={t("messages.numDocRequired")}
												type="number"
												{...field}
											/>
										)}
									/>
									<FormField
										control={form.control}
										name="name"
										render={({ field }) => (
											<FormInput
												label={t("labels.nombre")}
												error={t("messages.nombreRequired")}
												{...field}
											/>
										)}
									/>
									<h3>{t("labels.codesPUC")}</h3>
									<FormField
										control={form.control}
										name="defaultPucCode"
										render={({ field }) => (
											<PucCombobox
												form={form}
												field={field}
												pucFilter={pucFilter}
												setPucFilter={setPucFilter}
												pucCodes={pucCodes}
												inferringPUC={inferringPuc}
											/>
										)}
									/>
									<h3>{t("labels.datosContacto")}</h3>
									{form.getValues("contacts").map((contact, index) => (
										<div key={contact.id} className="space-y-3">
											<FormField
												control={form.control}
												name={`contacts.${index}.firstName`}
												render={({ field }) => (
													<FormInput
														label={t("labels.nombre")}
														{...field}
														value={contact.firstName}
													/>
												)}
											/>
											<FormField
												control={form.control}
												name={`contacts.${index}.lastName`}
												render={({ field }) => (
													<FormInput
														label={t("labels.apellidos")}
														{...field}
														value={contact.lastName}
													/>
												)}
											/>
											<FormField
												control={form.control}
												name={`contacts.${index}.email`}
												render={({ field }) => (
													<FormInput
														label={t("labels.email")}
														type="email"
														error={t("messages.emailInvalid")}
														{...field}
														value={contact.email}
													/>
												)}
											/>
											<div className="flex justify-end gap-4">
												{index === 0 && (
													<Button
														type="button"
														variant="primary"
														onClick={() =>
															addContact({
																firstName: "",
																lastName: "",
																email: "",
															})
														}
														id="addContact"
													>
														{t("buttons.añadirContacto")}
													</Button>
												)}
												{form.getValues("contacts").length > 1 && (
													<Button
														type="button"
														variant="negative"
														onClick={() => removeContact(contact.id || 0)}
													>
														{t("buttons.borrarContacto")}
													</Button>
												)}
											</div>
										</div>
									))}
								</div>
							</main>
							<footer className="my-6 flex flex-col gap-3">
								<h3>{t("labels.actions")}</h3>
								<div className="flex items-center gap-4">
									<Button type="submit" variant="primary" value="create" className="h-10 w-full">
										<div className="flex h-full items-center justify-center">
											{loading ? (
												<Loader className="h-5 w-5 animate-pulse text-white" />
											) : (
												<span>{t("buttons.crear")}</span>
											)}
										</div>
									</Button>
									<Button type="submit" variant="quiet" value="update">
										{t("buttons.guardar")}
									</Button>
									<Button type="reset" variant="quiet" value="clear">
										{t("buttons.limpiar")}
									</Button>
									<Button
										type="button"
										variant="icon"
										size="icon"
										value="delete"
										onClick={() => removeProvider(form.getValues("id"))}
									>
										<Trash2 className="stroke-semantic-red-1200" />
									</Button>
								</div>
							</footer>
						</form>
					</Form>
				</section>
				<section className="w-full">
					<DataTableProviders
						onSelect={selectProvider}
						selected={selected}
						isSync={isSync}
						setIsSync={setIsSync}
					/>
				</section>
			</main>
		</>
	)
}

interface PucComboboxProps {
	form: ReturnType<typeof useForm<z.infer<typeof FormSchema>>>
	field: {
		value: string | undefined
		onChange: (value: string) => void
	}
	pucFilter: string
	setPucFilter: (value: string) => void
	pucCodes: string[]
	inferringPUC?: boolean
}

function PucCombobox({
	form,
	field,
	pucFilter,
	setPucFilter,
	pucCodes,
	inferringPUC,
}: PucComboboxProps) {
	return (
		<FormItem className="flex flex-col">
			<Popover>
				<PopoverTrigger asChild>
					<FormControl>
						<Button
							variant="outline"
							role="combobox"
							className={cn("mb-4 w-full justify-between", !field.value && "text-muted-foreground")}
						>
							{field.value ? `Default PUC ${field.value}` : "Manage PUC codes"}
							<ChevronsUpDown className="opacity-50" />
						</Button>
					</FormControl>
				</PopoverTrigger>
				<PopoverContent className="p-0">
					<Command>
						<CommandInput
							value={pucFilter}
							onChangeCapture={(e) => setPucFilter((e.target as HTMLInputElement).value)}
							placeholder="Search PUC Code"
							className="h-9"
						/>
						<CommandList>
							{pucFilter === "" && <CommandEmpty>No PUC codes created</CommandEmpty>}
							<CommandGroup>
								{(inferringPUC || form.getValues("inferredPucCode")) && (
									<CommandItem
										value={form.getValues("inferredPucCode")}
										className="group/puc cursor-pointer"
										disabled={inferringPUC}
										onSelect={() => {
											if (field.value !== form.getValues("inferredPucCode")) {
												form.setValue("defaultPucCode", form.getValues("inferredPucCode"))
											} else {
												form.setValue("defaultPucCode", "")
											}
										}}
									>
										{inferringPUC ? (
											<Skeleton className="h-4 w-20" />
										) : (
											form.getValues("inferredPucCode")
										)}

										<div className="ml-auto flex items-center gap-2">
											<Button
												variant="ghost"
												size="none"
												className="z-[100] hidden p-0.5 hover:bg-primary-grey-200 group-hover/puc:block [&_svg]:size-4"
												onClick={() => {
													form.setValue("inferredPucCode", "")
													setTimeout(() => {
														if (
															form.getValues("defaultPucCode") === form.getValues("inferredPucCode")
														) {
															form.setValue("defaultPucCode", "")
														}
													})
												}}
											>
												<Trash2 className="stroke-semantic-red-1200" />
											</Button>
											<TooltipProvider>
												<Tooltip>
													<TooltipTrigger>
														<HiSparkles className="text-tertiary-mint-1200" />
													</TooltipTrigger>
													<TooltipContent>
														<div className="rounded-md bg-primary-grey-50 p-2 text-primary-grey-1000">
															Inferred by AI
														</div>
													</TooltipContent>
												</Tooltip>
											</TooltipProvider>
											{form.getValues("inferredPucCode") !== "" &&
												form.getValues("inferredPucCode") === field.value && (
													<TooltipProvider>
														<Tooltip>
															<TooltipTrigger>
																<Check />
															</TooltipTrigger>
															<TooltipContent>
																<div className="rounded-md bg-primary-grey-50 p-2 text-primary-grey-1000">
																	Default PUC
																</div>
															</TooltipContent>
														</Tooltip>
													</TooltipProvider>
												)}
										</div>
									</CommandItem>
								)}
								{pucCodes.map((puc) => (
									<CommandItem
										value={puc}
										key={puc}
										className="group/puc cursor-pointer"
										onSelect={() => {
											if (field.value !== puc) {
												form.setValue("defaultPucCode", puc)
											} else {
												form.setValue("defaultPucCode", "")
											}
										}}
									>
										{puc}
										<div className="ml-auto flex items-center gap-2">
											<Button
												variant="ghost"
												size="none"
												className="z-[100] hidden p-0.5 hover:bg-primary-grey-200 group-hover/puc:block [&_svg]:size-4"
												onClick={() => {
													form.setValue(
														"pucCodes",
														pucCodes.filter((code) => code !== puc),
													)
													setTimeout(() => {
														if (form.getValues("defaultPucCode") === puc) {
															form.setValue("defaultPucCode", "")
														}
													})
												}}
											>
												<Trash2 className="stroke-semantic-red-1200" />
											</Button>
											{puc === field.value && (
												<TooltipProvider>
													<Tooltip>
														<TooltipTrigger>
															<Check />
														</TooltipTrigger>
														<TooltipContent>
															<div className="rounded-md bg-primary-grey-50 p-2 text-primary-grey-1000">
																Default PUC
															</div>
														</TooltipContent>
													</Tooltip>
												</TooltipProvider>
											)}
										</div>
									</CommandItem>
								))}
							</CommandGroup>
						</CommandList>
					</Command>
					{pucFilter !== "" && !pucCodes.find((code) => code === pucFilter) && (
						<Button
							variant="ghost"
							className="m-1 w-[calc(100%-8px)] px-2 py-1.5 normal-case"
							size="none"
							onClick={() => {
								form.setValue("pucCodes", [...pucCodes, pucFilter])
								setPucFilter("")
							}}
						>
							Add code '{pucFilter}'
						</Button>
					)}
				</PopoverContent>
			</Popover>
			<FormMessage />
		</FormItem>
	)
}
