// src/components/inventory/Inventory.jsx
import { BaseSyntheticEvent, useEffect, useState } from "react"
import { useTranslation } from "react-i18next"

import { TbTriangleInvertedFilled } from "react-icons/tb"

import {
	createProduct,
	deleteProduct,
	getAllCategories,
	putProduct,
} from "@/modules/management/services/products.ts"
import { useLocation, useNavigate } from "react-router-dom"
import Header from "@/modules/common/components/app/Header/Header.tsx"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import {
	Form,
	FormControl,
	FormField,
	FormItem,
	FormLabel,
	FormMessage,
} from "@/modules/common/components/ui/form"
import { RadioGroup, RadioGroupItem } from "@/modules/common/components/ui/radio-group"
import FormInput from "@/modules/common/components/app/Inputs/FormInput"
import { Button } from "@/modules/common/components/ui/button"
import { Loader, Minus, Plus, Trash2 } from "lucide-react"
import FormSelect from "@/modules/common/components/app/Inputs/FormSelect"
import { Checkbox } from "@/modules/common/components/ui/checkbox"
import useCurrencies from "../../hooks/useCurrencies"
import { cn } from "@/modules/common/lib/utils"
import { toast } from "sonner"
import { DataTableInventory } from "../../components/DataTables/DataTableInventory"
import { SelectItem } from "@radix-ui/react-select"

const FormSchema = z.object({
	id: z.string().optional(),
	code: z.string().min(1),
	inventoryType: z.number().optional(),
	type: z.enum(["Product", "Service", "ConsumerGood"]),
	category: z.string().min(1),
	name: z.string().min(1),
	quantity: z.string().min(1),
	reference: z.string().min(1),
	active: z.boolean(),
	stockControl: z.boolean(),
	unit: z.object({
		code: z.string().min(1),
		name: z.string().min(1),
		label: z.string().min(1),
	}),
	taxIncluded: z.boolean(),
	taxType: z.enum(["Taxed", "Exempt", "Excluded"]),
	taxConsumptionValue: z.string().min(1),
	prices: z.array(
		z.object({
			id: z.number().optional(),
			currencyCode: z.string().min(1),
			collapsed: z.boolean().default(true),
			priceList: z.array(
				z.object({
					id: z.number().optional(),
					name: z.string().min(1),
					value: z.string().min(1),
				}),
			),
		}),
	),
})

const defaultProduct = {
	_id: "",
	code: "",
	name: "",
	prices: [],
	active: true,
	type: "",
	reference: "",
	available_quantity: 0,
	inventory_type: "",
	category: {
		code: "",
		name: "",
	},
	unit: {
		code: "",
		name: "",
	},
	unit_label: "",
	stock_control: false,
	ware_houses: [],
	tax_included: false,
	tax_classification: "",
	tax_consumption_value: 0,
}

export default function Inventory() {
	const { t } = useTranslation(["inventory"])
	const location = useLocation()
	const navigate = useNavigate()
	const [categories, setCategories] = useState<any[]>([])

	const [selected, setSelected] = useState<any>(defaultProduct)
	const [isSync, setIsSync] = useState(false)
	const [isLoading, setIsLoading] = useState(false)
	const [currencyCodes] = useState<string[]>([
		"COP",
		"EUR",
		"USD",
		"ANG",
		"ARS",
		"AUD",
		"BOB",
		"BRL",
		"CAD",
		"CHF",
		"CLP",
		"CRC",
		"GBP",
		"GTQ",
		"HNL",
		"JPY",
		"MXN",
		"NZD",
		"PAB",
		"PEN",
		"SGD",
		"UYU",
	])

	const form = useForm<z.infer<typeof FormSchema>>({
		resolver: zodResolver(FormSchema),
		defaultValues: {
			name: "",
			reference: "",
			active: false,
			stockControl: false,
			category: "",
			unit: {
				code: "",
				name: "",
				label: "",
			},
			taxIncluded: false,
			prices: [],
		},
	})

	const { addCurrency, removeCurrency, addPrice, removePrice, toggleCollapse } = useCurrencies(
		() => form.getValues("prices"),
		(currencies) => form.setValue("prices", currencies),
	)

	const getCategories = async () => {
		const res = await getAllCategories()
		let fetchedCategories
		if (res) {
			fetchedCategories = res
		} else {
			fetchedCategories = []
		}
		setCategories(fetchedCategories)
	}

	useEffect(() => {
		getCategories()
	}, [])

	useEffect(() => {
		if (location.state?.item) {
			setSelected({ ...defaultProduct, name: location.state.item?.name })
			navigate(location.pathname, { replace: true })
		}
	}, [location.state, navigate, location.pathname])

	const selectProduct = async (product: any) => {
		console.log(product)
		form.reset()

		setSelected(true)

		let type: "Product" | "Service" | "ConsumerGood" = "Product"
		if (product.type === "Producto") {
			type = "Product"
		} else if (product.type === "Servicio") {
			type = "Service"
		} else if (product.type === "Consumo") {
			type = "ConsumerGood"
		}

		let tax_classification: "Taxed" | "Exempt" | "Excluded" = "Taxed"
		if (product.tax_classification === "Gravado") {
			tax_classification = "Taxed"
		} else if (product.tax_classification === "Exento") {
			tax_classification = "Exempt"
		} else if (product.tax_classification === "Excluido") {
			tax_classification = "Excluded"
		}

		form.setValue("id", product._id)
		form.setValue("type", type)
		form.setValue("code", product.code)
		form.setValue("category", categories.find((category) => category.id === product.inventory_type)?.name)
		form.setValue("inventoryType", product.inventory_type ?? "");
		form.setValue("name", product.name)
		form.setValue("quantity", product.available_quantity.toString())
		form.setValue("reference", product.reference)
		form.setValue("active", product.active)
		form.setValue("stockControl", product.stock_control)
		form.setValue("unit.code", product.unit.code)
		form.setValue("unit.name", product.unit.name)
		form.setValue("unit.label", product.unit_label)
		form.setValue("taxIncluded", product.tax_included)
		form.setValue("taxType", tax_classification)
		form.setValue("taxConsumptionValue", product.tax_consumption_value.toString())
		form.setValue(
			"prices",
			(product.prices ?? []).map((price: any) => ({
				currencyCode: price.currency_code ?? "",
				priceList: (price.price_list ?? []).map((subPrice: any) => ({
					id: subPrice.position ?? 0,
					name: subPrice.name ?? "",
					value: subPrice.value?.toString() ?? "0",
				})),
			}))
		);
	}

	async function onSubmit(data: z.infer<typeof FormSchema>, event?: BaseSyntheticEvent) {
		const triggerButton = (event?.nativeEvent as SubmitEvent).submitter as HTMLButtonElement
		setIsLoading(true)
		if (triggerButton.value === "create") {
			try {
				await createProduct({
					code: data.code,
					type: data.type,
					category: data.category,
					inventory_type: data?.inventoryType?.toString() || "",
					name: data.name,
					description:data.name,
					available_quantity: data.quantity,
					reference: data.reference,
					active: data.active,
					stock_control: data.stockControl,
					unit_label: data.unit.label,
					unit: {
						code: data.unit.code,
						name: data.unit.name,
					},
					tax_included: data.taxIncluded,
					tax_classification: data.taxType,
					taxConsumptionValue: data.taxConsumptionValue,
					prices: data.prices.map((price) => ({
						currency_code: price.currencyCode,
						price_list: price.priceList.map((subPrice, index) => ({
							id: subPrice.id,
							name: subPrice.name,
							value: Number(subPrice.value),
							position: index + 1,
						})),				
					})),
				})
	
				
				form.reset()
				form.resetField("category")
				toast(t("messages.productoCreado"))
			} catch (error) {
				if((error as any)?.response?.data?.error?.[0]?.Code === "already_exists") {
					toast.error(t("Product already exists"))
				}else{
					toast.error(t("messages.errorCreandoProducto"))
				}
			}
		} else if (triggerButton.value === "update") {
			await putProduct({
				_id: data.id?.toString(),
				code: data.code,
				type: data.type,
				category: data.category,
				inventory_type: data.inventoryType,
				name: data.name,
				available_quantity: data.quantity,
				reference: data.reference,
				active: data.active,
				stock_control: data.stockControl,
				unit_label: data.unit.label,
				unit: {
					code: data.unit.code,
					name: data.unit.name,
				},
				tax_included: data.taxIncluded,
				tax_classification: data.taxType,
				taxConsumptionValue: data.taxConsumptionValue,
				prices: data.prices.map((price) => ({
					currency_code: price.currencyCode,
					price_list: price.priceList.map((subPrice, index) => ({
						...subPrice,
						position: index + 1,
					})),
					...price,
				})),
			})

			form.reset()
			toast(t("messages.proveedorEditado"))
		}
		setIsLoading(false)
		setSelected(false)
		setIsSync(false)
	}

	async function removeProduct(id?: string) {
		await deleteProduct({ _id: id })
		toast(t("messages.productoEliminado"))
		setSelected(false)
		setIsSync(false)
	}

	const options = [
		{ value: "Product", label: t("labels.producto") },
		{ value: "Service", label: t("labels.servicio") },
		{ value: "ConsumerGood", label: t("labels.consumo") },
	];
	  
	return (
		<>
			<Header title={t("title")} sections={[{ title: t("management"), href: "/management" }]} />
			<main className="px-12 w-full flex gap-8 min-h-[calc(80vh)]">
				<section className="w-80 pt-6 min-h-[calc(80vh)]">
					<Form {...form}>
						<form
							onSubmit={form.handleSubmit(onSubmit)}
							onReset={() => {
								form.reset()
								setSelected(false)
							}}
							className="w-full h-full flex flex-col justify-between"
						>
							<main className="space-y-6">
								<h2>{t("labels.informacionProducto")}</h2>
								<div className="flex flex-col gap-2">
									<FormField
										control={form.control}
										name="code"
										render={({ field }) => (
											<FormInput
												type="number"
												label={t("labels.codigo")}
												error={t("messages.codigoRequired")}
												{...field}
												value={field.value} 
												onChange={field.onChange}
												onBlur={field.onBlur}
												name={field.name}
												ref={field.ref}
											/>
										)}
									/>
									

									<FormField
									control={form.control}
									name="type"
									render={({ field }) => (
										<FormItem className="space-y-3 mb-4">
										<FormControl>
											<RadioGroup
											onValueChange={field.onChange}
											value={field.value}
											className="flex gap-6 flex-wrap"
											>
											{options.map(({ value, label }) => (
												<FormItem key={value} className="flex items-center space-x-3 space-y-0">
												<FormControl>
													<RadioGroupItem value={value} />
												</FormControl>
												<FormLabel className="font-normal">{label}</FormLabel>
												</FormItem>
											))}
											</RadioGroup>
										</FormControl>
										<FormMessage />
										</FormItem>
									)}
									/>
									<FormField
									control={form.control}
									name="category"
									render={({ field }) => (
										<FormSelect
										options={categories.map((category) => category.name)}
										label={t("labels.categoria")}
										onValueChange={(e) => {
											field.onChange(e)
											categories.forEach((category) => {
											if (category.name === e) {
												form.setValue("inventoryType", category.id)
											}
											})
										}}
										value={field.value}
										/>
									)}
									/>

									<div className="flex gap-4 [&>*]:w-full">
										<FormField
											control={form.control}
											name="name"
											render={({ field }) => (
												<FormInput
													label={t("labels.nombre")}
													error={t("messages.nombreRequired")}
													{...field}
												/>
											)}
										/>
										<FormField
											control={form.control}
											name="quantity"
											render={({ field }) => (
												<FormInput
													label={t("labels.cantidad")}
													// error={t("messages.cantidadRequired")}
													{...field}
												/>
											)}
										/>
									</div>
									<FormField
										control={form.control}
										name="reference"
										render={({ field }) => (
											<FormInput
												label={t("labels.referencia")}
												error={t("messages.referenciaRequired")}
												{...field}
											/>
										)}
									/>
									<div className="flex gap-4 mb-2">
										<FormField
											control={form.control}
											name="active"
											render={({ field }) => {
												return (
													<FormItem className="flex flex-row items-center space-x-3 space-y-0">
														<FormControl>
															<Checkbox
																className="text-primary-green-1200 bg-white shadow-none"
																checked={field.value}
																onCheckedChange={field.onChange}
															/>
														</FormControl>
														<FormLabel className="text-sm font-normal">
															{t("labels.activo")}
														</FormLabel>
													</FormItem>
												)
											}}
										/>
										<FormField
											control={form.control}
											name="stockControl"
											render={({ field }) => {
												return (
													<FormItem className="flex flex-row items-center space-x-3 space-y-0">
														<FormControl>
															<Checkbox
																className="text-primary-green-1200 bg-white shadow-none"
																checked={field.value}
																onCheckedChange={field.onChange}
															/>
														</FormControl>
														<FormLabel className="text-sm font-normal">
															{t("labels.controlStock")}
														</FormLabel>
													</FormItem>
												)
											}}
										/>
									</div>
									<h3>{t("labels.unidad")}</h3>
									<FormField
										control={form.control}
										name="unit.code"
										render={({ field }) => (
											<FormInput
												label={t("labels.codigoUnidad")}
												error={t("messages.codigoUnidadRequired")}
												{...field}
											/>
										)}
									/>
									<div className="flex gap-4 [&>*]:w-full">
										<FormField
											control={form.control}
											name="unit.name"
											render={({ field }) => (
												<FormInput
													label={t("labels.nombreUnidad")}
													error={t("messages.codigoNombreRequired")}
													{...field}
												/>
											)}
										/>
										<FormField
											control={form.control}
											name="unit.label"
											render={({ field }) => (
												<FormInput
													label={t("labels.etiquetaUnidad")}
													error={t("messages.codigoEtiquetaRequired")}
													{...field}
												/>
											)}
										/>
									</div>
									<h3>{t("labels.impuestos")}</h3>
									<FormField
										control={form.control}
										name="taxIncluded"
										render={({ field }) => {
											return (
												<FormItem className="flex flex-row items-center space-x-3 space-y-0 mb-2">
													<FormControl>
														<Checkbox
															className="text-primary-green-1200 bg-white shadow-none"
															checked={field.value}
															onCheckedChange={field.onChange}
														/>
													</FormControl>
													<FormLabel className="text-sm font-normal">
														{t("labels.impuestoIncluido")}
													</FormLabel>
												</FormItem>
											)
										}}
									/>
									<div className="mt-2">
										<FormField
											control={form.control}
											name="taxType"
											render={({ field }) => {
												const options = [
													{ label: "Gravado", value: "Taxed" },
													{ label: "Exento", value: "Exempt" },
													{ label: "Excluido", value: "Excluded" },
												];

												return (
													<FormSelect
														options={options.map(option => option.value)}
														label={t("labels.tipoImpuesto")}
														onValueChange={(selectedValue) => {
															const selectedOption = options.find(option => option.value === selectedValue);
															if (selectedOption) {
																field.onChange(selectedOption.value);
															}
														}}
														value={field.value}
													>
														{options.map((option) => (
															<SelectItem key={option.value} value={option.value}>
																{option.label}
															</SelectItem>
														))}
													</FormSelect>
												);
											}}
										/>
									</div>

									<FormField
										control={form.control}
										name="taxConsumptionValue"
										render={({ field }) => (
											<FormInput
												type="number"
												label={t("labels.valorImpuestoConsumo")}
												error={t("messages.taxConsumptionValueRequired")}
												{...field}
											/>
										)}
									/>
									<h3 className="mb-2">{t("labels.precios")}</h3>
									{form.getValues("prices").map((price, index) => (
										<div key={price.id} className="space-y-2">
											<div className="flex gap-1 items-center [&>div]:w-1/2">
												<FormField
													control={form.control}
													name={`prices.${index}.currencyCode`}
													render={({ field }) => (
														<FormSelect
															className="w-full"
															label={t("labels.moneda")}
															options={currencyCodes}
															onValueChange={field.onChange}
															value={field.value}
														/>
													)}
												/>
												<Button
													type="button"
													variant="icon"
													className={cn("size-3 [&_svg]:size-3", {
														"-rotate-90": price.collapsed,
													})}
													onClick={() => toggleCollapse(price.id ?? 0)}
												>
													<TbTriangleInvertedFilled />
												</Button>
												<Button
													type="button"
													variant="icon"
													className="w-8 h-8 text-semantic-red-1200"
													onClick={() => removeCurrency(price.id ?? 0)}
												>
													<Trash2 />
												</Button>
											</div>
											{!price.collapsed && (
												<>
													{form.getValues(`prices.${index}.priceList`).map((subPrice, subIndex) => (
														<div className="flex gap-4 items-center">
															<FormField
																control={form.control}
																name={`prices.${index}.priceList.${subIndex}.name`}
																render={({ field }) => (
																	<FormInput
																		label={t("labels.nombre")}
																		{...field}
																		value={subPrice.name}
																	/>
																)}
															/>
															<FormField
																control={form.control}
																name={`prices.${index}.priceList.${subIndex}.value`}
																render={({ field }) => (
																	<FormInput
																		className=""
																		label={t("labels.valor")}
																		{...field}
																		type="number"
																		value={subPrice.value}
																	/>
																)}
															/>
															<Button
																type="button"
																variant="icon"
																className="size-4 [&_svg]:size-4 text-semantic-red-1200 m-0 p-0"
																onClick={() => removePrice(price.id ?? 0, subPrice.id ?? 0)}
															>
																<Minus />
															</Button>
														</div>
													))}
													<Button
														type="button"
														variant="icon"
														className="size-4 [&_svg]:size-4 text-primary-green-1200 m-0 p-0"
														onClick={() => addPrice(price.id ?? 0, { name: "", value: "" })}
													>
														<Plus />
													</Button>
												</>
											)}
										</div>
									))}
									<Button
										type="button"
										className="w-fit ml-auto"
										variant="primary"
										onClick={() =>
											addCurrency({
												currencyCode: "",
												priceList: [],
												collapsed: true,
											})
										}
									>
										{t("buttons.añadirMoneda")}
									</Button>
								</div>
							</main>
							<footer className="flex flex-col gap-3 my-6">
								<h3>{t("labels.actions")}</h3>
								<div className="flex gap-4 items-center">
									<Button type="submit" variant="primary" value="create">
									{isLoading ? (
											<Loader className="animate-pulse h-5 w-5 text-white" />
										) : (
											<span>{t("buttons.crear")}</span>
										)}
									</Button>
									<Button type="submit" variant="quiet" value="update" onClick={() => {}}>
										{t("buttons.guardar")}
									</Button>
									<Button type="reset" variant="quiet" value="clear">
										{t("buttons.limpiar")}
									</Button>
									<Button
										type="button"
										variant="icon"
										size="icon"
										value="delete"
										onClick={() => removeProduct(form.getValues("id"))}
									>
										<Trash2 className="stroke-semantic-red-1200" />
									</Button>
								</div>
							</footer>
						</form>
					</Form>
				</section>
				<DataTableInventory
					selected={selected}
					onSelect={selectProduct}
					isSync={isSync}
					setIsSync={setIsSync}
				/>
			</main>
		</>
	)
}