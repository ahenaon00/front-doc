import { useEffect, useState } from "react"
import Header from "@/modules/common/components/app/Header/Header"
import { Card } from "@/modules/common/components/ui/card"
import { Button } from "@/modules/common/components/ui/button.tsx"
import {
	getAllTaxesCurrentMonth,
	getAllCountTaxes,
} from "@/modules/causation/services/invoice"

// Importa tus dos componentes

function Taxes() {
	const [, setTaxSummary] = useState({
		ivaTaxes: 0,
		reteICA: 0,
		rentTaxes: 0,
		otherTaxes: 0,
	})
	const [, setCount] = useState({
		IVA: 0,
		ICA: 0,
		rent: 0,
		other: 0,
	})
	const buttonLabels = ['IVA', 'ICA', 'RENTA', 'IPOCONSUMO', 'IBUA', 'ICUI'];
	const [selectedLabel, setSelectedLabel] = useState('IVA');
	const fetchTaxSummary = async () => {
		const response = await getAllTaxesCurrentMonth()
		const response2 = await getAllCountTaxes()
		setTaxSummary(response)
		setCount(response2)
	}

	useEffect(() => {
		fetchTaxSummary()
	}, [])

	return (
		<>
			<Header title = {"Taxes"} sections = {[{title : "Management", href : "/management" }]} ></Header>
			<main className="p-4">
				<section className="mt-4 mx-2">
						<h2 className="text-xl mb-2">Detalle de impuestos</h2>
						<p className ="text-base">Consulta la información detallada de los impuestos que debes pagar y sus fechas límite.</p>
					<div className="flex border-b border-primary-grey-200 my-9">
						{buttonLabels.map((label) => (
							<div className="flex-1">
								<Button className={`w-full ${selectedLabel === label ? "text-gray-950" : "text-gray-600"}  shadow-none text-xl`} onClick={() => setSelectedLabel(label)}>{label}</Button>
								{selectedLabel === label &&
									(<div className="h-1 w-full bg-primary-green-1100 text-ga mt-1 rounded" />)
								}
							</div>
						))
						}
					</div>
					<div className="flex gap-12">
						<Card className="p-6 border border-primary-grey-300 flex items-center w-full rounded-[14px]">
							<Card className="bg-primary-green-50 px-8 py-5 items-center flex flex-1 flex-col h-full rounded-lg">
								<div className="flex flex-row justify-between items-center w-full mb-12">
									<p className="text-lg">Impuesto al valor agregado {selectedLabel}</p>
									<Card className="bg-primary-green-200 p-1 rounded-2xl px-4">
										<p className="text-gray-800"><span className="text-black">Estado:</span> Pagado</p>
									</Card>
								</div>
								<div className="w-[80%] flex flex-row justify-between border-b border-primary-grey-1000 px-8 pb-5 mb-4 pr-12">
									<div className="flex flex-col items-center">	
										<h1 className="font-bold text-3xl mb-2">Total Facturas:</h1>
										<p className="text-3xl text-primary-gray-1800">25.000</p>
									</div>
									<div className="flex flex-col items-center gap-1">
										<h1 className="font-bold text-3xl mb-2">Total Pagado:</h1>
										<p className="text-3xl text-primary-gray-800">279’000.000</p>
									</div>
								</div>
							<div className="flex w-[80%] text-base justify-between px-4">
								<p><span className="font-semibold">Último pago realizado:</span> 28/01/2025</p>
								<p><span className="font-semibold">Fecha límite de pago:</span> 15/05/2025</p>
							</div>	
							</Card>
						</Card>
						<Card className="p-6 border border-primary-grey-300 w-[35%] mr-6 flex rounded-[14px]">
							<Card className="bg-primary-green-50 items-center flex flex-1 flex-col justify-between p-8 gap-6 rounded-lg">
								<h1 className="text-center text-lg font-bold ">Consulta oficial de impuestos</h1>
								<h1 className="text-center text-lg">Verifica tu estado de cuenta y presenta tu declaración de {selectedLabel} en la entidad correspondiente.</h1>
								<Button variant="primary">Más detalles</Button>
							</Card>
						</Card>
					</div>
				</section>

			</main>
		</>
	)
}

export default Taxes
