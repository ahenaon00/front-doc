import { useEffect, useState } from "react"
import { useTranslation } from "react-i18next"
import { useNavigate } from "react-router-dom"
import { Card, CardDescription, CardHeader, CardTitle } from "@/modules/common/components/ui/card"
import { Button } from "@/modules/common/components/ui/button"
import { ArrowUpRight } from "lucide-react"
import { getProductsByMonth } from "@/modules/management/services/products"
import { getActiveProvidersThisMonth } from "@/modules/management/services/providers"
import Header from "@/modules/common/components/app/Header/Header"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import { toast } from "sonner"

export default function Management() {
	const { t } = useTranslation(["management"])
	const navigate = useNavigate()

	// Estados para manejar datos
	const [products, setProducts] = useState<any>([])
	const [providers, setProviders] = useState<any>([])

	// Estados para totales
	const [totalProducts, setTotalProducts] = useState(0)
	const [totalProviders, setTotalProviders] = useState(0)
	const [totalTaxes] = useState(0)

	// Estado de carga
	const [loading, setLoading] = useState(true)

	useEffect(() => {
		const fetchRecentActivity = async () => {
			try {
				// Obtener proveedores
				const fetchedProviders = await getActiveProvidersThisMonth()
				setProviders(fetchedProviders)
				setTotalProviders(fetchedProviders.total)

				// Obtener productos
				const fetchedProducts = await getProductsByMonth()
				setProducts(fetchedProducts)
				setTotalProducts(fetchedProducts.total)

				// Obtener impuestos
				/* const fetchedTaxes = await getTaxesByMonth()
				setTaxes(fetchedTaxes)

				// Calcular el total de impuestos
				const totalTaxAmount = fetchedTaxes.reduce((sum, tax) => sum + (tax.amount || 0), 0)
				setTotalTaxes(totalTaxAmount) */
			} catch (error) {
				console.error("Error fetching data:", error)
				toast.error((error as { message: string })?.message)
			} finally {
				setLoading(false)
			}
		}

		fetchRecentActivity()
	}, [t])

	return (
		<>
			<Header title={t("title")} />
			<main className="m-5 flex flex-col justify-between gap-5">
				<div className="flex flex-row justify-between gap-5 2xl:gap-14">
					{/* Carta 1: Proveedores */}
					<Card className="w-full flex flex-col bg-primary-green-1200">
						<CardHeader className="flex flex-row justify-between items-center">
							<CardTitle className="max-w-48">{t("cards.providers.title")}</CardTitle>
							<Button variant="arrowGrey" size="circle" onClick={() => navigate("/providers")}>
								<ArrowUpRight className="h-5 w-5" />
							</Button>
						</CardHeader>
						<div className="border-t border-primary-grey-1800 mx-5 my-10 2xl:my-2"></div>
						<CardDescription className="mx-5 mb-5 mt-2">
							{loading ? t("loading") : `${totalProviders} ${t("cards.providers.description")}`}
						</CardDescription>
					</Card>

					{/* Carta 2: Productos */}
					<Card className="w-full flex flex-col bg-primary-green-1200">
						<CardHeader className="flex flex-row justify-between items-center">
							<CardTitle className="max-w-44">{t("cards.inventory.title")}</CardTitle>
							<Button variant="arrowGrey" size="circle" onClick={() => navigate("/inventory")}>
								<ArrowUpRight className="h-5 w-5" />
							</Button>
						</CardHeader>
						<div className="border-t border-primary-grey-1800 mx-5 my-10 2xl:my-2"></div>
						<CardDescription className="mx-5 mb-5 mt-2">
							{loading ? t("loading") : `${totalProducts} ${t("cards.inventory.description")}`}
						</CardDescription>
					</Card>

					{/* Carta 3: Impuestos */}
					<Card className="w-full flex flex-col bg-primary-grey-1800">
						<CardHeader className="flex flex-row justify-between items-center">
							<CardTitle className="text-white">{t("cards.taxes.title")}</CardTitle>
							<Button variant="arrowWhite" size="circle" onClick={() => navigate("/taxes")}>
								<ArrowUpRight className="h-5 w-5" />
							</Button>
						</CardHeader>
						<div className="border-t border-primary-grey-400 mx-5 my-10 2xl:my-2"></div>
						<CardDescription className="mx-5 mb-5 mt-2 text-primary-grey-400">
							{loading
								? t("loading")
								: `${totalTaxes.toLocaleString("es-CO", {
										style: "currency",
										currency: "COP",
									})} ${t("cards.taxes.description")}`}
						</CardDescription>
					</Card>
				</div>

				{/* Tablas */}
				<div className="flex flex-col gap-5">
					{/* Tabla de Proveedores */}
					<section>
						<h2>{t("tables.providers.title")}</h2>
						<Table>
							<TableHeader>
								<TableRow>
									<TableHead>{t("tables.providers.title")}</TableHead>
									<TableHead>{t("tables.providers.nitOrId")}</TableHead>
									<TableHead>{t("tables.providers.pucCode")}</TableHead>
									<TableHead>{t("tables.providers.contact")}</TableHead>
								</TableRow>
							</TableHeader>
							<TableBody>
								{loading ? (
									<TableRow>
										<TableCell colSpan={4} className="h-24 text-center">
											{t("loading")}
										</TableCell>
									</TableRow>
								) : !providers?.providers?.length ? (
									<TableRow>
										<TableCell colSpan={4} className="h-24 text-center">
											{t("No results.")}
										</TableCell>
									</TableRow>
								) : (
									providers.providers.slice(0, 5).map((provider: any) => (
										<TableRow key={provider._id}>
											<TableCell className="font-medium">{provider.name}</TableCell>
											<TableCell>{provider.id}</TableCell>
											<TableCell>{provider.defaultPUC?.code || provider.PUC?.[0]?.code || provider.inferredPUC?.code || t("No hay PUC")}</TableCell>
											<TableCell>
												{provider.contacts?.[0]?.firstName +
													" " +
													provider.contacts?.[0]?.lastName || t("tables.noContact")}
											</TableCell>
										</TableRow>
									))
								)}
							</TableBody>
						</Table>
					</section>

					{/* Tabla de Productos */}
					<section>
						<h2>{t("tables.products.title")}</h2>

						<Table>
							<TableHeader>
								<TableRow>
									<TableHead>{t("tables.products.title")}</TableHead>
									<TableHead>{t("tables.products.provider")}</TableHead>
									<TableHead>{t("tables.products.units")}</TableHead>
									<TableHead className="text-right">{t("tables.products.price")}</TableHead>
								</TableRow>
							</TableHeader>
							<TableBody>
								{loading ? (
									<TableRow>
										<TableCell colSpan={4} className="h-24 text-center">
											{t("loading")}
										</TableCell>
									</TableRow>
								) : !products?.products?.length ? (
									<TableRow>
										<TableCell colSpan={4} className="h-24 text-center">
											{t("No results.")}
										</TableCell>
									</TableRow>
								) : (
									products.products.slice(0, 5).map((product: any) => (
										<TableRow key={product._id}>
											<TableCell className="font-medium">{product.name}</TableCell>
											<TableCell>{product.provider || t("No se encuentra proveedor")}</TableCell>
											<TableCell>{product.available_quantity || 0}</TableCell>
											<TableCell className="text-right">
												{product.prices?.[0]?.reference?.toLocaleString("es-CO", {
													style: "currency",
													currency: "COP",
												}) || "-"}
											</TableCell>
										</TableRow>
									))
								)}
							</TableBody>
						</Table>
					</section>
				</div>
			</main>
		</>
	)
}
