import React, { useEffect } from "react"
import {
	ColumnDef,
	ColumnFiltersState,
	flexRender,
	getCoreRowModel,
	getFilteredRowModel,
	getPaginationRowModel,
	getSortedRowModel,
	SortingState,
	useReactTable,
} from "@tanstack/react-table"
import { Input } from "@/modules/common/components/ui/input"
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@/modules/common/components/ui/table"
import { useTranslation } from "react-i18next"
import {
	Pagination,
	PaginationContent,
	PaginationEllipsis,
	PaginationItem,
	PaginationLink,
	PaginationNext,
	PaginationPrevious,
} from "@/modules/common/components/ui/pagination"
import { searchProviders } from "../../services/providers"
import { Card } from "@/modules/common/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/modules/common/components/ui/radio-group"
import { Label } from "@/modules/common/components/ui/label"
import LogoLoader from "@/modules/common/components/app/LogoLoader/LogoLoader"

interface Props {
	onSelect?: (row: any) => void
	selected: boolean
	isSync: boolean
	setIsSync: (value: boolean) => void
}

export function DataTableProviders({ onSelect, selected, isSync, setIsSync }: Props) {
	const [sorting, setSorting] = React.useState<SortingState>([])
	const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
	const [columnVisibility, setColumnVisibility] = React.useState({})
	const [rowSelection, setRowSelection] = React.useState({})
	const { t } = useTranslation(["providers"])
	const [data, setData] = React.useState([])
	const [filter, setFilter] = React.useState("")
	const [personType, setPersonType] = React.useState("all")
	const [pagination, setPagination] = React.useState({
		pageIndex: 0, //initial page index
		pageSize: 15, //default page size
	})

	const [paginationInfo, setPaginationInfo] = React.useState({
		total: 0, //total number of records
		totalPages: 0, //total number of pages
	})

	useEffect(() => {
		const fetchProviders = async () => {
			const providers = await searchProviders({
				limit: pagination.pageSize,
				page: pagination.pageIndex + 1,
				search: filter,
				personType: personType.charAt(0).toUpperCase() + personType.slice(1),
			})
			setData(providers.providers)
			setPaginationInfo({
				total: providers.total,
				totalPages: providers.totalPages,
			})
			setIsSync(true)
		}

		fetchProviders()
	}, [pagination, filter, personType, isSync, setIsSync])

	const columns: ColumnDef<any>[] = [
		{
			accessorKey: "name",
			header: () => <div>{t("table.name")}</div>,
			cell: ({ row }) => <div className="capitalize">{row.getValue("name")}</div>,
		},
		{
			accessorKey: "id",
			header: () => <div>CC/NIT</div>,
			cell: ({ row }) => <div>{row.getValue("id")}</div>,
		},
		{
			accessorKey: "personType",
			header: () => <div>{t("table.type")}</div>,
			cell: ({ row }) => (
				<div>{t(`table.${(row.getValue("personType") as string).toLowerCase()}`)}</div>
			),
		},
		{
			accessorKey: "createdAt",
			header: () => <div className="text-right">{t("table.creationDate")}</div>,
			cell: ({ row }) => (
				<div className="text-right">
					{row.getValue("createdAt")
						? new Date(row.getValue("createdAt")).toLocaleDateString()
						: "N/A"}
				</div>
			),
		},
	]

	const table = useReactTable({
		data,
		columns,
		onSortingChange: setSorting,
		onColumnFiltersChange: setColumnFilters,
		getCoreRowModel: getCoreRowModel(),
		getPaginationRowModel: getPaginationRowModel(),
		getSortedRowModel: getSortedRowModel(),
		getFilteredRowModel: getFilteredRowModel(),
		onColumnVisibilityChange: setColumnVisibility,
		onRowSelectionChange: setRowSelection,
		manualPagination: true,
		onPaginationChange: setPagination,
		rowCount: paginationInfo.total,
		pageCount: paginationInfo.totalPages,
		state: {
			sorting,
			columnFilters,
			columnVisibility,
			rowSelection,
		},
	})

	useEffect(() => {
		if (!selected) {
			table.resetRowSelection()
		}
	}, [selected, table])

	return (
		<div className="w-full mt-6 flex flex-col gap-4">
			<div className="flex w-full justify-between items-center ml-1">
				<h2>{t("labels.listaProveedores")}</h2>
				<Input
					type="text"
					placeholder={t("labels.inputPlaceholder")}
					variant="search"
					className="w-1/2 h-8 mr-1"
					autoComplete="off"
					spellCheck="false"
					value={filter}
					onChange={(event) => {
						setFilter(event.target.value)
						setPagination({ ...pagination, pageIndex: 0 })
					}}
				/>
			</div>
			<div className="flex gap-8 justify-between items-center">
				<RadioGroup
					value={personType}
					onValueChange={(value) => setPersonType(value)}
					className="flex flex-wrap gap-4"
				>
					<div className="flex items-center">
						<RadioGroupItem value="all" id="r1" />
						<Label htmlFor="r1">{t("table.all")}</Label>
					</div>
					<div className="flex items-center">
						<RadioGroupItem value="Company" id="r2" />
						<Label htmlFor="r2">{t("table.company")}</Label>
					</div>
					<div className="flex items-center">
						<RadioGroupItem value="Person" id="r3" />
						<Label htmlFor="r3">{t("table.person")}</Label>
					</div>
				</RadioGroup>
				<Card className="bg-primary-green-50 border border-primary-green-1200 px-4 py-2 flex justify-between items-center w-1/2">
					<span>{t("table.total")}</span>
					<span>{paginationInfo.total}</span>
				</Card>
			</div>
			<Table>
				<TableHeader>
					{table.getHeaderGroups().map((headerGroup) => (
						<TableRow key={headerGroup.id}>
							{headerGroup.headers.map((header) => {
								return (
									<TableHead key={header.id}>
										{header.isPlaceholder
											? null
											: flexRender(header.column.columnDef.header, header.getContext())}
									</TableHead>
								)
							})}
						</TableRow>
					))}
				</TableHeader>
				<TableBody>
					{table.getRowModel().rows?.length ? (
						table.getRowModel().rows.map((row) => (
							<TableRow
								key={row.id}
								data-state={row.getIsSelected() && "selected"}
								className="cursor-pointer"
								onClick={() => {
									if (onSelect) onSelect(row.original)
									table.resetRowSelection()
									row.toggleSelected()
								}}
							>
								{row.getVisibleCells().map((cell) => (
									<TableCell key={cell.id}>
										{flexRender(cell.column.columnDef.cell, cell.getContext())}
									</TableCell>
								))}
							</TableRow>
						))
					) : (
						<TableRow>
							<TableCell colSpan={columns.length} className="h-24 text-center">
								{isSync ? t("labels.noResults") : <LogoLoader className="size-12 mx-auto" />}
							</TableCell>
						</TableRow>
					)}
				</TableBody>
			</Table>
			<Pagination className="mb-2">
				<PaginationContent>
					<PaginationItem>
						<PaginationPrevious
							onClick={() => {
								if (pagination.pageIndex !== 0)
									setPagination({ ...pagination, pageIndex: pagination.pageIndex - 1 })
							}}
							disabled={pagination.pageIndex === 0}
							displayName={t("pagination.previous")}
						/>
					</PaginationItem>
					{pagination.pageIndex > 1 && (
						<>
							<PaginationItem>
								<PaginationLink onClick={() => setPagination({ ...pagination, pageIndex: 0 })}>
									1
								</PaginationLink>
							</PaginationItem>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
						</>
					)}
					{pagination.pageIndex > 0 && (
						<PaginationItem>
							<PaginationLink
								onClick={() =>
									setPagination({ ...pagination, pageIndex: pagination.pageIndex - 1 })
								}
							>
								{pagination.pageIndex}
							</PaginationLink>
						</PaginationItem>
					)}
					<PaginationItem>
						<PaginationLink isActive>{pagination.pageIndex + 1}</PaginationLink>
					</PaginationItem>
					{paginationInfo.totalPages >= pagination.pageIndex + 2 && (
						<PaginationItem>
							<PaginationLink
								onClick={() =>
									setPagination({ ...pagination, pageIndex: pagination.pageIndex + 1 })
								}
							>
								{pagination.pageIndex + 2}
							</PaginationLink>
						</PaginationItem>
					)}
					{paginationInfo.totalPages > pagination.pageIndex + 2 && (
						<>
							<PaginationItem>
								<PaginationEllipsis />
							</PaginationItem>
							<PaginationItem>
								<PaginationLink
									onClick={() =>
										setPagination({ ...pagination, pageIndex: table.getPageCount() - 1 })
									}
								>
									{table.getPageCount()}
								</PaginationLink>
							</PaginationItem>
						</>
					)}
					<PaginationItem>
						<PaginationNext
							onClick={() => {
								if (pagination.pageIndex < paginationInfo.totalPages - 1)
									setPagination({ ...pagination, pageIndex: pagination.pageIndex + 1 })
							}}
							disabled={pagination.pageIndex === paginationInfo.totalPages - 1}
							displayName={t("pagination.next")}
						/>
					</PaginationItem>
				</PaginationContent>
			</Pagination>
		</div>
	)
}
