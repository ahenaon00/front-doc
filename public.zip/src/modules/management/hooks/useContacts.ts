import { useState } from "react"

interface Contact {
	id?: number
	firstName?: string
	lastName?: string
	email: string
}

function useContacts(getValues: () => Contact[], setValues: (contacts: Contact[]) => void) {
	const [id, setId] = useState(2)

	const [contacts, setContacts] = useState<Contact[]>(getValues())

	const addContact = (contact: Contact) => {
		const newContacts = [...getValues(), { ...contact, id }]
		setValues(newContacts)
		setContacts(newContacts)

		setId(id + 1)
	}

	const removeContact = (contactId: number) => {
		const newContacts = getValues().filter((contact) => contact.id !== contactId)
		setValues(newContacts)
		setContacts(newContacts)
	}


	return {
		contacts,
		addContact,
		removeContact,
	}
}

export default useContacts
