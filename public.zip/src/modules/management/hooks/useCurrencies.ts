import { useState } from "react"

interface Currency {
	id?: number
	currencyCode: string
	collapsed: boolean
	priceList: Price[]
}

interface Price {
	id?: number
	name: string
	value: string
}

function useCurrencies(getValues: () => Currency[], setValues: (currencies: Currency[]) => void) {
	const [id, setId] = useState(2)
	const [priceId, setPriceId] = useState(2)

	const [currencies, setCurrencies] = useState<Currency[]>(getValues())

	const addCurrency = (price: Currency) => {
		const newPrices = [...getValues(), { ...price, id }]
		setValues(newPrices)
		setCurrencies(newPrices)

		setId(id + 1)
	}

	const removeCurrency = (currencyId: number) => {
		const newCurrencies = getValues().filter((currency) => currency.id !== currencyId)
		setValues(newCurrencies)
		setCurrencies(newCurrencies)
	}

	const addPrice = (currencyId: number, price: Price) => {
		const newCurrencies = getValues().map((currency) => {
			if (currency.id === currencyId) {
				return {
					...currency,
					priceList: [...currency.priceList, { ...price, id: priceId }],
				}
			}

      setPriceId(priceId + 1)

			return currency
		})

		setValues(newCurrencies)
		setCurrencies(newCurrencies)
	}

	const removePrice = (currencyId: number, priceId: number) => {
		const newCurrencies = getValues().map((currency) => {
			if (currency.id === currencyId) {
				return {
					...currency,
					priceList: currency.priceList.filter((price) => price.id !== priceId),
				}
			}

			return currency
		})

		setValues(newCurrencies)
		setCurrencies(newCurrencies)
	}

	const toggleCollapse = (currencyId: number) => {
		const newCurrencies = getValues().map((currency) => {
			if (currency.id === currencyId) {
				return {
					...currency,
					collapsed: !currency.collapsed,
				}
			}

			return currency
		})

		setValues(newCurrencies)
		setCurrencies(newCurrencies)
	}

	return {
		currencies,
		addCurrency,
		removeCurrency,
		addPrice,
		removePrice,
		toggleCollapse,
	}
}

export default useCurrencies
