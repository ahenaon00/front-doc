import axios from "axios"
import Cookies from "js-cookie"

const VITE_BASE_URL = import.meta.env.VITE_BASE_URL + "/api/taxes"

// Obtener impuestos del mes actual
export const getTaxesByMonth = async () => {
	try {
		const response = await axios.get(`${VITE_BASE_URL}/month`, {
			headers: {
				Authorization: `Bearer ${Cookies.get("token")}`,
			},
		})
		return response.data
	} catch (error) {
		console.error("Error getting taxes by month:", error)
		throw error
	}
}
