import { StrictMode, Suspense } from "react"
import { createRoot } from "react-dom/client"
import { Provider } from "react-redux"

import App from "@/App"
import { store } from "@/modules/common/lib/redux/store"
import "@/index.css"
import "@/modules/common/config/translate/i18n.config"
import "@/modules/common/config/security/jwt"
import LogoLoader from "@/modules/common/components/app/LogoLoader/LogoLoader"

createRoot(document.getElementById("root")!).render(
	<StrictMode>
		<Provider store={store}>
			<Suspense
				fallback={
					<main className="flex items-center justify-center h-screen w-screen">
						<LogoLoader className="h-32 w-32" />
					</main>
				}
			>
				<App />
			</Suspense>
		</Provider>
	</StrictMode>,
)
