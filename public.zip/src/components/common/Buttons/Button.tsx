import "./Button.css"
import { cn } from "@/modules/common/lib/utils"

interface Props {
	text: string
	onClick: () => void
	disabled?: boolean
	svg?: React.ReactNode
	type?: "button" | "submit" | "reset"
	className?: string
}

const Button = ({ text, onClick, disabled, svg, type = "button", className }: Props) => {
	return (
		<button
			type={type}
			onClick={onClick}
			disabled={disabled}
			className={cn("reusable-btn bg-green-600", className)}
		>
			{svg}
			<p>{text}</p>
		</button>
	)
}

export default Button
