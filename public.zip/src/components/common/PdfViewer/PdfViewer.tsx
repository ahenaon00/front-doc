import { useState } from "react"
import { Document, Page } from "react-pdf"

import "react-pdf/dist/esm/Page/AnnotationLayer.css"
import { Button } from "@/modules/common/components/ui/button"
import { ArrowLeft, ArrowRight, Minus, Plus } from "lucide-react"
import { cn } from "@/modules/common/lib/utils"
import LogoLoader from "@/modules/common/components/app/LogoLoader/LogoLoader"

interface Props {
	pdfFile: string
	zoom?: number
	className?: string
}

export const PdfViewer = ({ pdfFile, className, zoom = 1 }: Props) => {
	const [numPages, setNumPages] = useState<number>(0)
	const [pageNumber, setPageNumber] = useState(1)
	const [scale, setScale] = useState(zoom) // For zooming

	function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
		setNumPages(numPages)
		setPageNumber(1) // Reset to first page when document loads
	}

	// Navigation functions
	const goToPrevPage = () => setPageNumber(pageNumber - 1 <= 1 ? 1 : pageNumber - 1)
	const goToNextPage = () => setPageNumber(pageNumber + 1 >= numPages ? numPages : pageNumber + 1)

	// Zoom functions
	const zoomIn = () => setScale(scale + 0.25)
	const zoomOut = () => setScale(scale - 0.25 > 0 ? scale - 0.25 : 0.25)

	return (
		<article className={cn("bg-primary-grey-100 p-1 rounded-xl", className)}>
			<div
				className="relative bg-primary-grey-100 overflow-scroll p-2 pb-0 rounded-lg h-full w-full"
				style={{ scrollbarColor: "#999 hsl(204 16% 94%)" }}
			>
				<Document
					file={pdfFile}
					onLoadSuccess={onDocumentLoadSuccess}
					className="h-full w-min mx-auto"
					loading={
						<div className="flex items-center justify-center h-full">
							<LogoLoader className="h-20 w-20" />
						</div>
					}
				>
					<Page
						pageNumber={pageNumber}
						scale={scale}
						renderTextLayer={false}
						renderAnnotationLayer={false}
					/>
				</Document>
				<div className="sticky bottom-0 top-[calc(100%-36px)] -left-2 -right-2 flex items-center justify-between px-4 -mx-2 bg-primary-grey-100/50 backdrop-blur-md">
					<p className="w-1/3">
						Página {pageNumber} de {numPages}
					</p>
					<div className="w-1/3 flex items-center gap-2 justify-center">
						<Button variant="ghost" onClick={goToPrevPage} disabled={pageNumber <= 1}>
							<ArrowLeft className="size-8" />
						</Button>
						<Button variant="ghost" onClick={goToNextPage} disabled={pageNumber >= numPages}>
							<ArrowRight className="size-8" />
						</Button>
					</div>
					<div className="w-1/3 flex items-center gap-2 justify-end">
						<Button variant="primary" className="p-1 h-6" onClick={zoomOut} disabled={scale <= 0.5}>
							<Minus className="size-2" />
						</Button>
						<span>{(scale * 100).toFixed(0)}%</span>
						<Button variant="primary" className="p-1 h-6" onClick={zoomIn} disabled={scale >= 2}>
							<Plus className="size-2" />
						</Button>
					</div>
				</div>
			</div>
		</article>
	)
}
