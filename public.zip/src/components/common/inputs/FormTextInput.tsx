import { cn } from "@/modules/common/lib/utils"

interface Props {
	id: string
	label: string
	value: string | number
	className?: string
	onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
	number?: boolean
	disabled?: boolean
}

export default function FormTextInput({
	id,
	label,
	className,
}: Props) {
	return (
		<div className={cn("relative", className)}>
			<input
				id={id}
				name={id}
				className="border-b w-full border-gray-300 disabled:text-gray-500 py-1 focus:border-b-2 focus:border-[#006e25] transition-colors focus:outline-none peer bg-inherit"
			/>
			<label
				htmlFor={id}
				className="absolute w-full left-0 -translate-y-4 cursor-text text-xs peer-focus:-translate-y-4 transition-all peer-focus:text-[#006e25] peer-placeholder-shown:translate-y-1 text-gray-500 peer-placeholder-shown:text-base"
			>
				{label}
			</label>
		</div>
	)
}
