import { cn } from "@/modules/common/lib/utils"

interface Props {
	id: string
	label: string
	className?: string
	value: boolean
	onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
}

export default function FormCheckInput({ id, label, className, value, onChange }: Props) {
	return (
		<div className={cn("flex gap-2 group items-center", className)}>
			<label htmlFor={id} className="text-gray-500 group-hover:text-[#006e25]">
				{label}
			</label>
			<input
				id={id}
				type="checkbox"
				className="h-5 w-5 border-gray-300 rounded focus:border-[#006e25] group-hover:border-[#006e25]"
				checked={value}
				onChange={onChange}
			/>
		</div>
	)
}
