import { Check, Pencil, PencilOff } from "lucide-react"
import { useState } from "react"

interface Props {
	name: string
	description: string
	value: string
	handleChange: (e: any) => void
	handleSave: (name: string, value: string, required: boolean) => void
	required?: boolean
	number?: boolean
	disabled?: boolean
	options?: string[]
}

export default function InvoiceFormInput({
	name,
	description,
	value,
	handleChange,
	handleSave,
	required = false,
	number = false,
	disabled = false,
	options = [],
}: Props) {
	const [edit, setEdit] = useState(false)
	const [savedValue, setSavedValue] = useState(value)
	const [currentValue, setCurrentValue] = useState(value)

	const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		setCurrentValue(e.target.value)
		handleChange(e)
	}

	const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
		setCurrentValue(e.target.value)
		handleChange(e as any)
	}

	return (
		<div className="form-group">
			<div className="flex justify-between">
				<label htmlFor={name}>{description}</label>
			</div>
			<div className="group relative form-control p-0">
				{options.length > 0 ? (
					<select
						className="w-full p-2"
						id={name}
						name={name}
						value={currentValue}
						onChange={handleSelectChange}
						disabled={!edit}
					>
						{options.map((option, index) => (
							<option key={index} value={option}>
								{option}
							</option>
						))}
					</select>
				) : (
					<input
						className="w-full p-2"
						id={name}
						type={number ? "number" : "text"}
						name={name}
						value={disabled ? value : currentValue}
						onChange={handleInputChange}
						disabled={!edit}
					/>
				)}
				{!disabled && (
					<div className="flex gap-2 absolute top-1/2 right-2 -translate-y-1/2 group-hover:opacity-100 opacity-0">
						{edit ? (
							<>
								<button
									type="button"
									onClick={() => {
										setEdit(false)
										handleSave(name, currentValue, required)
										if (required && currentValue.trim() === "") {
											setCurrentValue(savedValue)
											return
										}
										setSavedValue(currentValue)
									}}
								>
									<Check
										className="text-green-600 opacity-50 hover:opacity-100"
										size={24}
									/>
								</button>
								<button
									type="button"
									onClick={() => {
										setCurrentValue(savedValue)
										setEdit(false)
									}}
								>
									<PencilOff
										className="text-red-600 opacity-50 hover:opacity-100"
										size={24}
									/>
								</button>
							</>
						) : (
							<button type="button" onClick={() => setEdit(true)}>
								<Pencil
									className="text-yellow-600 opacity-50 hover:opacity-100"
									size={24}
								/>
							</button>
						)}
					</div>
				)}
			</div>
		</div>
	)
}
