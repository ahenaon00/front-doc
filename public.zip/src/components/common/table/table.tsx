import { useState } from "react"
import { useTranslation } from "react-i18next"

// Import components
import { ToastContainer, toast } from "react-toastify"

// Import Services
import { updateInvoice } from "../../../modules/causation/services/invoice"

// Import Styles
import "./table.css"
import InvoiceFormInput from "../inputs/InvoiceFormInput"
import ItemRow from "./ItemRow"

interface Props {
	Items: Array<any>
	DueDate: string
	InvoiceId: string
	InvoiceTotal: string
	CustomerName: string
	CustomerId: string
	CustomerAddress: string
	CustomerCity: string
	IssueDate: string
	InvoiceTax: number
	Id: string
	supplierId: {
		id?: string
		vendorName?: string
		vendorNit?: string
		vendorAddress?: string
		vendorCity?: string
	}
}

export const Table = ({
	Id,
	Items,
	DueDate,
	InvoiceId,
	InvoiceTotal,
	supplierId,
	CustomerName,
	CustomerId,
	CustomerAddress,
	CustomerCity,
	IssueDate,
	InvoiceTax,
}: Props) => {
	const { t } = useTranslation(["transaction"])
	const [newItems, setNewItems] = useState([])


	const cities = ["Bogotá, d.c"]
	const [formData, setFormData] = useState({
		items: Items,
		dueDate: DueDate,
		invoiceId: InvoiceId,
		invoiceTotal: InvoiceTotal,
		supplierId: supplierId,
		vendorAddress: supplierId.vendorAddress,
		vendorName: supplierId.vendorName,
		vendorNit: supplierId.vendorNit,
		vendorCity: supplierId.vendorCity,
		customerName: CustomerName,
		customerId: CustomerId,
		customerAddress: CustomerAddress,
		customerCity: CustomerCity,
		issueDate: IssueDate,
		invoiceTax: InvoiceTax,
	})

	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		const { name } = e.target
		setFormData((prevState) => ({
			...prevState,
			[name]: e.target.value,
		}))
	}

	const handleSave = (name: string, value: string, required: boolean = false) => {
		if (required && value.trim() === "") {
			toastPop(t("transaction.table.messages.fieldEmpty"), "colored")
			return
		}

		setFormData((prevState) => ({
			...prevState,
			[name]: value,
		}))
		
		updateinvoice()
	}

	const toastPop = (message: string, type: "light" | "dark" | "colored") => {
		toast(message, {
			position: "bottom-right",
			autoClose: 5000,
			hideProgressBar: false,
			closeOnClick: true,
			pauseOnHover: true,
			draggable: true,
			progress: undefined,
			theme: type,
		})
	}

	const updateinvoice = async () => {
		try {
			const response = await updateInvoice(Id, formData)
			if (response.status === 200) {
				toastPop(t("transaction.table.messages.updatedSuccess"), "light")
			} else {
				toastPop(t("transaction.table.messages.updateError"), "colored")
			}
		} catch (error) {
			console.error(error)
			toastPop(t("transaction.table.messages.updateError"), "colored")
		}
	}

	const validItem = (
		description: string,
		quantity: number,
		total: number,
		unitPrice: number,
		unitTax: number,
	) => {
		return (
			description &&
			description?.trim() !== "" &&
			quantity > 0 &&
			total > 0 &&
			unitPrice > 0 &&
			unitTax >= 0
		)
	}

	const saveRow = ({ description, quantity, total, unitPrice, tax }: any, id: string) => {
		if (!validItem(description, quantity, total, unitPrice, tax)) {
			toastPop(t("transaction.table.messages.completeFields"), "colored")
			return
		}

		setFormData((prev) => {
			const newItems = prev.items.map((item) => (item.id === id ? { ...item } : item))
			updateinvoice()
			return { ...prev, items: newItems }
		})
	}

	const createRow = ({ description, quantity, total, unitPrice, tax }: any, id: string) => {
		if (!validItem(description, quantity, total, unitPrice, tax)) {
			toastPop(t("transaction.table.messages.completeFields"), "colored")
			return
		}
		setNewItems((prev) => prev.filter((item: any) => id !== item.id))
		setFormData((prev) => {
			const newItems = [...prev.items]
			newItems.push({
				id,
				description: description,
				quantity: quantity,
				total: total,
				unitPrice: unitPrice,
				unitTax: tax,
			})
			updateinvoice()
			return { ...prev, items: newItems }
		})
	}

	const deleteRow = (id: any) => {
		setNewItems((prev) => prev.filter((item: any) => item.id !== id))
		setFormData((prev) => {
			const newItems = prev.items.filter((item) => item.id !== id)
			return {
				...prev,
				items: newItems,
			}
		})
	}

	return (
		<form>
			<div>
				<ToastContainer />
				<div className="invoice-data">
					<h2 className="mb-4">{t("transaction.table.invoiceInfo")}</h2>
					<InvoiceFormInput
						name="dueDate"
						description={t("transaction.table.fields.dueDate")}
						value={formData.dueDate}
						handleChange={handleChange}
						handleSave={handleSave}
						required
					/>
					<InvoiceFormInput
						name="issueDate"
						description={t("transaction.table.fields.issueDate")}
						value={formData.issueDate}
						handleChange={handleChange}
						handleSave={handleSave}
						required
					/>
					<InvoiceFormInput
						name="invoiceId"
						description={t("transaction.table.fields.invoiceId")}
						number
						value={formData.invoiceId}
						handleChange={handleChange}
						handleSave={handleSave}
						required
					/>
					<InvoiceFormInput
						name="invoiceTotal"
						description={t("transaction.table.fields.invoiceTotal")}
						number
						value={formData.invoiceTotal}
						handleChange={handleChange}
						handleSave={handleSave}
						required
					/>
				</div>

				<div className="invoice-data">
					<h2 className="mb-4">{t("transaction.table.providerInfo")}</h2>
					{/* <InvoiceCombobox
						id="searchProvider"
						label={t("transaction.table.fields.vendorName")}
						values={providers}
						onSelect={(value, selected) => {
							if (selected) {
								value.addresses = value.addresses || []
								updateProvider(value) // Immediately update provider if selected
							} else {
								getProvidersByQuery(value || "") // Continue querying if user is typing
							}
						}}
						value={undefined}
					/> */}
					<InvoiceFormInput
						name="vendorName"
						description={t("transaction.table.fields.vendorName")}
						value={formData.vendorName ?? ""}
						handleChange={handleChange}
						handleSave={handleSave}
						disabled
					/>
					<InvoiceFormInput
						name="vendorNit"
						description={t("transaction.table.fields.vendorNit")}
						value={formData.vendorNit ?? ""}
						handleChange={handleChange}
						handleSave={handleSave}
						required
						disabled
					/>
					<InvoiceFormInput
						name="vendorAddress"
						description={t("transaction.table.fields.vendorAddress")}
						value={formData.vendorAddress ?? ""}
						handleChange={handleChange}
						handleSave={handleSave}
						disabled
					/>
					<InvoiceFormInput
						name="vendorCity"
						description={t("transaction.table.fields.vendorCity")}
						value={formData.vendorCity ?? ""}
						handleChange={handleChange}
						handleSave={handleSave}
						required
						options={cities}
					/>
				</div>

				<div className="invoice-data">
					<h2 className="mb-4">{t("transaction.table.customerInfo")}</h2>
					<InvoiceFormInput
						name="customerName"
						description={t("transaction.table.fields.customerName")}
						value={formData.customerName}
						handleChange={handleChange}
						handleSave={handleSave}
					/>
					<InvoiceFormInput
						name="customerId"
						description={t("transaction.table.fields.customerId")}
						number
						value={formData.customerId}
						handleChange={handleChange}
						handleSave={handleSave}
					/>
					<InvoiceFormInput
						name="customerAddress"
						description={t("transaction.table.fields.customerAddress")}
						value={formData.customerAddress}
						handleChange={handleChange}
						handleSave={handleSave}
					/>
					<InvoiceFormInput
						name="customerCity"
						description={t("transaction.table.fields.customerCity")}
						value={formData.customerCity}
						handleChange={handleChange}
						handleSave={handleSave}
						required
						options={cities}
					/>
				</div>
			</div>
			<h2>{t("transaction.table.products")}</h2>
			<table className="table" style={{ marginBottom: "1rem" }}>
				<thead>
					<tr>
						<th>{t("transaction.table.fields.description")}</th>
						<th>{t("transaction.table.fields.quantity")}</th>
						<th>{t("transaction.table.fields.total")}</th>
						<th>{t("transaction.table.fields.unitPrice")}</th>
						<th>{t("transaction.table.fields.tax")}</th>
					</tr>
				</thead>
				<tbody>
					{formData.items.map(({ description, quantity, total, unitPrice, unitTax, id }) => (
						<ItemRow
							key={id}
							description={description}
							quantity={quantity}
							total={total}
							unitPrice={unitPrice}
							tax={unitTax}
							handleSave={(value) => saveRow(value, id)}
							handleDelete={() => deleteRow(id)}
						/>
					))}
					{newItems.map(({ description, quantity, total, unitPrice, unitTax, id }) => (
						<ItemRow
							key={id}
							description={description}
							quantity={quantity}
							total={total}
							unitPrice={unitPrice}
							tax={unitTax}
							handleSave={(value) => createRow(value, id)}
							handleDelete={() => deleteRow(id)}
							enabled
						/>
					))}
				</tbody>
			</table>
			<div
				className="opts"
				style={{
					gap: "2rem",
					width: "100%",
					display: "flex",
					justifyContent: "flex-end",
				}}
			>
				{/* <Button type="button" text="Add Item" onClick={addNewItemRow} /> */}
			</div>
		</form>
	)
}
