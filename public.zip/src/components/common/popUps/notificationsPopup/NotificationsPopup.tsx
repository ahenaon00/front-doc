import PropTypes from "prop-types"
import { useEffect, useRef } from "react"
import { useSelector } from "react-redux"
import { useNavigate } from "react-router-dom"

import Notification from "../../notifications/Notification"

interface Props {
	trigger: boolean;
	setTriggers: React.Dispatch<React.SetStateAction<{ bell: boolean }>>;
}

export default function NotificationsPopup({ trigger, setTriggers }: Props) {
	const popupRef = useRef(null)
	const navigate = useNavigate()

	const notifications = useSelector((state: { notifications: { notifications: any[] } }) => state.notifications.notifications)

	const btn = document.getElementById("showNotifications")

	useEffect(() => {
		const handler = (e: MouseEvent) => {
			if (!btn) return
			if (popupRef.current && btn) {
				if (!(popupRef.current as HTMLElement).contains(e.target as Node) && !btn.contains(e.target as Node)) {
					setTriggers((prevTriggers) => ({
						...prevTriggers,
						bell: false,
					}))
				}
			}
		}
		document.addEventListener("mousedown", handler)
		return () => {
			document.removeEventListener("mousedown", handler)
		}
	}, [setTriggers])
	return (
		<div
			className={`bg-[#C4F7C2] py-1 rounded-md z-10 absolute top-16 -translate-x-24 h-fit flex flex-col items-center shadow-xl ${
				trigger ? "" : "hidden"
			}`}
			ref={popupRef}
		>
			<div className="overflow-y-scroll max-h-[50vh] no-scrollbar px-1 w-72 overflow-x-hidden">
				{notifications.map((data) => (
					<Notification key={data._id} notification={data} />
				))}
			</div>

			<div className="flex m-2 gap-4">
				<button
					className="text-black bg-white rounded-md px-2 hover:bg-neutral-50 shadow"
					onClick={() => {
						navigate("/notifications")
						setTriggers((prevTriggers) => ({
							...prevTriggers,
							bell: false,
						}))
					}}
				>
					Ver todas
				</button>
			</div>
		</div>
	)
}

NotificationsPopup.propTypes = {
	trigger: PropTypes.bool,
	setTriggers: PropTypes.func,
}
