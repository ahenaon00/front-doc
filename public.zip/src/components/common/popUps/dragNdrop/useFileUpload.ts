import { useState, useCallback } from 'react'
import { useDispatch } from 'react-redux'
import { addInvoice } from "../../../../modules/common/lib/redux/invoiceSlice.ts"
import { uploadFile } from '@/modules/causation/services/file'

const useFileUpload = (t: Function) => {
  const [totalFiles, setTotalFiles] = useState(0)
  const [progressCounts, setProgressCounts] = useState({ loading: 0, success: 0, error: 0 })
  const [showProgress, setShowProgress] = useState(false)
  const [fileStatuses, setFileStatuses] = useState<any[]>([])
  const dispatch = useDispatch()

  
  // Manejar la carga de archivos
  const handleFile = async (file: File) => {
    const formData = new FormData()
    formData.append("file", file)

    const fileType = file.type

    if (fileType === "application/zip" || fileType === "application/x-zip-compressed") {
      return handleZipFile(formData)
    } else {
      return {
        status: 415,
        message: t("messages.unsupportedFileType"), // "Tipo de archivo no soportado"
      }
    }
  }

  // Manejar la carga de archivos ZIP
  const handleZipFile = async (formData: any) => {
    try {
      // Sube el archivo
      const result = await uploadFile(formData)
      const { transactionEntity, invoice } = result.data

      return {
        status: result.status,
        path: transactionEntity.path,
        invoiceId: transactionEntity._id,
        data: invoice,
      }
    } catch (error: any) {
      console.error("Error in handleZipFile:", error)

      if (error.response && error.response.status === 400) {
        const { errors, errorTypes } = error.response.data

        // Procesar errores por tipo
        let translatedErrors = ""

        // Manejar errores de proveedor
        if (errorTypes.includes("provider")) {
          const providerErrors = errors.filter(
            (err: any) => err.error === "No se encontró el proveedor",
          )
          const providerDetails = providerErrors
            .map((e: any) => {
              return `${t("messages.errorProvider")}: ${e.supplier.name} (${e.supplier.vendorAddress}, ${e.supplier.vendorEmail})`
            })
            .join(". ")
          translatedErrors += providerDetails + ". "
        }

        // Manejar errores de ítems
        if (errorTypes.includes("item")) {
          const itemErrors = errors.filter(
            (err: any) => err.error === "No se encontraron los items en el inventario",
          )
          const itemNames = itemErrors
            .flatMap((e: any) => e.items.map((item: any) => item.description)) // Obtener nombres de todos los ítems
            .join(", ")
          translatedErrors += `${t("messages.errorItemNotFound")}${itemNames}. `
        }

        // Manejar errores de PUC
        if (errorTypes.includes("puc")) {
          translatedErrors += `${t("messages.errorPUC")}. `
        }

        return {
          status: error.response.status,
          message: translatedErrors.trim(), // Eliminar espacios innecesarios al final
        }
      } else if (error.response && error.response.status === 406) {
        return {
          status: error.response.status,
          message: t("messages.invalidInvoice"), // "Factura inválida."
        }
      } else if (error.response && error.response.status === 409) {
        return {
          status: error.response.status,
          message: t("messages.uploadDuplicate"), // "Archivo duplicado."
        }
      }

      // Manejo genérico de errores
      return {
        status: error.response ? error.response.status : 500,
        message: error.message || t("messages.genericError"), // "Ocurrió un error."
      }
    }
  }

  // Manejar la caída de archivos
  const onDrop = useCallback(
    (acceptedFiles: any) => {
      const totalFiles = acceptedFiles.length
      console.log("📦 Total files to upload:", totalFiles)
      setTotalFiles(acceptedFiles.length)
      setProgressCounts({
        loading: acceptedFiles.length,
        success: 0,
        error: 0,
      })
      setShowProgress(true)

      // Inicializamos todos los estados como "loading" de una sola vez si quieres usar el índice más adelante
      setFileStatuses((prevStatuses: any) => [
        ...prevStatuses,
        ...acceptedFiles.map((file: File) => ({
          name: file.name,
          status: "loading",
        })),
      ])

      acceptedFiles.forEach(async (file: File, index: number) => {
        const result = await handleFile(file)

        switch (result.status) {
          case 200:
            result.message = t("messages.uploadSuccess")
            break
          case 201:
            result.message = t("messages.uploadWarning")
            break
          case 202:
            result.message = t("messages.uploadAttention")
            break
          case 409:
            result.message = t("messages.uploadDuplicate")
            break
          case 406:
            result.message = t("messages.invalidInvoice")
            break
          default:
            break
        }

        dispatch(
          addInvoice({
            status: result.status,
            name: file.name,
            description: result.message,
            invoiceId: result.invoiceId,
            date: new Date().toLocaleString("es-CO", {
              day: "2-digit",
              month: "2-digit",
              year: "2-digit",
              hour: "numeric",
              minute: "2-digit",
              hour12: true,
            })
          }),
        )
        setProgressCounts((prev) => {
          if ([200, 201, 202].includes(result.status)) {
            return {
              ...prev,
              success: (prev.success ?? 0) + 1,
              loading: (prev.loading ?? 0) - 1,
            }
          } else {
            return {
              ...prev,
              error: (prev.error ?? 0) + 1,
              loading: (prev.loading ?? 0) - 1,
            }
          }
        })

        setFileStatuses((prevStatuses: any) => {
          const newStatuses = [...prevStatuses]
          newStatuses[index] = {
            ...newStatuses[index],
            status: result.status,
            message: result.message || t("messages.uploadSuccess"),
            invoiceId: result.invoiceId,
          }
          return newStatuses
        })
      })
    },
    [setShowProgress, setFileStatuses, handleFile, dispatch, t],
  )

  return {
    totalFiles,
    progressCounts,
    showProgress,
    fileStatuses,
    onDrop,
  }
}

export default useFileUpload
