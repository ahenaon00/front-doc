// src/components/common/DropzoneUpload.tsx
import { useDropzone } from "react-dropzone"
import { useCallback } from "react"
import PropTypes from "prop-types"
import { useTranslation } from "react-i18next"
import { FolderUp } from "lucide-react"
import { cn } from "@/modules/common/lib/utils"

interface DropzoneUploadProps {
	onDrop: (files: File[]) => void
	className?: string
	children?: React.ReactNode
	accept?: string | string[]
	multiple?: boolean
	landScape?: "Vertical" | "Horizontal"
}

const DropzoneUpload = ({
	onDrop,
	className = "",
	children,
	multiple = true,
	landScape = "Vertical",
}: DropzoneUploadProps) => {
	const { t } = useTranslation(["invoice"])
	const handleDrop = useCallback(
		(acceptedFiles: File[]) => {
			onDrop(acceptedFiles)
		},
		[onDrop],
	)

	const { getRootProps, getInputProps, isDragActive } = useDropzone({
		onDrop: handleDrop,
		multiple,
	})

	return (
		<div
			{...getRootProps()}
			className={`${landScape === "Horizontal" ? "flex flex-row" : "flex flex-col"} transition-all duration-200 border-2 border-dashed rounded-lg cursor-pointer hover:bg-[#33CB66]/10 ${isDragActive ? "border-primary-green-1200 bg-gray-50" : "border-gray-300"} ${className}`}
		>
			<FolderUp className={cn("size-14 stroke-1", { "size-20 mb-4": landScape !== "Horizontal" })} />
			<p className={`${landScape === "Horizontal" ? "text-xs" : ""} text-center text-gray-600`}>
				{t("labels.descriptionFileUpload")}{" "}
				<span className={`text-[#33CB66] font-medium cursor-pointer`}>
					{t("labels.descriptionFileUpload2")}
				</span>
			</p>
			<input {...getInputProps()} />
			{children}
		</div>
	)
}

DropzoneUpload.propTypes = {
	onDrop: PropTypes.func.isRequired,
	className: PropTypes.string,
	children: PropTypes.node,
	accept: PropTypes.oneOfType([PropTypes.string, PropTypes.arrayOf(PropTypes.string)]),
	multiple: PropTypes.bool,
}

export default DropzoneUpload
