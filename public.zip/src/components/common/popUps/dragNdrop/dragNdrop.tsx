// src/components/invoice/DragNdrop.jsx
import { useNavigate } from "react-router-dom"

// Import PropTypes
import "./dragNdrop.css" // Asegúrate de crear este archivo CSS para los estilos

// Import useTranslation
import { useTranslation } from "react-i18next"
import DropzoneUpload from "./dropZone.tsx"
import useFileUpload from "./useFileUpload.ts"
import { FileCheck, FileClock, FileX, X } from "lucide-react"

interface Props {
	show: boolean
	setShow: (value: boolean) => void
	onClose: () => void
	setShowProgress: (value: boolean) => void
	setFileStatuses: (value: any) => void
}

export const DragNdrop = ({show,setShow,onClose}:Props) => {
	const { t } = useTranslation(["invoice"])
	const { totalFiles, progressCounts, onDrop } = useFileUpload(t)

	const navigation = useNavigate()
	const handleClose = () => {
		setShow(false)
		if (onClose) onClose()
	}

	if (!show) return null

	const ProgressBar = ({
		total,
		success,
		error,
	}: {
		total: number
		success: number
		error: number
		loading: number
	}) => {
		if (total === 0) return null

		const successPercent = (success / total) * 100
		const errorPercent = (error / total) * 100
		const completed = successPercent + errorPercent
		return (
			<div className="w-full bg-gray-400 rounded-xl overflow-hidden h-2 flex">
				<div
					className="bg-green-500 h-2 transition-all duration-300"
					style={{ width: `${completed}%` }}
				/>
			</div>
		)
	}

	console.log("progressCounts ",progressCounts);
	
	return (
		<div className="popup-backdrop z-[100]">
			<div className="popup-content w-full max-w-xl bg-white rounded-xl shadow-lg p-6">
				{/* Header */}
				<div className="w-full flex justify-between align-middle items-center mb-4">
					<h2 className="text-xl font-semibold">{t("labels.headerFileUpload")}</h2>
					<button
						onClick={handleClose}
						className="flex justify-center h-full text-gray-500 hover:text-gray-800"
					>
						<X className="w-8 h-8" />
					</button>
				</div>

				{/* Dropzone */}
				<DropzoneUpload
					onDrop={onDrop}
					className="w-full p-14 flex flex-col items-center hover:bg-[#33CB66]/10"
					accept={["application/zip", "application/x-zip-compressed"]}
				>
					
				</DropzoneUpload>

				{/* Footer Info */}
				<div className="w-full flex justify-between mt-4 text-sm text-gray-500">
					<p>{t("labels.compatibleFileTypes")}</p>
					<p>{t("labels.sizeLimit")}</p>
				</div>

				{progressCounts.loading !== null && progressCounts.loading > 0 && (
					<div className="w-full flex flex-col">
						<div className="w-full flex justify-between items-center gap-2">
							<FileClock />
							<ProgressBar
								total={totalFiles}
								success={progressCounts.success ?? 0}
								error={progressCounts.error ?? 0}
								loading={progressCounts.loading}
							/>
						</div>
						<div className="w-full flex justify-between">
							<p className="w-full"></p>
							<p className="w-full self-end text-end text-gray-400">
								{totalFiles > 0
									? `${Math.round((((progressCounts.error ?? 0) + (progressCounts.success ?? 0)) * 100) / totalFiles)} %`
									: "0 %"}
							</p>
						</div>
					</div>
				)}

				{progressCounts.loading === 0 && (
					<>
						<div className="flex w-full gap-2">
							<FileCheck />
							<p>
								{progressCounts.success} {t("labels.invoiceLabel")}
								<span className="text-green-500 font-semibold"> {t('labels.successfullyUploaded')}</span>
							</p>
						</div>
						<div className="flex w-full gap-2">
							<FileX className="stroke-semantic-red-1200" /> 
							<p>
								{progressCounts.error} {t("labels.invoiceLabel")}
								<span className="text-red-500 font-semibold"> {t('labels.errorUploading')}</span>
							</p>
						</div>
						<div className="w-full flex justify-between items-center">
							<p className="text-gray-600 gap-2">{t('labels.totalInvoices')}: <span><strong>{(progressCounts.error ?? 0) + (progressCounts.success ?? 0)}</strong></span></p>
							<button
								className="px-4 py-2 text--[#18252F] rounded-full border-2 border-[#18252F] transition-colors duration-200"
								onClick={() => {
									navigation("/home/invoices-loaded")
									handleClose()
								}}
							>
								{t("labels.seeMore")}
							</button>
						</div>
					</>
				)}
			</div>
		</div>
	)
}
