import { useNavigate } from "react-router-dom"
import { useEffect, useRef } from "react"

// Import Loader
import { PulseLoader } from "react-spinners"

// Import SVG
import { FaCheck, FaTimes, FaBan } from "react-icons/fa"
import { IoWarning } from "react-icons/io5"

// Import components
import Button from "../../Buttons/Button"

// Import Utils
import { Each } from "../../../../modules/common/lib/utils/Each"

// Import Styles
import "./filesprogress.css"

interface Props {
	show: boolean
	onClose: () => void
	data: Array<{ name: string; status: number; message: string; id: string }>
	setData: React.Dispatch<React.SetStateAction<any[]>>
}

export const FilesProgress = ({ show, onClose, data, setData }: Props) => {
	const popupContentRef = useRef<HTMLDivElement>(null) // Create a ref for the popup content
	const navigation = useNavigate()
	useEffect(() => {
		if (data.some((file) => file.status === 401)) {
			setTimeout(() => {
				onClose()
				navigation("/login", { replace: true })
			}, 2000)
		}
	}, [data, navigation, onClose])

	const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
		// Check if the click is on the backdrop (and not on the popup content itself)
		if (popupContentRef.current && !popupContentRef.current.contains(e.target as Node)) {
			setData([])
			onClose()
			// Close the popup if the click is outside the popup content
		}
	}

	if (!show) {
		return null
	}

	return (
		<div className="popup-backdrop z-[100]" onClick={handleBackdropClick}>
			<div
				className="flex flex-col overflow-y-auto rounded-md bg-white max-h-[570px] max-w-[700px] shadow-md"
				ref={popupContentRef}
			>
				<Each
					data={data}
					render={(file: any, index: number) => (
						<div key={index} className="grid grid-cols-4 gap-4 items-center border-b px-4 py-3">
							{/* Nombre del archivo */}
							<h3 className=" text-sm font-medium text-gray-900">{file.name}</h3>

							{/* Estado del archivo con íconos */}
							<div className="flex items-center justify-center">
								{file.status === "loading" && <PulseLoader size={8} color={"var(--primary)"} />}
								{file.status === 200 && <FaCheck className="text-green-500 text-lg" />}
								{file.status === 201 && <IoWarning className="text-yellow-500 text-lg" />}
								{file.status === 202 && <FaTimes className="text-red-500 text-lg" />}
								{(file.status === 409 ||
									file.status === 400 ||
									file.status === 401 ||
									file.status === 500) && <FaBan className="text-red-500 text-lg" />}
							</div>

							{/* Mensaje de estado */}
							<p className="text-md text-muted-foreground">{file.message}</p>

							{/* Botón o errores */}
							<div className="flex items-center justify-end">
								{file.status === 409 && (
									<Button
										text="See in Invoices"
										onClick={() => {
											onClose()
											navigation(`/invoices-not-sent`)
										}}
									/>
								)}
								{file.status === 401 && (
									<p className="text-xs text-gray-500 italic">Redirigiendo...</p>
								)}

								{file.errors ? (
									<p className="text-xs text-red-500">{file.errors}</p>
								) : (
									(file.status === 200 || file.status === 201) && (
										<button
											onClick={() => navigation(`/invoice/${file.invoiceId}`)}
											className="px-3 py-1 bg-blue-500 text-white rounded-md text-xs hover:bg-blue-600 transition"
										>
											Ver Reporte
										</button>
									)
								)}
							</div>
						</div>
					)}
				/>
			</div>
		</div>
	)
}
