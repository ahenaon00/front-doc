// src/components/common/popUps/payPopUp/payPopUp.jsx
import { useRef, useState } from "react"

// Import Components
import Button from "../../Buttons/Button"
import { toggleToast } from "../../modules/modules"

// Import Services
import { depositDebt } from "../../../../modules/causation/services/invoice"

// Import Prop Types
import PropTypes from "prop-types"

interface Props {
	show: boolean
	onClose: () => void
	data: any
	onPaymentSuccess?: () => void
}

export const PayPopUp = ({ show, onClose, data, onPaymentSuccess }: Props) => {
	const [form, setForm] = useState({
		amount: 0,
		paymentType: "",
		paymentDate: new Date().toISOString().split("T")[0],
	})
	const [errors, setErrors] = useState<any>({})
	const [loading, setLoading] = useState(false) // New state for loading

	const popupContentRef = useRef<HTMLDivElement>(null)

	const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
		if (popupContentRef.current && !popupContentRef.current.contains(e.target as Node)) {
			e.stopPropagation()
			onClose()
		}
	}

	const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
		const { name, value } = e.target
		setForm((prevForm) => ({ ...prevForm, [name]: value }))
	}

	const handlePayment = async () => {
		setLoading(true) // Start loading
		try {
			await depositDebt(data.entity, form)
			toggleToast("Abono realizado con éxito")
			setLoading(false) // Stop loading
			onClose()
			// Call onPaymentSuccess callback to reload data after successful payment
			if (onPaymentSuccess) {
				onPaymentSuccess()
			}
		} catch (error) {
			setErrors({ response: "El valor abonado es mayor al de la deuda" })
			console.error("Error depositing debt:", error)
			setLoading(false) // Stop loading on error
		}
	}

	const validateForm = () => {
		const newErrors: any = {}
		if (!form.amount || form.amount <= 0) {
			newErrors.amount = "Please enter a valid amount."
		}
		if (!form.paymentType) {
			newErrors.paymentType = "Please select a payment method."
		}
		return newErrors
	}

	const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault()

		// Validate the amount and payment method
		const validationErrors: any = validateForm()
		if (Object.keys(validationErrors).length > 0) {
			setErrors(validationErrors)
			return
		}
		setErrors({})

		handlePayment() // Trigger payment on submit
	}

	if (!show) {
		return null
	}

	return (
		<div className="popup-backdrop z-50" onClick={handleBackdropClick}>
			<div
				className="popup-content-no-click"
				ref={popupContentRef}
				onClick={(e) => e.stopPropagation()}
			>
				<h2>Abonar factura</h2>

				<form onSubmit={handleSubmit}>
					<div className="input-group">
						<label htmlFor="amount">Valor:</label>
						<input
							type="number"
							name="amount"
							value={form.amount}
							onChange={handleChange}
							disabled={loading} // Disable input if loading
						/>
						{errors.amount && <span className="error-message">{errors.amount}</span>}
					</div>
					<div className="input-group">
						<label htmlFor="paymentType">Código:</label>
						<select
							name="paymentType"
							value={form.paymentType}
							onChange={handleChange}
							disabled={loading} // Disable select if loading
						>
							<option value="">Seleccione un método de pago</option>
							<option value="CASH">Efectivo</option>
							<option value="BANK_TRANSFER">Transferencia Bancaria</option>
							<option value="CREDIT_CARD">Tarjeta de crédito</option>
							<option value="DEBIT_CARD">Tarjeta débito</option>
						</select>
						{errors.paymentType && <span className="error-message">{errors.paymentType}</span>}
					</div>
					<div className="input-group">
						<label htmlFor="paymentDate">Fecha de abono</label>
						<input
							type="date"
							name="paymentDate"
							value={form.paymentDate}
							onChange={handleChange}
							disabled={loading} // Disable input if loading
						/>
					</div>
					<div className="error-message" style={{ margin: "1rem 0" }}>
						{errors.response}
					</div>

					{/* Show a loader if loading */}
					{loading ? (
						<p>Loading...</p>
					) : (
						<Button text="Pagar" type="submit" disabled={loading} onClick={() => {}} />
					)}
				</form>
			</div>
		</div>
	)
}

PayPopUp.propTypes = {
	show: PropTypes.bool.isRequired,
	onClose: PropTypes.func.isRequired,
	data: PropTypes.object.isRequired,
	onPaymentSuccess: PropTypes.func, // New prop for callback after payment
}
