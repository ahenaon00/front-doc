import { useRef, useState, useEffect } from "react"
import propTypes from "prop-types"
import { getInvoicePayments } from "../../../../modules/causation/services/invoice"
import { TableComponent } from "../../../../modules/causation/components/TableComponent/TableComponent"
import moment from "moment"

interface Props {
	show: boolean;
	data: {
		entity: string;
	};
	onClose: () => void;
}

export const PaymentHistoryPopUp = ({ show, data, onClose }: Props) => {
	const [historyData, setHistoryData] = useState([])
	const popupContentRef = useRef<HTMLDivElement>(null)

	useEffect(() => {
		if (show && data) {
			// Fetch payment history data
			const fetchHistoryData = async () => {
				try {
					const response = await getInvoicePayments(data.entity)
					const flattenData = response.map((item: any) => ({
						"Fecha": moment(item.date).format("DD/MM/YYYY"),
						"Cuenta Puc credito": item.paymentCodes.credit,
						"Cuenta Puc debito": item.paymentCodes.debit,
						"Medio de pago": item.paymentType,
						"Cantidad abonada": item.amount,
					}))
					setHistoryData(flattenData)
				} catch (error) {
					console.error("Error fetching payment history:", error)
				}
			}

			fetchHistoryData()
		}
	}, [show, data])

	const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
		if (popupContentRef.current && !popupContentRef.current.contains(e.target as Node)) {
			e.stopPropagation()
			onClose()
		}
	}

	return show ? (
		<div className="popup-backdrop z-50" onClick={handleBackdropClick}>
			<div
				className="popup-content-no-click"
				ref={popupContentRef}
				onClick={(e) => e.stopPropagation()}
			>
				<div className="flex flex-col gap-2 items-center">
					<h2>Historial de pagos</h2>

					{historyData.length > 0 ? (
						<TableComponent data={historyData} ActionComponent={undefined} onClick={() => {}} />
					) : (
						<p>No payment history available.</p>
					)}
				</div>
			</div>
		</div>
	) : null
}

PaymentHistoryPopUp.propTypes = {
	show: propTypes.bool.isRequired,
	data: propTypes.object.isRequired,
	onClose: propTypes.func.isRequired,
}
