import { useRef } from "react"
import Button from "../../Buttons/Button"

interface Props {
	show: boolean
	confirmation: () => void
	message: string
	onClose: () => void
}

export const ConfirmationOptionPopUp = ({ show, confirmation, message, onClose }: Props) => {
	const popupContentRef = useRef<HTMLDivElement>(null)
	// Comment out handleBackdropClick for testing

	const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
		if (popupContentRef.current && !popupContentRef.current.contains(e.target as Node)) {
			onClose()
		}
	}

	if (!show) {
		return null
	}

	return (
		<div className="popup-backdrop" onClick={handleBackdropClick}>
			<div className="popup-content" ref={popupContentRef}>
				<h2>{message}</h2>
				<div className="options">
					<Button text="Confirmar" onClick={confirmation} />
					<Button text="Cancelar" onClick={onClose} />
				</div>
			</div>
		</div>
	)
}
