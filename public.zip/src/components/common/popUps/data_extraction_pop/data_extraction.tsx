// Import Compoments
import { Table } from "../../table/table"

// Import Helpers
import { getDetailedData } from "@/modules/common/lib/utils/helpers.js"

// Import Styles
import "./data_extraction.css"

interface Props {
	show: boolean;
	fileData: any;
}

export const DataExtraction = ({ show, fileData }: Props) => {
	console.log("fileData", fileData)
	if (!show) {
		return null
	}
	return (
		<div className="data-table">
			<div className="">
				<h2>Extracción de Datos</h2>
				<div className="data-extraction">
					<Table
						Id={fileData.entity}
						CustomerName={fileData.customerName}
						CustomerAddress={fileData.customerAddress}
						CustomerId={fileData.customerId}
						CustomerCity={fileData.customerCity}
						DueDate={fileData.dueDate}
						IssueDate={fileData.issueDate}
						supplierId={fileData}
						InvoiceTax={fileData.invoiceTax}
						InvoiceId={fileData.invoiceId}
						InvoiceTotal={fileData.invoiceTotal}
						Items={getDetailedData(fileData.items)}
					/>
				</div>
			</div>
		</div>
	)
}
