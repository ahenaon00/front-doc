/** @type {import("prettier").Config} */
export default {
	printWidth: 100,
	semi: false,
	singleQuote: false,
	quoteProps: "consistent",
	tabWidth: 2,
	useTabs: true,
	endOfLine: "lf",
	arrowParens: "always",
	plugins: ["prettier-plugin-tailwindcss"],
	overrides: [
		{
			files: ["*.json", "*.md", "*.toml", "*.yml"],
			options: {
				useTabs: false,
			},
		},
	],
}
